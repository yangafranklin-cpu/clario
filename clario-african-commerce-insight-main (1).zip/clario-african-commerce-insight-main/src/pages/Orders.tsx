import { useState, useMemo } from "react";
import { useOrders } from "@/hooks/useOrders";
import { useProducts } from "@/hooks/useProducts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, UserCheck, DollarSign, History, Package, Plus } from "lucide-react";
import { AddOrderDialog } from "@/components/deliveries/AddOrderDialog";
import { AssignOrderDialog } from "@/components/orders/AssignOrderDialog";
import { EditLogisticsCostDialog } from "@/components/orders/EditLogisticsCostDialog";
import { OrderActionsHistory } from "@/components/orders/OrderActionsHistory";
import { useCurrency } from "@/contexts/CurrencyContext";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function Orders() {
  const { orders, isLoading, addOrder } = useOrders();
  const { products } = useProducts();
  const { formatAmount } = useCurrency();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [logisticsDialogOpen, setLogisticsDialogOpen] = useState(false);
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<string>("");
  const [selectedOrderAssignedTo, setSelectedOrderAssignedTo] = useState<string | undefined>();
  const [selectedOrderLogistics, setSelectedOrderLogistics] = useState<number>(0);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  const filteredOrders = orders?.filter((order) => {
    const matchesSearch =
      order.customer_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.id.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === "all" || order.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Pagination
  const totalPages = Math.ceil((filteredOrders?.length || 0) / itemsPerPage);
  const paginatedOrders = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredOrders?.slice(start, start + itemsPerPage);
  }, [filteredOrders, currentPage, itemsPerPage]);

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      pending: "secondary",
      processing: "default",
      shipped: "outline",
      delivered: "default",
      cancelled: "destructive",
    };

    const labels: Record<string, string> = {
      pending: "En attente",
      processing: "En cours",
      shipped: "Expédié",
      delivered: "Livré",
      cancelled: "Annulé",
    };

    return (
      <Badge variant={variants[status] || "default"}>
        {labels[status] || status}
      </Badge>
    );
  };

  const openAssignDialog = (orderId: string, assignedTo?: string) => {
    setSelectedOrderId(orderId);
    setSelectedOrderAssignedTo(assignedTo);
    setAssignDialogOpen(true);
  };

  const openLogisticsDialog = (orderId: string, currentCost?: number) => {
    setSelectedOrderId(orderId);
    setSelectedOrderLogistics(currentCost || 0);
    setLogisticsDialogOpen(true);
  };

  const openHistoryDialog = (orderId: string) => {
    setSelectedOrderId(orderId);
    setHistoryDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <h1 className="text-3xl font-bold">Commandes</h1>
        <Card>
          <CardContent className="p-6">
            <p>Chargement...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Gestion des commandes</h1>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="text-lg">
            <Package className="mr-2 h-4 w-4" />
            {filteredOrders?.length || 0} commandes
          </Badge>
          <Button onClick={() => setAddDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Nouvelle commande
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filtres</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher par client ou ID..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={(value) => {
              setStatusFilter(value);
              setCurrentPage(1);
            }}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Filtrer par statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="pending">En attente</SelectItem>
                <SelectItem value="processing">En cours</SelectItem>
                <SelectItem value="shipped">Expédié</SelectItem>
                <SelectItem value="delivered">Livré</SelectItem>
                <SelectItem value="cancelled">Annulé</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Produit</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Logistique</TableHead>
                <TableHead>Marge brute</TableHead>
                <TableHead>Profit net</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedOrders?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center text-muted-foreground">
                    Aucune commande trouvée
                  </TableCell>
                </TableRow>
              ) : (
                paginatedOrders?.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-mono text-xs">
                      {order.id.slice(0, 8)}
                    </TableCell>
                    <TableCell>{order.customer_name}</TableCell>
                    <TableCell>
                      {order.products?.name || order.product_variants?.name || "N/A"}
                      {order.quantity > 1 && ` (×${order.quantity})`}
                    </TableCell>
                    <TableCell>{getStatusBadge(order.status)}</TableCell>
                    <TableCell>
                      {formatAmount(order.logistics_cost || 0)}
                    </TableCell>
                    <TableCell className="text-green-600 font-medium">
                      {formatAmount(order.gross_margin || 0)}
                    </TableCell>
                    <TableCell className="text-blue-600 font-medium">
                      {formatAmount(order.net_profit || 0)}
                    </TableCell>
                    <TableCell>
                      {format(new Date(order.created_at), "dd MMM yyyy", { locale: fr })}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openAssignDialog(order.id, order.assigned_to)}
                        >
                          <UserCheck className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openLogisticsDialog(order.id, order.logistics_cost)}
                        >
                          <DollarSign className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openHistoryDialog(order.id)}
                        >
                          <History className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between p-4">
              <p className="text-sm text-muted-foreground">
                Page {currentPage} sur {totalPages}
              </p>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                >
                  Précédent
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                >
                  Suivant
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <AddOrderDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        onAdd={addOrder}
        products={products.map((p) => ({
          id: p.id,
          name: p.name,
          price: p.sale_price,
          currency: p.currency,
        }))}
      />

      <AssignOrderDialog
        open={assignDialogOpen}
        onOpenChange={setAssignDialogOpen}
        orderId={selectedOrderId}
        currentAssignedTo={selectedOrderAssignedTo}
      />

      <EditLogisticsCostDialog
        open={logisticsDialogOpen}
        onOpenChange={setLogisticsDialogOpen}
        orderId={selectedOrderId}
        currentCost={selectedOrderLogistics}
      />

      {historyDialogOpen && (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
          <div className="fixed left-[50%] top-[50%] z-50 w-full max-w-2xl translate-x-[-50%] translate-y-[-50%] p-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Historique de la commande</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => setHistoryDialogOpen(false)}>
                  ✕
                </Button>
              </CardHeader>
              <CardContent>
                <OrderActionsHistory orderId={selectedOrderId} />
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}