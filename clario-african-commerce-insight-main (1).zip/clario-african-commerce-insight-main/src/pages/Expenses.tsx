import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Trash2, Loader2, Download, Search } from "lucide-react";
import { AddExpenseDialog } from "@/components/expenses/AddExpenseDialog";
import { ExpensesByCategory } from "@/components/expenses/ExpensesByCategory";
import { ExpensesByProduct } from "@/components/expenses/ExpensesByProduct";
import { ExpensesByPeriod } from "@/components/expenses/ExpensesByPeriod";
import { ExportDialog } from "@/components/shared/ExportDialog";
import { useExpenses } from "@/hooks/useExpenses";
import { useProducts } from "@/hooks/useProducts";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Expense } from "@/types";
import { ExportColumn } from "@/lib/export";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const categoryLabels: Record<Expense["category"], string> = {
  facebook_ads: "Facebook Ads",
  tiktok_ads: "TikTok Ads",
  influencer: "Influenceur",
  flyer: "Flyer",
  shipping: "Livraison",
  other: "Autre",
};

const Expenses = () => {
  const { expenses, isLoading, addExpense, deleteExpense } = useExpenses();
  const { products } = useProducts();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { formatAmount, convertAmount } = useCurrency();

  const getProductName = (productId?: string) => {
    if (!productId) return "-";
    const product = products.find((p) => p.id === productId);
    return product?.name || "-";
  };

  // Filter expenses based on search
  const filteredExpenses = useMemo(() => {
    if (!searchQuery) return expenses;
    
    const query = searchQuery.toLowerCase();
    return expenses.filter(
      (expense) =>
        expense.title.toLowerCase().includes(query) ||
        categoryLabels[expense.category].toLowerCase().includes(query) ||
        getProductName(expense.linked_product_id).toLowerCase().includes(query)
    );
  }, [expenses, searchQuery]);

  const totalExpenses = filteredExpenses.reduce((sum, exp) => {
    return sum + convertAmount(exp.amount, exp.currency);
  }, 0);

  // Export columns configuration
  const exportColumns: ExportColumn[] = [
    { key: "title", label: "Titre" },
    {
      key: "category",
      label: "Catégorie",
      format: (value) => categoryLabels[value as Expense["category"]],
    },
    {
      key: "amount",
      label: "Montant",
      format: (value) => value.toString(),
    },
    { key: "currency", label: "Devise" },
    {
      key: "linked_product_id",
      label: "Produit lié",
      format: (value) => getProductName(value),
    },
    {
      key: "date",
      label: "Date",
      format: (value) => format(new Date(value), "dd/MM/yyyy"),
    },
    { key: "source", label: "Source" },
    { key: "notes", label: "Notes" },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dépenses & Publicités</h1>
          <p className="text-muted-foreground mt-1">
            Suivez toutes vos dépenses marketing et opérationnelles
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setExportOpen(true)}>
            <Download className="mr-2 h-4 w-4" />
            Exporter
          </Button>
          <Button onClick={() => setDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Ajouter une dépense
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Total des dépenses</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{formatAmount(totalExpenses)}</div>
          <p className="text-sm text-muted-foreground mt-1">
            {filteredExpenses.length} dépense{filteredExpenses.length > 1 ? "s" : ""}
          </p>
        </CardContent>
      </Card>

      <Tabs defaultValue="list" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="list">Liste</TabsTrigger>
          <TabsTrigger value="category">Par catégorie</TabsTrigger>
          <TabsTrigger value="product">Par produit</TabsTrigger>
          <TabsTrigger value="period">Par période</TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Rechercher par titre, catégorie ou produit..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Dépenses récentes</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredExpenses.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  {searchQuery
                    ? "Aucune dépense ne correspond à votre recherche."
                    : "Aucune dépense enregistrée."}
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Titre</TableHead>
                      <TableHead>Catégorie</TableHead>
                      <TableHead>Produit</TableHead>
                      <TableHead>Montant</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredExpenses.map((expense) => (
                      <TableRow key={expense.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{expense.title}</div>
                            {expense.notes && (
                              <div className="text-xs text-muted-foreground truncate max-w-[200px]">
                                {expense.notes}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{categoryLabels[expense.category]}</Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {getProductName(expense.linked_product_id)}
                        </TableCell>
                        <TableCell className="font-medium">
                          {formatAmount(convertAmount(expense.amount, expense.currency))}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {format(new Date(expense.date), "dd MMM yyyy", { locale: fr })}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteExpense(expense.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="category">
          <ExpensesByCategory expenses={filteredExpenses} />
        </TabsContent>

        <TabsContent value="product">
          <ExpensesByProduct expenses={filteredExpenses} products={products} />
        </TabsContent>

        <TabsContent value="period">
          <ExpensesByPeriod expenses={filteredExpenses} />
        </TabsContent>
      </Tabs>

      <AddExpenseDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onAdd={addExpense}
        products={products.map((p) => ({ id: p.id, name: p.name }))}
      />

      <ExportDialog
        open={exportOpen}
        onOpenChange={setExportOpen}
        data={filteredExpenses}
        allColumns={exportColumns}
        defaultFilename={`depenses_${format(new Date(), "yyyy-MM-dd")}`}
        title="Exporter les dépenses"
      />
    </div>
  );
};

export default Expenses;
