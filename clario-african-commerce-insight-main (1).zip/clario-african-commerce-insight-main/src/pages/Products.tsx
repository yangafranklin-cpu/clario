import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Plus,
  Trash2,
  Loader2,
  Search,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Eye,
  Download,
} from "lucide-react";
import { AddProductDialog } from "@/components/products/AddProductDialog";
import { ExportDialog } from "@/components/shared/ExportDialog";
import { useProducts } from "@/hooks/useProducts";
import { useOrders } from "@/hooks/useOrders";
import { useExpenses } from "@/hooks/useExpenses";
import { useCurrency } from "@/contexts/CurrencyContext";
import { PeriodSelector, Period } from "@/components/dashboard/PeriodSelector";
import { ExportColumn } from "@/lib/export";
import { startOfDay, startOfWeek, startOfMonth, isWithinInterval, format } from "date-fns";

type SortField = "name" | "sales" | "gross_margin" | "net_margin";
type SortDirection = "asc" | "desc";

const Products = () => {
  const navigate = useNavigate();
  const { products, isLoading, addProduct, deleteProduct } = useProducts();
  const { orders } = useOrders();
  const { expenses } = useExpenses();
  const [dialogOpen, setDialogOpen] = useState(false);
  const { formatAmount, convertAmount } = useCurrency();
  
  const [period, setPeriod] = useState<Period>("month");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortField, setSortField] = useState<SortField>("name");
  const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
  const [currentPage, setCurrentPage] = useState(1);
  const [exportOpen, setExportOpen] = useState(false);
  const itemsPerPage = 10;

  // Calculate period start
  const periodStart = useMemo(() => {
    const now = new Date();
    switch (period) {
      case "day":
        return startOfDay(now);
      case "week":
        return startOfWeek(now, { weekStartsOn: 1 });
      case "month":
        return startOfMonth(now);
    }
  }, [period]);

  // Calculate metrics for each product
  const productsWithMetrics = useMemo(() => {
    return products.map((product) => {
      const productOrders = orders.filter(
        (order) =>
          order.product_id === product.id &&
          isWithinInterval(new Date(order.created_at), {
            start: periodStart,
            end: new Date(),
          })
      );

      const sales = productOrders.reduce((sum, order) => {
        return sum + convertAmount(order.total_amount, order.currency);
      }, 0);

      const quantitySold = productOrders.reduce((sum, order) => sum + order.quantity, 0);

      const logisticsCost = productOrders.reduce((sum, order) => {
        return sum + convertAmount(order.logistics_cost || 0, order.currency);
      }, 0);

      const linkedExpenses = expenses
        .filter(
          (expense) =>
            expense.linked_product_id === product.id &&
            isWithinInterval(new Date(expense.date), {
              start: periodStart,
              end: new Date(),
            })
        )
        .reduce((sum, expense) => {
          return sum + convertAmount(expense.amount, expense.currency);
        }, 0);

      const grossMargin = product.sale_price - product.cost_price;
      const grossMarginPercent = ((grossMargin / product.sale_price) * 100);
      
      const netProfit = sales - linkedExpenses - logisticsCost;
      const netMarginPercent = sales > 0 ? (netProfit / sales) * 100 : 0;

      return {
        ...product,
        sales,
        quantitySold,
        grossMargin,
        grossMarginPercent,
        netProfit,
        netMarginPercent,
      };
    });
  }, [products, orders, expenses, periodStart, convertAmount]);

  // Filter and sort
  const filteredAndSortedProducts = useMemo(() => {
    let filtered = productsWithMetrics;

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.sku?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let comparison = 0;
      switch (sortField) {
        case "name":
          comparison = a.name.localeCompare(b.name);
          break;
        case "sales":
          comparison = a.sales - b.sales;
          break;
        case "gross_margin":
          comparison = a.grossMarginPercent - b.grossMarginPercent;
          break;
        case "net_margin":
          comparison = a.netMarginPercent - b.netMarginPercent;
          break;
      }
      return sortDirection === "asc" ? comparison : -comparison;
    });

    return filtered;
  }, [productsWithMetrics, searchQuery, sortField, sortDirection]);

  // Pagination
  const totalPages = Math.ceil(filteredAndSortedProducts.length / itemsPerPage);
  const paginatedProducts = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredAndSortedProducts.slice(start, start + itemsPerPage);
  }, [filteredAndSortedProducts, currentPage, itemsPerPage]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="ml-2 h-4 w-4" />;
    return sortDirection === "asc" ? (
      <ArrowUp className="ml-2 h-4 w-4" />
    ) : (
      <ArrowDown className="ml-2 h-4 w-4" />
    );
  };

  // Export columns configuration
  const exportColumns: ExportColumn[] = [
    { key: "name", label: "Nom" },
    { key: "sku", label: "SKU" },
    {
      key: "sale_price",
      label: "Prix de vente",
      format: (value) => formatAmount(value),
    },
    {
      key: "cost_price",
      label: "Prix d'achat",
      format: (value) => formatAmount(value),
    },
    {
      key: "sales",
      label: "Ventes (période)",
      format: (value) => formatAmount(value),
    },
    {
      key: "quantitySold",
      label: "Quantité vendue (période)",
    },
    {
      key: "grossMarginPercent",
      label: "Marge brute %",
      format: (value) => `${value.toFixed(1)}%`,
    },
    {
      key: "netMarginPercent",
      label: "Marge nette %",
      format: (value) => `${value.toFixed(1)}%`,
    },
    {
      key: "netProfit",
      label: "Profit net (période)",
      format: (value) => formatAmount(value),
    },
    { key: "currency", label: "Devise" },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Produits</h1>
          <p className="text-muted-foreground mt-1">
            Suivez les performances et rentabilité de vos produits
          </p>
        </div>
        <div className="flex items-center gap-2">
          <PeriodSelector value={period} onChange={setPeriod} />
          <Button variant="outline" onClick={() => setExportOpen(true)}>
            <Download className="mr-2 h-4 w-4" />
            Exporter
          </Button>
          <Button onClick={() => setDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Ajouter un produit
          </Button>
        </div>
      </div>

      {/* Search and filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher par nom ou SKU..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="pl-9"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Products table */}
      <Card>
        <CardHeader>
          <CardTitle>
            {filteredAndSortedProducts.length} produit{filteredAndSortedProducts.length > 1 ? "s" : ""}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {paginatedProducts.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              {products.length === 0
                ? "Aucun produit pour le moment. Commencez par en ajouter un."
                : "Aucun produit ne correspond à votre recherche."}
            </p>
          ) : (
            <>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Image</TableHead>
                      <TableHead>
                        <Button
                          variant="ghost"
                          onClick={() => toggleSort("name")}
                          className="h-8 px-2"
                        >
                          Nom <SortIcon field="name" />
                        </Button>
                      </TableHead>
                      <TableHead>SKU</TableHead>
                      <TableHead>Prix</TableHead>
                      <TableHead>
                        <Button
                          variant="ghost"
                          onClick={() => toggleSort("sales")}
                          className="h-8 px-2"
                        >
                          Ventes <SortIcon field="sales" />
                        </Button>
                      </TableHead>
                      <TableHead>
                        <Button
                          variant="ghost"
                          onClick={() => toggleSort("gross_margin")}
                          className="h-8 px-2"
                        >
                          Marge brute <SortIcon field="gross_margin" />
                        </Button>
                      </TableHead>
                      <TableHead>
                        <Button
                          variant="ghost"
                          onClick={() => toggleSort("net_margin")}
                          className="h-8 px-2"
                        >
                          Marge nette <SortIcon field="net_margin" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedProducts.map((product) => (
                      <TableRow key={product.id} className="hover:bg-muted/50">
                        <TableCell>
                          {product.image_url ? (
                            <img
                              src={product.image_url}
                              alt={product.name}
                              className="h-12 w-12 object-cover rounded"
                              loading="lazy"
                            />
                          ) : (
                            <div className="h-12 w-12 bg-muted rounded flex items-center justify-center text-muted-foreground text-xs">
                              Pas d'image
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="font-medium">{product.name}</TableCell>
                        <TableCell className="text-muted-foreground">{product.sku || "-"}</TableCell>
                        <TableCell>{formatAmount(product.sale_price)}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{formatAmount(product.sales)}</div>
                            <div className="text-xs text-muted-foreground">
                              {product.quantitySold} unités
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-green-600 font-medium">
                            {product.grossMarginPercent.toFixed(1)}%
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {formatAmount(product.grossMargin)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div
                            className={`font-medium ${
                              product.netMarginPercent >= 0 ? "text-green-600" : "text-red-600"
                            }`}
                          >
                            {product.netMarginPercent.toFixed(1)}%
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {formatAmount(product.netProfit)}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => navigate(`/products/${product.id}`)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteProduct(product.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <p className="text-sm text-muted-foreground">
                    Page {currentPage} sur {totalPages}
                  </p>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      Précédent
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                    >
                      Suivant
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      <AddProductDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onAdd={addProduct}
      />

      <ExportDialog
        open={exportOpen}
        onOpenChange={setExportOpen}
        data={filteredAndSortedProducts}
        allColumns={exportColumns}
        defaultFilename={`produits_${format(new Date(), "yyyy-MM-dd")}`}
        title="Exporter les produits"
      />
    </div>
  );
};

export default Products;
