import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Loader2, Download } from "lucide-react";
import { AddOrderDialog } from "@/components/deliveries/AddOrderDialog";
import { ExportDialog } from "@/components/shared/ExportDialog";
import { useOrders } from "@/hooks/useOrders";
import { useProducts } from "@/hooks/useProducts";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Order } from "@/types";
import { ExportColumn } from "@/lib/export";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const statusLabels: Record<Order["status"], { label: string; variant: "default" | "secondary" | "outline" | "destructive" }> = {
  pending: { label: "En attente", variant: "outline" },
  processing: { label: "En traitement", variant: "secondary" },
  shipped: { label: "Expédiée", variant: "default" },
  delivered: { label: "Livrée", variant: "default" },
  cancelled: { label: "Annulée", variant: "destructive" },
};

const Deliveries = () => {
  const { orders, isLoading, addOrder, updateOrder, deleteOrder } = useOrders();
  const { products } = useProducts();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const { formatAmount, convertAmount } = useCurrency();

  const handleStatusChange = (orderId: string, newStatus: Order["status"]) => {
    updateOrder({ id: orderId, status: newStatus });
  };

  const getProductName = (productId?: string) => {
    if (!productId) return "Produit inconnu";
    const product = products.find((p) => p.id === productId);
    return product?.name || "Produit inconnu";
  };

  const activeOrders = orders.filter((o) => o.status !== "delivered" && o.status !== "cancelled");
  const completedOrders = orders.filter((o) => o.status === "delivered" || o.status === "cancelled");

  // Export columns configuration
  const exportColumns: ExportColumn[] = [
    { key: "customer_name", label: "Client" },
    {
      key: "product_id",
      label: "Produit",
      format: (value) => getProductName(value),
    },
    { key: "quantity", label: "Quantité" },
    {
      key: "total_amount",
      label: "Montant total",
      format: (value) => value.toString(),
    },
    { key: "currency", label: "Devise" },
    {
      key: "logistics_cost",
      label: "Frais logistique",
      format: (value) => value?.toString() || "0",
    },
    {
      key: "gross_margin",
      label: "Marge brute",
      format: (value) => value?.toString() || "0",
    },
    {
      key: "net_profit",
      label: "Profit net",
      format: (value) => value?.toString() || "0",
    },
    {
      key: "status",
      label: "Statut",
      format: (value) => statusLabels[value as Order["status"]].label,
    },
    { key: "assigned_to", label: "Assignée à" },
    {
      key: "created_at",
      label: "Date de création",
      format: (value) => format(new Date(value), "dd/MM/yyyy HH:mm"),
    },
    {
      key: "updated_at",
      label: "Dernière mise à jour",
      format: (value) => format(new Date(value), "dd/MM/yyyy HH:mm"),
    },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Livraisons</h1>
          <p className="text-muted-foreground mt-1">
            Suivez l'état de toutes vos commandes
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setExportOpen(true)}>
            <Download className="mr-2 h-4 w-4" />
            Exporter
          </Button>
          <Button onClick={() => setDialogOpen(true)} disabled={products.length === 0}>
            <Plus className="mr-2 h-4 w-4" />
            Nouvelle commande
          </Button>
        </div>
      </div>

      {products.length === 0 && (
        <Card>
          <CardContent className="pt-6">
            <p className="text-muted-foreground text-center">
              Ajoutez d'abord des produits avant de créer des commandes
            </p>
          </CardContent>
        </Card>
      )}

      {/* Active Orders */}
      <Card>
        <CardHeader>
          <CardTitle>Commandes en cours ({activeOrders.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {activeOrders.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              Aucune commande en cours
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Produit</TableHead>
                  <TableHead>Montant</TableHead>
                  <TableHead>Marge brute</TableHead>
                  <TableHead>Profit net</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Assignée à</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activeOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">{order.customer_name}</TableCell>
                    <TableCell>{getProductName(order.product_id)}</TableCell>
                    <TableCell>{formatAmount(convertAmount(order.total_amount, order.currency))}</TableCell>
                    <TableCell>
                      <span className={order.gross_margin && order.gross_margin >= 0 ? "text-green-600" : "text-red-600"}>
                        {formatAmount(convertAmount(order.gross_margin || 0, order.currency))}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={order.net_profit && order.net_profit >= 0 ? "text-green-600" : "text-red-600"}>
                        {formatAmount(convertAmount(order.net_profit || 0, order.currency))}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Select
                        value={order.status}
                        onValueChange={(value: Order["status"]) => handleStatusChange(order.id, value)}
                      >
                        <SelectTrigger className="w-[140px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">En attente</SelectItem>
                          <SelectItem value="processing">En traitement</SelectItem>
                          <SelectItem value="shipped">Expédiée</SelectItem>
                          <SelectItem value="delivered">Livrée</SelectItem>
                          <SelectItem value="cancelled">Annulée</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {order.assigned_to || "-"}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {format(new Date(order.created_at), "dd MMM", { locale: fr })}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteOrder(order.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Completed Orders */}
      {completedOrders.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Commandes terminées ({completedOrders.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Produit</TableHead>
                  <TableHead>Montant</TableHead>
                  <TableHead>Marge brute</TableHead>
                  <TableHead>Profit net</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {completedOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">{order.customer_name}</TableCell>
                    <TableCell>{getProductName(order.product_id)}</TableCell>
                    <TableCell>{formatAmount(convertAmount(order.total_amount, order.currency))}</TableCell>
                    <TableCell>
                      <span className={order.gross_margin && order.gross_margin >= 0 ? "text-green-600" : "text-red-600"}>
                        {formatAmount(convertAmount(order.gross_margin || 0, order.currency))}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={order.net_profit && order.net_profit >= 0 ? "text-green-600" : "text-red-600"}>
                        {formatAmount(convertAmount(order.net_profit || 0, order.currency))}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant={statusLabels[order.status].variant}>
                        {statusLabels[order.status].label}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {format(new Date(order.updated_at), "dd MMM yyyy", { locale: fr })}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <AddOrderDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onAdd={addOrder}
        products={products.map((p) => ({ id: p.id, name: p.name, price: p.sale_price, currency: p.currency }))}
      />

      <ExportDialog
        open={exportOpen}
        onOpenChange={setExportOpen}
        data={orders}
        allColumns={exportColumns}
        defaultFilename={`commandes_${format(new Date(), "yyyy-MM-dd")}`}
        title="Exporter les commandes"
      />
    </div>
  );
};

export default Deliveries;
