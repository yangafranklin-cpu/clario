import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, DollarSign, TrendingUp, Package, Loader2, Link as LinkIcon } from "lucide-react";
import { useProducts } from "@/hooks/useProducts";
import { useProductMetrics } from "@/hooks/useProductMetrics";
import { useCurrency } from "@/contexts/CurrencyContext";
import { PeriodSelector, Period } from "@/components/dashboard/PeriodSelector";
import { ProductProfitChart } from "@/components/products/ProductProfitChart";
import { LinkExpenseDialog } from "@/components/products/LinkExpenseDialog";
import { startOfDay, startOfWeek, startOfMonth, subMonths } from "date-fns";

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { products, isLoading } = useProducts();
  const { formatAmount } = useCurrency();
  const [period, setPeriod] = useState<Period>("month");
  const [linkExpenseOpen, setLinkExpenseOpen] = useState(false);

  const product = products.find((p) => p.id === id);

  // Calculate period range
  const now = new Date();
  const periodStart =
    period === "day"
      ? startOfDay(now)
      : period === "week"
      ? startOfWeek(now, { weekStartsOn: 1 })
      : startOfMonth(now);

  // For chart, show last 6 months
  const chartStartDate = subMonths(now, 6);

  const metrics = useProductMetrics(id || "", periodStart, now);
  const chartMetrics = useProductMetrics(id || "", chartStartDate, now);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="space-y-6">
        <Button variant="ghost" onClick={() => navigate("/products")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Retour aux produits
        </Button>
        <Card>
          <CardContent className="py-8">
            <p className="text-center text-muted-foreground">Produit non trouvé</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const grossMargin = product.sale_price - product.cost_price;
  const grossMarginPercent = ((grossMargin / product.sale_price) * 100).toFixed(1);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={() => navigate("/products")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{product.name}</h1>
            <p className="text-muted-foreground mt-1">
              {product.sku && <span>SKU: {product.sku}</span>}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <PeriodSelector value={period} onChange={setPeriod} />
          <Button onClick={() => setLinkExpenseOpen(true)} variant="outline">
            <LinkIcon className="mr-2 h-4 w-4" />
            Lier une dépense
          </Button>
        </div>
      </div>

      {/* Product Info Card */}
      <Card>
        <CardHeader>
          <CardTitle>Informations produit</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Prix de vente</p>
              <p className="text-lg font-semibold">{formatAmount(product.sale_price)}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Prix d'achat</p>
              <p className="text-lg font-semibold">{formatAmount(product.cost_price)}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Marge brute</p>
              <p className="text-lg font-semibold text-green-600">
                {formatAmount(grossMargin)} ({grossMarginPercent}%)
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total vendu</p>
              <p className="text-lg font-semibold">{product.total_sold}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Metrics Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ventes</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatAmount(metrics.totalSales)}</div>
            <p className="text-xs text-muted-foreground">{metrics.totalQuantity} unités vendues</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Dépenses pub</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatAmount(metrics.totalAdSpend)}</div>
            <p className="text-xs text-muted-foreground">
              {metrics.linkedExpenses.length} dépense{metrics.linkedExpenses.length > 1 ? "s" : ""} liée{metrics.linkedExpenses.length > 1 ? "s" : ""}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Coût logistique</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatAmount(metrics.totalLogisticsCost)}</div>
            <p className="text-xs text-muted-foreground">Frais de livraison</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Bénéfice net</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div
              className={`text-2xl font-bold ${
                metrics.netProfit >= 0 ? "text-green-600" : "text-red-600"
              }`}
            >
              {formatAmount(metrics.netProfit)}
            </div>
            <p className="text-xs text-muted-foreground">
              Marge:{" "}
              {metrics.totalSales > 0
                ? ((metrics.netProfit / metrics.totalSales) * 100).toFixed(1)
                : "0"}
              %
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Chart */}
      <ProductProfitChart data={chartMetrics.monthlyData} />

      {/* Linked Expenses */}
      <Card>
        <CardHeader>
          <CardTitle>Dépenses liées ({metrics.linkedExpenses.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {metrics.linkedExpenses.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              Aucune dépense liée à ce produit
            </p>
          ) : (
            <div className="space-y-2">
              {metrics.linkedExpenses.map((expense) => (
                <div
                  key={expense.id}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div className="flex-1">
                    <p className="font-medium">{expense.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline">{expense.category}</Badge>
                      <span className="text-sm text-muted-foreground">
                        {new Date(expense.date).toLocaleDateString("fr-FR")}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">
                      {expense.amount} {expense.currency}
                    </p>
                    <p className="text-xs text-muted-foreground">{expense.source}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <LinkExpenseDialog
        open={linkExpenseOpen}
        onOpenChange={setLinkExpenseOpen}
        productId={product.id}
      />
    </div>
  );
};

export default ProductDetail;
