import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ExternalLink, CheckCircle, User, Lock, Bell, Users, Settings as SettingsIcon } from "lucide-react";
import { ProfileManagement } from "@/components/settings/ProfileManagement";
import { SecuritySettings } from "@/components/settings/SecuritySettings";
import { PreferencesSettings } from "@/components/settings/PreferencesSettings";
import { TeamManagement } from "@/components/admin/TeamManagement";

const Settings = () => {
  const { currentCurrency, currencies, setCurrency } = useCurrency();
  const { user, userRole } = useAuth();
  const { toast } = useToast();
  const [isConnecting, setIsConnecting] = useState(false);
  const [shopifyConnected, setShopifyConnected] = useState(false);
  const [shopDomain, setShopDomain] = useState("");

  const SHOPIFY_CLIENT_ID = "f9b3fcb50f731babcfeb5210d928297d";
  // Use the exact URL format Shopify expects
  const REDIRECT_URI = window.location.hostname === 'localhost' 
    ? 'http://localhost:5173/settings'
    : `${window.location.origin}/settings`;

  const handleShopifyConnect = () => {
    if (!shopDomain) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Veuillez entrer votre nom de boutique Shopify",
      });
      return;
    }

    const shop = shopDomain.includes('.myshopify.com') 
      ? shopDomain 
      : `${shopDomain}.myshopify.com`;

    const scopes = "read_products,read_orders,write_products,write_orders";
    const nonce = Math.random().toString(36).substring(7);
    
    // Store user ID and shop in localStorage for callback
    localStorage.setItem('shopify_oauth_user_id', user?.id || '');
    localStorage.setItem('shopify_oauth_shop', shop);

    // Build the authorization URL with proper encoding
    const authUrl = `https://${shop}/admin/oauth/authorize?` + 
      `client_id=${encodeURIComponent(SHOPIFY_CLIENT_ID)}` +
      `&scope=${encodeURIComponent(scopes)}` +
      `&redirect_uri=${encodeURIComponent(REDIRECT_URI)}` +
      `&state=${nonce}`;
    
    console.log('Redirecting to Shopify OAuth:', authUrl);
    console.log('Redirect URI configured:', REDIRECT_URI);
    
    window.location.href = authUrl;
  };

  // Handle OAuth callback
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const shop = urlParams.get('shop');
    const error = urlParams.get('error');
    const errorDescription = urlParams.get('error_description');

    // Handle OAuth errors
    if (error) {
      console.error('OAuth error:', error, errorDescription);
      toast({
        variant: "destructive",
        title: "Erreur d'autorisation Shopify",
        description: errorDescription || error,
      });
      // Clean up URL
      window.history.replaceState({}, document.title, "/settings");
      return;
    }

    if (code && shop) {
      setIsConnecting(true);
      const userId = localStorage.getItem('shopify_oauth_user_id');
      
      console.log('Processing OAuth callback with code:', code.substring(0, 10) + '...');
      
      supabase.functions
        .invoke('shopify-oauth-callback', {
          body: { code, shop, userId },
        })
        .then(({ data, error }) => {
          if (error) {
            console.error('Callback error:', error);
            toast({
              variant: "destructive",
              title: "Erreur de connexion",
              description: error.message || 'Impossible de compléter la connexion à Shopify',
            });
          } else {
            setShopifyConnected(true);
            toast({
              title: "Connexion réussie",
              description: "Votre boutique Shopify est maintenant connectée. La synchronisation des produits et commandes a commencé.",
            });
            // Clean up URL
            window.history.replaceState({}, document.title, "/settings");
          }
        })
        .catch((err) => {
          console.error('Unexpected error:', err);
          toast({
            variant: "destructive",
            title: "Erreur inattendue",
            description: "Une erreur est survenue lors de la connexion",
          });
        })
        .finally(() => {
          setIsConnecting(false);
          localStorage.removeItem('shopify_oauth_user_id');
          localStorage.removeItem('shopify_oauth_shop');
        });
    }

    // Check if already connected
    if (user?.id) {
      supabase
        .from('profiles')
        .select('shopify_connected')
        .eq('id', user.id)
        .single()
        .then(({ data }) => {
          if (data?.shopify_connected) {
            setShopifyConnected(true);
          }
        });
    }
  }, [user, toast]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Paramètres</h1>
        <p className="text-muted-foreground mt-1">
          Configurez votre compte et vos préférences
        </p>
      </div>

      <Tabs defaultValue="profile" className="space-y-4 sm:space-y-6">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-5 h-auto p-1 gap-1">
          <TabsTrigger value="profile" className="gap-2">
            <User className="h-4 w-4" />
            <span className="hidden sm:inline">Profil</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="gap-2">
            <Lock className="h-4 w-4" />
            <span className="hidden sm:inline">Sécurité</span>
          </TabsTrigger>
          <TabsTrigger value="preferences" className="gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden sm:inline">Préférences</span>
          </TabsTrigger>
          <TabsTrigger value="currency" className="gap-2">
            <SettingsIcon className="h-4 w-4" />
            <span className="hidden sm:inline">Devise</span>
          </TabsTrigger>
          {userRole === "admin" && (
            <TabsTrigger value="team" className="gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Équipe</span>
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <ProfileManagement />
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <SecuritySettings />
        </TabsContent>

        <TabsContent value="preferences" className="space-y-6">
          <PreferencesSettings />
        </TabsContent>

        <TabsContent value="currency" className="space-y-6">
          <Card className="modern-card">
        <CardHeader>
          <CardTitle>Devise & Localisation</CardTitle>
          <CardDescription>
            Choisissez votre devise principale pour afficher tous les montants
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="currency">Devise principale</Label>
            <Select value={currentCurrency.code} onValueChange={setCurrency}>
              <SelectTrigger id="currency" className="w-[240px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {currencies.map((currency) => (
                  <SelectItem key={currency.code} value={currency.code}>
                    {currency.code} ({currency.symbol})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              Tous les montants seront affichés dans cette devise
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Intégrations</CardTitle>
          <CardDescription>
            Connectez vos comptes Shopify, Facebook Ads et autres plateformes
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Shopify Integration */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <ExternalLink className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold">Shopify</h4>
                  <p className="text-sm text-muted-foreground">
                    Synchronisez vos produits et commandes
                  </p>
                </div>
              </div>
              {shopifyConnected ? (
                <Badge variant="outline" className="gap-1">
                  <CheckCircle className="h-3 w-3" />
                  Connecté
                </Badge>
              ) : (
                <Badge variant="secondary">Non connecté</Badge>
              )}
            </div>

            {!shopifyConnected && (
              <div className="space-y-3 pt-2">
                <div className="rounded-lg bg-blue-50 dark:bg-blue-950 p-4 mb-4">
                  <h4 className="font-semibold text-sm mb-2">⚠️ Configuration requise</h4>
                  <ol className="text-xs space-y-1 list-decimal list-inside text-muted-foreground">
                    <li>Créez une application Shopify dans votre <a href="https://partners.shopify.com" target="_blank" rel="noopener noreferrer" className="underline">Partners Dashboard</a></li>
                    <li>Configurez l'URL de redirection : <code className="bg-muted px-1 py-0.5 rounded">{REDIRECT_URI}</code></li>
                    <li>Utilisez le Client ID : <code className="bg-muted px-1 py-0.5 rounded">{SHOPIFY_CLIENT_ID}</code></li>
                  </ol>
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="shop-domain">Nom de votre boutique</Label>
                  <div className="flex gap-2">
                    <input
                      id="shop-domain"
                      type="text"
                      placeholder="ma-boutique"
                      value={shopDomain}
                      onChange={(e) => setShopDomain(e.target.value)}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    />
                    <span className="flex items-center text-sm text-muted-foreground whitespace-nowrap">
                      .myshopify.com
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Entrez le nom de votre boutique Shopify (sans .myshopify.com)
                  </p>
                </div>
                <Button 
                  onClick={handleShopifyConnect}
                  disabled={isConnecting || !shopDomain}
                  className="w-full"
                >
                  {isConnecting ? "Connexion en cours..." : "Connecter Shopify"}
                </Button>
              </div>
            )}

            {shopifyConnected && (
              <div className="rounded-lg bg-muted/50 p-4">
                <p className="text-sm text-muted-foreground">
                  ✅ Synchronisation automatique toutes les 5 minutes
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Les produits et commandes sont synchronisés automatiquement
                </p>
              </div>
            )}
          </div>

          {/* Facebook Ads - Coming Soon */}
          <div className="space-y-4 pt-4 border-t">
            <div className="flex items-center justify-between opacity-50">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <ExternalLink className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold">Facebook Ads</h4>
                  <p className="text-sm text-muted-foreground">
                    Importez vos dépenses publicitaires
                  </p>
                </div>
              </div>
              <Badge variant="secondary">Bientôt disponible</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
        </TabsContent>

        {userRole === "admin" && (
          <TabsContent value="team" className="space-y-6">
            <TeamManagement />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default Settings;
