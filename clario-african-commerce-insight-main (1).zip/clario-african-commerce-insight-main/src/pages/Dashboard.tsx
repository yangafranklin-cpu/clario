import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, DollarSign, ShoppingCart, TruckIcon, Loader2 } from "lucide-react";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useProducts } from "@/hooks/useProducts";
import { useExpenses } from "@/hooks/useExpenses";
import { useOrders } from "@/hooks/useOrders";
import { useAuth } from "@/contexts/AuthContext";
import { startOfDay, startOfWeek, startOfMonth, isWithinInterval, isToday } from "date-fns";
import { PeriodSelector, Period } from "@/components/dashboard/PeriodSelector";
import { RevenueChart } from "@/components/dashboard/RevenueChart";
import { ROASChart } from "@/components/dashboard/ROASChart";
import { OrdersStatusChart } from "@/components/dashboard/OrdersStatusChart";
import { AlertsPanel } from "@/components/dashboard/AlertsPanel";
import { DailyInsightsCard } from "@/components/dashboard/DailyInsightsCard";

const Dashboard = () => {
  const { products } = useProducts();
  const { expenses } = useExpenses();
  const { orders, isLoading } = useOrders();
  const { formatAmount, convertAmount } = useCurrency();
  const { userRole } = useAuth();
  const [period, setPeriod] = useState<Period>("day");

  // Calculate period start date
  const periodStart = useMemo(() => {
    const now = new Date();
    switch (period) {
      case "day":
        return startOfDay(now);
      case "week":
        return startOfWeek(now, { weekStartsOn: 1 });
      case "month":
        return startOfMonth(now);
    }
  }, [period]);

  // Filter data by period
  const periodOrders = useMemo(
    () =>
      orders.filter((order) =>
        isWithinInterval(new Date(order.created_at), {
          start: periodStart,
          end: new Date(),
        })
      ),
    [orders, periodStart]
  );

  const periodExpenses = useMemo(
    () =>
      expenses.filter((expense) =>
        isWithinInterval(new Date(expense.date), {
          start: periodStart,
          end: new Date(),
        })
      ),
    [expenses, periodStart]
  );

  // Calculate metrics
  const periodRevenue = periodOrders.reduce((sum, order) => {
    return sum + convertAmount(order.total_amount, order.currency);
  }, 0);

  const periodExpensesTotal = periodExpenses.reduce((sum, expense) => {
    return sum + convertAmount(expense.amount, expense.currency);
  }, 0);

  const netProfit = periodRevenue - periodExpensesTotal;
  const roas = periodExpensesTotal > 0 ? (periodRevenue / periodExpensesTotal).toFixed(1) : "0.0";

  const pendingOrders = orders.filter((o) => o.status === "pending").length;
  const inDelivery = orders.filter((o) => o.status === "shipped").length;

  // Prepare chart data
  const revenueChartData = useMemo(() => {
    const dataMap = new Map<string, number>();
    periodOrders.forEach((order) => {
      const date = new Date(order.created_at).toISOString().split("T")[0];
      const current = dataMap.get(date) || 0;
      dataMap.set(date, current + convertAmount(order.total_amount, order.currency));
    });
    return Array.from(dataMap.entries())
      .map(([date, revenue]) => ({ date, revenue }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [periodOrders, convertAmount]);

  const roasChartData = useMemo(() => {
    const dataMap = new Map<string, { revenue: number; expenses: number }>();
    
    periodOrders.forEach((order) => {
      const date = new Date(order.created_at).toISOString().split("T")[0];
      const current = dataMap.get(date) || { revenue: 0, expenses: 0 };
      current.revenue += convertAmount(order.total_amount, order.currency);
      dataMap.set(date, current);
    });

    periodExpenses.forEach((expense) => {
      const date = new Date(expense.date).toISOString().split("T")[0];
      const current = dataMap.get(date) || { revenue: 0, expenses: 0 };
      current.expenses += convertAmount(expense.amount, expense.currency);
      dataMap.set(date, current);
    });

    return Array.from(dataMap.entries())
      .map(([date, data]) => ({
        date,
        roas: data.expenses > 0 ? data.revenue / data.expenses : 0,
      }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [periodOrders, periodExpenses, convertAmount]);

  const ordersStatusData = useMemo(() => {
    const statusCounts = orders.reduce((acc, order) => {
      acc[order.status] = (acc[order.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(statusCounts).map(([status, count]) => ({
      status,
      count,
    }));
  }, [orders]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6 animate-fade-in">
      {/* Header with gradient background */}
      <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent p-4 sm:p-6 md:p-8 border border-primary/10">
        <div className="absolute inset-0 bg-grid-white/5 [mask-image:linear-gradient(0deg,transparent,black)]" />
        <div className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Tableau de bord
            </h1>
            <p className="text-muted-foreground mt-1 sm:mt-2 text-sm sm:text-base md:text-lg">
              Vue d'ensemble de votre activité
            </p>
          </div>
          <div className="w-full sm:w-auto">
            <PeriodSelector value={period} onChange={setPeriod} />
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-32 h-32 sm:w-64 sm:h-64 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-24 h-24 sm:w-48 sm:h-48 bg-primary/5 rounded-full blur-3xl" />
      </div>

      {/* Metrics Cards with enhanced styling */}
      <div className="grid gap-3 sm:gap-4 grid-cols-1 xs:grid-cols-2 lg:grid-cols-4">
        <Card className="modern-card hover-lift group border-l-4 border-l-primary/20 hover:border-l-primary transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs sm:text-sm font-medium">Revenus</CardTitle>
            <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-full bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
              <DollarSign className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl md:text-3xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              {formatAmount(periodRevenue)}
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground mt-1 flex items-center gap-1">
              <span className="font-semibold text-foreground">{periodOrders.length}</span>
              commande{periodOrders.length > 1 ? "s" : ""}
            </p>
          </CardContent>
        </Card>

        <Card className="modern-card hover-lift group border-l-4 border-l-blue-500/20 hover:border-l-blue-500 transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs sm:text-sm font-medium">Dépenses pub</CardTitle>
            <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-full bg-blue-500/10 flex items-center justify-center group-hover:scale-110 transition-transform">
              <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 text-blue-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl md:text-3xl font-bold">{formatAmount(periodExpensesTotal)}</div>
            <p className="text-xs sm:text-sm text-muted-foreground mt-1">
              <span className="font-semibold text-blue-500">ROAS: {roas}x</span>
            </p>
          </CardContent>
        </Card>

        <Card className="modern-card hover-lift group border-l-4 border-l-green-500/20 hover:border-l-green-500 transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs sm:text-sm font-medium">Bénéfice net</CardTitle>
            <div className={`h-8 w-8 sm:h-10 sm:w-10 rounded-full ${netProfit >= 0 ? 'bg-green-500/10' : 'bg-red-500/10'} flex items-center justify-center group-hover:scale-110 transition-transform`}>
              <TrendingUp className={`h-4 w-4 sm:h-5 sm:w-5 ${netProfit >= 0 ? 'text-green-500' : 'text-red-500'}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className={`text-xl sm:text-2xl md:text-3xl font-bold ${netProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
              {formatAmount(netProfit)}
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground mt-1">
              <span className={`font-semibold ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                Marge: {periodRevenue > 0 ? ((netProfit / periodRevenue) * 100).toFixed(1) : "0"}%
              </span>
            </p>
          </CardContent>
        </Card>

        <Card className="modern-card hover-lift group border-l-4 border-l-orange-500/20 hover:border-l-orange-500 transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs sm:text-sm font-medium">Commandes en attente</CardTitle>
            <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-full bg-orange-500/10 flex items-center justify-center group-hover:scale-110 transition-transform">
              <ShoppingCart className="h-4 w-4 sm:h-5 sm:w-5 text-orange-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xl sm:text-2xl md:text-3xl font-bold">{pendingOrders}</div>
            <p className="text-xs sm:text-sm text-muted-foreground mt-1">
              <span className="font-semibold text-orange-500">{inDelivery}</span> en livraison
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Daily AI Insights */}
      <DailyInsightsCard />

      {/* Charts */}
      <div className="grid gap-3 sm:gap-4 grid-cols-1 lg:grid-cols-2">
        <RevenueChart data={revenueChartData} />
        <ROASChart data={roasChartData} />
      </div>

      <OrdersStatusChart data={ordersStatusData} />

      {/* Alerts Panel */}
      <AlertsPanel />
    </div>
  );
};

export default Dashboard;
