export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      alerts: {
        Row: {
          category: string
          created_at: string
          id: string
          is_read: boolean
          message: string
          organization_id: string | null
          severity: string
          title: string
          user_id: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          organization_id?: string | null
          severity: string
          title: string
          user_id: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          organization_id?: string | null
          severity?: string
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "alerts_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      expenses: {
        Row: {
          amount: number
          category: string
          created_at: string
          created_by: string
          currency: string
          date: string
          id: string
          linked_product_id: string | null
          notes: string | null
          organization_id: string | null
          source: string | null
          title: string
          user_id: string
        }
        Insert: {
          amount: number
          category: string
          created_at?: string
          created_by: string
          currency?: string
          date: string
          id?: string
          linked_product_id?: string | null
          notes?: string | null
          organization_id?: string | null
          source?: string | null
          title: string
          user_id: string
        }
        Update: {
          amount?: number
          category?: string
          created_at?: string
          created_by?: string
          currency?: string
          date?: string
          id?: string
          linked_product_id?: string | null
          notes?: string | null
          organization_id?: string | null
          source?: string | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "expenses_linked_product_id_fkey"
            columns: ["linked_product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expenses_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      insights: {
        Row: {
          created_at: string
          critical_alert: string | null
          date: string
          id: string
          insights: Json
          language: string
          metrics: Json
          organization_id: string | null
          recommended_actions: Json | null
          summary: string
          user_id: string
        }
        Insert: {
          created_at?: string
          critical_alert?: string | null
          date: string
          id?: string
          insights: Json
          language?: string
          metrics: Json
          organization_id?: string | null
          recommended_actions?: Json | null
          summary: string
          user_id: string
        }
        Update: {
          created_at?: string
          critical_alert?: string | null
          date?: string
          id?: string
          insights?: Json
          language?: string
          metrics?: Json
          organization_id?: string | null
          recommended_actions?: Json | null
          summary?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "insights_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      member_statistics: {
        Row: {
          created_at: string | null
          id: string
          last_activity: string | null
          orders_delivered: number | null
          orders_handled: number | null
          organization_id: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          last_activity?: string | null
          orders_delivered?: number | null
          orders_handled?: number | null
          organization_id?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          last_activity?: string | null
          orders_delivered?: number | null
          orders_handled?: number | null
          organization_id?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "member_statistics_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          is_read: boolean
          message: string
          order_id: string | null
          organization_id: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          order_id?: string | null
          organization_id?: string | null
          title: string
          type?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          order_id?: string | null
          organization_id?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      order_actions: {
        Row: {
          action_type: string
          created_at: string
          description: string
          id: string
          metadata: Json | null
          order_id: string
          user_id: string
        }
        Insert: {
          action_type: string
          created_at?: string
          description: string
          id?: string
          metadata?: Json | null
          order_id: string
          user_id: string
        }
        Update: {
          action_type?: string
          created_at?: string
          description?: string
          id?: string
          metadata?: Json | null
          order_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_actions_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          assigned_to: string | null
          created_at: string
          currency: string
          customer_name: string
          gross_margin: number | null
          id: string
          logistics_cost: number | null
          net_profit: number | null
          order_id_shopify: string | null
          organization_id: string | null
          product_id: string | null
          product_variant_id: string | null
          quantity: number
          status: string
          total_amount: number
          updated_at: string
          user_id: string
        }
        Insert: {
          assigned_to?: string | null
          created_at?: string
          currency?: string
          customer_name: string
          gross_margin?: number | null
          id?: string
          logistics_cost?: number | null
          net_profit?: number | null
          order_id_shopify?: string | null
          organization_id?: string | null
          product_id?: string | null
          product_variant_id?: string | null
          quantity?: number
          status?: string
          total_amount: number
          updated_at?: string
          user_id: string
        }
        Update: {
          assigned_to?: string | null
          created_at?: string
          currency?: string
          customer_name?: string
          gross_margin?: number | null
          id?: string
          logistics_cost?: number | null
          net_profit?: number | null
          order_id_shopify?: string | null
          organization_id?: string | null
          product_id?: string | null
          product_variant_id?: string | null
          quantity?: number
          status?: string
          total_amount?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "orders_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_product_variant_id_fkey"
            columns: ["product_variant_id"]
            isOneToOne: false
            referencedRelation: "product_variants"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          country: string | null
          created_at: string | null
          currency: string | null
          email: string
          id: string
          is_active: boolean | null
          name: string
          phone: string | null
          shop_domain: string | null
          updated_at: string | null
        }
        Insert: {
          country?: string | null
          created_at?: string | null
          currency?: string | null
          email: string
          id?: string
          is_active?: boolean | null
          name: string
          phone?: string | null
          shop_domain?: string | null
          updated_at?: string | null
        }
        Update: {
          country?: string | null
          created_at?: string | null
          currency?: string | null
          email?: string
          id?: string
          is_active?: boolean | null
          name?: string
          phone?: string | null
          shop_domain?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      product_variants: {
        Row: {
          color: string | null
          cost_price: number
          created_at: string
          custom_attributes: Json | null
          external_source: string | null
          external_variant_id: string | null
          id: string
          is_active: boolean | null
          name: string
          organization_id: string | null
          product_id: string
          sale_price: number
          shoe_size: string | null
          shopify_variant_id: string | null
          size: string | null
          sku: string | null
          stock_quantity: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          color?: string | null
          cost_price: number
          created_at?: string
          custom_attributes?: Json | null
          external_source?: string | null
          external_variant_id?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          organization_id?: string | null
          product_id: string
          sale_price: number
          shoe_size?: string | null
          shopify_variant_id?: string | null
          size?: string | null
          sku?: string | null
          stock_quantity?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          color?: string | null
          cost_price?: number
          created_at?: string
          custom_attributes?: Json | null
          external_source?: string | null
          external_variant_id?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          organization_id?: string | null
          product_id?: string
          sale_price?: number
          shoe_size?: string | null
          shopify_variant_id?: string | null
          size?: string | null
          sku?: string | null
          stock_quantity?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_variants_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_variants_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          cost_price: number
          created_at: string
          currency: string
          id: string
          image_url: string | null
          name: string
          organization_id: string | null
          sale_price: number
          shopify_id: string | null
          sku: string | null
          total_sold: number | null
          user_id: string
        }
        Insert: {
          cost_price: number
          created_at?: string
          currency?: string
          id?: string
          image_url?: string | null
          name: string
          organization_id?: string | null
          sale_price: number
          shopify_id?: string | null
          sku?: string | null
          total_sold?: number | null
          user_id: string
        }
        Update: {
          cost_price?: number
          created_at?: string
          currency?: string
          id?: string
          image_url?: string | null
          name?: string
          organization_id?: string | null
          sale_price?: number
          shopify_id?: string | null
          sku?: string | null
          total_sold?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "products_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          country: string | null
          created_at: string
          currency: string | null
          email: string
          facebook_connected: boolean | null
          full_name: string
          id: string
          is_active: boolean | null
          last_login: string | null
          organization_id: string | null
          phone: string | null
          shop_domain: string | null
          shopify_connected: boolean | null
        }
        Insert: {
          avatar_url?: string | null
          country?: string | null
          created_at?: string
          currency?: string | null
          email: string
          facebook_connected?: boolean | null
          full_name: string
          id: string
          is_active?: boolean | null
          last_login?: string | null
          organization_id?: string | null
          phone?: string | null
          shop_domain?: string | null
          shopify_connected?: boolean | null
        }
        Update: {
          avatar_url?: string | null
          country?: string | null
          created_at?: string
          currency?: string | null
          email?: string
          facebook_connected?: boolean | null
          full_name?: string
          id?: string
          is_active?: boolean | null
          last_login?: string | null
          organization_id?: string | null
          phone?: string | null
          shop_domain?: string | null
          shopify_connected?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      secure_tokens: {
        Row: {
          created_at: string | null
          id: string
          service: string
          token: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          service: string
          token: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          service?: string
          token?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          created_at: string
          end_date: string | null
          features: Json | null
          id: string
          max_orders: number | null
          max_products: number | null
          plan_type: string
          start_date: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          end_date?: string | null
          features?: Json | null
          id?: string
          max_orders?: number | null
          max_products?: number | null
          plan_type: string
          start_date?: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          end_date?: string | null
          features?: Json | null
          id?: string
          max_orders?: number | null
          max_products?: number | null
          plan_type?: string
          start_date?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      support_settings: {
        Row: {
          created_at: string | null
          id: string
          support_email: string
          support_whatsapp: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          support_email?: string
          support_whatsapp?: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          support_email?: string
          support_whatsapp?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      thresholds: {
        Row: {
          condition: string
          created_at: string
          id: string
          is_enabled: boolean
          metric_type: string
          organization_id: string | null
          threshold_value: number
          updated_at: string
          user_id: string
        }
        Insert: {
          condition: string
          created_at?: string
          id?: string
          is_enabled?: boolean
          metric_type: string
          organization_id?: string | null
          threshold_value: number
          updated_at?: string
          user_id: string
        }
        Update: {
          condition?: string
          created_at?: string
          id?: string
          is_enabled?: boolean
          metric_type?: string
          organization_id?: string | null
          threshold_value?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "thresholds_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role:
        | "admin"
        | "assistante"
        | "consultant"
        | "super_admin"
        | "livreur"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "assistante", "consultant", "super_admin", "livreur"],
    },
  },
} as const
