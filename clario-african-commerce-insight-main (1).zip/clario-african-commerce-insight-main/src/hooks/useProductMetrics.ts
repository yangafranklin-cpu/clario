import { useMemo } from "react";
import { useOrders } from "./useOrders";
import { useExpenses } from "./useExpenses";
import { useCurrency } from "@/contexts/CurrencyContext";
import { startOfMonth, endOfMonth, isWithinInterval } from "date-fns";

export function useProductMetrics(productId: string, periodStart: Date, periodEnd: Date) {
  const { orders } = useOrders();
  const { expenses } = useExpenses();
  const { convertAmount } = useCurrency();

  return useMemo(() => {
    // Filter orders for this product in the period
    const productOrders = orders.filter(
      (order) =>
        order.product_id === productId &&
        isWithinInterval(new Date(order.created_at), { start: periodStart, end: periodEnd })
    );

    // Calculate sales metrics
    const totalSales = productOrders.reduce((sum, order) => {
      return sum + convertAmount(order.total_amount, order.currency);
    }, 0);

    const totalQuantity = productOrders.reduce((sum, order) => sum + order.quantity, 0);

    const totalLogisticsCost = productOrders.reduce((sum, order) => {
      return sum + convertAmount(order.logistics_cost || 0, order.currency);
    }, 0);

    // Filter expenses linked to this product
    const linkedExpenses = expenses.filter(
      (expense) =>
        expense.linked_product_id === productId &&
        isWithinInterval(new Date(expense.date), { start: periodStart, end: periodEnd })
    );

    const totalAdSpend = linkedExpenses.reduce((sum, expense) => {
      return sum + convertAmount(expense.amount, expense.currency);
    }, 0);

    // Get monthly data for charts
    const monthlyData: { month: string; sales: number; expenses: number; profit: number }[] = [];
    
    const currentDate = new Date(periodStart);
    while (currentDate <= periodEnd) {
      const monthStart = startOfMonth(currentDate);
      const monthEnd = endOfMonth(currentDate);

      const monthOrders = productOrders.filter((order) =>
        isWithinInterval(new Date(order.created_at), { start: monthStart, end: monthEnd })
      );

      const monthExpenses = linkedExpenses.filter((expense) =>
        isWithinInterval(new Date(expense.date), { start: monthStart, end: monthEnd })
      );

      const monthSales = monthOrders.reduce((sum, order) => {
        return sum + convertAmount(order.total_amount, order.currency);
      }, 0);

      const monthAdSpend = monthExpenses.reduce((sum, expense) => {
        return sum + convertAmount(expense.amount, expense.currency);
      }, 0);

      const monthLogistics = monthOrders.reduce((sum, order) => {
        return sum + convertAmount(order.logistics_cost || 0, order.currency);
      }, 0);

      monthlyData.push({
        month: monthStart.toLocaleDateString("fr-FR", { month: "short", year: "numeric" }),
        sales: monthSales,
        expenses: monthAdSpend + monthLogistics,
        profit: monthSales - monthAdSpend - monthLogistics,
      });

      currentDate.setMonth(currentDate.getMonth() + 1);
    }

    return {
      totalSales,
      totalQuantity,
      totalAdSpend,
      totalLogisticsCost,
      netProfit: totalSales - totalAdSpend - totalLogisticsCost,
      monthlyData,
      linkedExpenses,
    };
  }, [productId, periodStart, periodEnd, orders, expenses, convertAmount]);
}
