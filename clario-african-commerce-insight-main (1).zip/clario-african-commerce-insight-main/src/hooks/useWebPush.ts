import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export function useWebPush() {
  const [permission, setPermission] = useState<NotificationPermission>("default");
  const { toast } = useToast();

  useEffect(() => {
    if ("Notification" in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = async () => {
    if (!("Notification" in window)) {
      toast({
        title: "Non supporté",
        description: "Les notifications ne sont pas supportées par ce navigateur",
        variant: "destructive",
      });
      return false;
    }

    const result = await Notification.requestPermission();
    setPermission(result);

    if (result === "granted") {
      toast({
        title: "Notifications activées",
        description: "Vous recevrez désormais des notifications",
      });
      return true;
    }

    return false;
  };

  const sendNotification = (title: string, options?: NotificationOptions) => {
    if (permission === "granted") {
      new Notification(title, options);
    }
  };

  return {
    permission,
    requestPermission,
    sendNotification,
  };
}