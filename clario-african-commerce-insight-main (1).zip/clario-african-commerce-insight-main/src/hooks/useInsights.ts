import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface Insight {
  id: string;
  user_id: string;
  organization_id: string;
  date: string;
  metrics: {
    totalSales: number;
    totalOrders: number;
    fbAdSpend: number;
    roas: number;
    roasChange: number;
    topProducts: Array<{ name: string; revenue: number; count: number }>;
    bottomProducts: Array<{ name: string; revenue: number; count: number }>;
  };
  summary: string;
  insights: string[];
  critical_alert?: string;
  recommended_actions?: string[];
  language: string;
  created_at: string;
}

export const useInsights = (limit = 7) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: insights = [], isLoading } = useQuery({
    queryKey: ["insights", limit],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insights")
        .select("*")
        .order("date", { ascending: false })
        .limit(limit);

      if (error) throw error;
      return (data || []).map(item => ({
        ...item,
        metrics: item.metrics as any,
        insights: Array.isArray(item.insights) ? item.insights : [],
        recommended_actions: Array.isArray(item.recommended_actions) ? item.recommended_actions : undefined,
      })) as Insight[];
    },
    staleTime: 5 * 60 * 1000, // 5 minutes cache
  });

  const generateInsights = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke("generate-daily-insights", {
        body: { scheduled: false },
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["insights"] });
      toast({
        title: "Insights générés",
        description: "Les insights ont été générés avec succès",
      });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible de générer les insights",
        variant: "destructive",
      });
      console.error("Error generating insights:", error);
    },
  });

  return {
    insights,
    isLoading,
    generateInsights: generateInsights.mutate,
    isGenerating: generateInsights.isPending,
  };
};