import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface Threshold {
  id: string;
  user_id: string;
  metric_type: string;
  condition: string;
  threshold_value: number;
  is_enabled: boolean;
  created_at: string;
  updated_at: string;
}

export const useThresholds = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: thresholds = [], isLoading } = useQuery({
    queryKey: ["thresholds"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("thresholds")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as Threshold[];
    },
    staleTime: 5 * 60 * 1000, // 5 minutes cache
  });

  const updateThreshold = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Threshold> & { id: string }) => {
      const { error } = await supabase
        .from("thresholds")
        .update(updates)
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["thresholds"] });
      toast({
        title: "Seuil mis à jour",
        description: "Le seuil a été modifié avec succès",
      });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible de modifier le seuil",
        variant: "destructive",
      });
      console.error("Error updating threshold:", error);
    },
  });

  const createThreshold = useMutation({
    mutationFn: async (threshold: Omit<Threshold, "id" | "created_at" | "updated_at">) => {
      const { error } = await supabase
        .from("thresholds")
        .insert(threshold);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["thresholds"] });
      toast({
        title: "Seuil créé",
        description: "Le seuil a été ajouté avec succès",
      });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible de créer le seuil",
        variant: "destructive",
      });
      console.error("Error creating threshold:", error);
    },
  });

  return {
    thresholds,
    isLoading,
    updateThreshold: updateThreshold.mutate,
    createThreshold: createThreshold.mutate,
  };
};
