import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface OrderAction {
  id: string;
  order_id: string;
  user_id: string;
  action_type: string;
  description: string;
  metadata: Record<string, any>;
  created_at: string;
}

export const useOrderActions = (orderId?: string) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: actions = [], isLoading } = useQuery({
    queryKey: ["orderActions", orderId],
    queryFn: async () => {
      if (!orderId) return [];
      
      const { data, error } = await supabase
        .from("order_actions")
        .select("*")
        .eq("order_id", orderId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as OrderAction[];
    },
    enabled: !!orderId,
  });

  const addAction = useMutation({
    mutationFn: async ({
      orderId,
      actionType,
      description,
      metadata = {},
    }: {
      orderId: string;
      actionType: string;
      description: string;
      metadata?: Record<string, any>;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { error } = await supabase.from("order_actions").insert({
        order_id: orderId,
        user_id: user.id,
        action_type: actionType,
        description,
        metadata,
      });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["orderActions"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible d'enregistrer l'action",
        variant: "destructive",
      });
      console.error("Error adding order action:", error);
    },
  });

  return {
    actions,
    isLoading,
    addAction: addAction.mutate,
  };
};