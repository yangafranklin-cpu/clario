import { z } from 'zod';

// Authentication validation schemas
export const signUpSchema = z.object({
  email: z.string()
    .trim()
    .email({ message: "Format d'email invalide" })
    .max(255, { message: "L'email ne peut pas dépasser 255 caractères" }),
  password: z.string()
    .min(8, { message: "Le mot de passe doit contenir au moins 8 caractères" })
    .max(100, { message: "Le mot de passe ne peut pas dépasser 100 caractères" })
    .regex(/[A-Z]/, { message: "Le mot de passe doit contenir au moins une majuscule" })
    .regex(/[a-z]/, { message: "Le mot de passe doit contenir au moins une minuscule" })
    .regex(/[0-9]/, { message: "Le mot de passe doit contenir au moins un chiffre" }),
  confirmPassword: z.string(),
  fullName: z.string()
    .trim()
    .min(2, { message: "Le nom doit contenir au moins 2 caractères" })
    .max(100, { message: "Le nom ne peut pas dépasser 100 caractères" })
    .regex(/^[\p{L}\s'-]+$/u, { message: "Le nom ne peut contenir que des lettres, espaces, apostrophes et tirets" }),
  shopName: z.string()
    .trim()
    .min(2, { message: "Le nom de l'entreprise doit contenir au moins 2 caractères" })
    .max(100, { message: "Le nom de l'entreprise ne peut pas dépasser 100 caractères" }),
  phone: z.string()
    .trim()
    .optional(),
  country: z.string()
    .trim()
    .optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Les mots de passe ne correspondent pas",
  path: ["confirmPassword"],
});

export const signInSchema = z.object({
  email: z.string()
    .trim()
    .email({ message: "Format d'email invalide" })
    .max(255),
  password: z.string()
    .min(1, { message: "Le mot de passe est requis" })
    .max(100),
});

// Team management validation
export const teamMemberSchema = z.object({
  email: z.string()
    .trim()
    .email({ message: "Format d'email invalide" })
    .max(255, { message: "L'email ne peut pas dépasser 255 caractères" }),
  fullName: z.string()
    .trim()
    .min(2, { message: "Le nom doit contenir au moins 2 caractères" })
    .max(100, { message: "Le nom ne peut pas dépasser 100 caractères" })
    .regex(/^[\p{L}\s'-]+$/u, { message: "Le nom ne peut contenir que des lettres, espaces, apostrophes et tirets" }),
  password: z.string()
    .min(8, { message: "Le mot de passe doit contenir au moins 8 caractères" })
    .max(100, { message: "Le mot de passe ne peut pas dépasser 100 caractères" })
    .regex(/[A-Z]/, { message: "Le mot de passe doit contenir au moins une majuscule" })
    .regex(/[a-z]/, { message: "Le mot de passe doit contenir au moins une minuscule" })
    .regex(/[0-9]/, { message: "Le mot de passe doit contenir au moins un chiffre" }),
  role: z.enum(['assistante', 'livreur'], { 
    errorMap: () => ({ message: "Le rôle doit être 'assistante' ou 'livreur'" })
  }),
});

// Order validation
export const orderSchema = z.object({
  productId: z.string()
    .uuid({ message: "ID de produit invalide" }),
  customerName: z.string()
    .trim()
    .min(1, { message: "Le nom du client est requis" })
    .max(200, { message: "Le nom du client ne peut pas dépasser 200 caractères" }),
  quantity: z.number()
    .int({ message: "La quantité doit être un nombre entier" })
    .min(1, { message: "La quantité doit être au moins 1" })
    .max(10000, { message: "La quantité ne peut pas dépasser 10000" }),
  totalAmount: z.number()
    .positive({ message: "Le montant doit être positif" })
    .max(1000000000, { message: "Le montant ne peut pas dépasser 1 milliard" }),
  logisticsCost: z.number()
    .nonnegative({ message: "Les frais de livraison ne peuvent pas être négatifs" })
    .max(1000000, { message: "Les frais de livraison ne peuvent pas dépasser 1 million" })
    .optional(),
  currency: z.string()
    .min(3)
    .max(10),
  status: z.enum(['pending', 'processing', 'shipped', 'delivered', 'cancelled']),
});

// Expense validation
export const expenseSchema = z.object({
  title: z.string()
    .trim()
    .min(1, { message: "Le titre est requis" })
    .max(200, { message: "Le titre ne peut pas dépasser 200 caractères" }),
  amount: z.number()
    .positive({ message: "Le montant doit être positif" })
    .max(1000000000, { message: "Le montant ne peut pas dépasser 1 milliard" }),
  currency: z.string()
    .min(3)
    .max(10),
  category: z.enum(['facebook_ads', 'tiktok_ads', 'influencer', 'flyer', 'shipping', 'other'], {
    errorMap: () => ({ message: "Catégorie invalide" })
  }),
  linkedProductId: z.string()
    .uuid({ message: "ID de produit invalide" })
    .optional(),
  date: z.string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, { message: "Format de date invalide (YYYY-MM-DD)" }),
  notes: z.string()
    .max(1000, { message: "Les notes ne peuvent pas dépasser 1000 caractères" })
    .optional(),
});

// Password reset validation
export const passwordResetSchema = z.object({
  email: z.string()
    .trim()
    .email({ message: "Format d'email invalide" })
    .max(255),
});

// Export type helpers
export type SignUpInput = z.infer<typeof signUpSchema>;
export type SignInInput = z.infer<typeof signInSchema>;
export type TeamMemberInput = z.infer<typeof teamMemberSchema>;
export type OrderInput = z.infer<typeof orderSchema>;
export type ExpenseInput = z.infer<typeof expenseSchema>;
export type PasswordResetInput = z.infer<typeof passwordResetSchema>;
