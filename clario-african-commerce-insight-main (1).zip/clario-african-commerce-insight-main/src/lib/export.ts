import Papa from "papaparse";

export interface ExportColumn {
  key: string;
  label: string;
  format?: (value: any) => string;
}

export interface ExportOptions {
  filename: string;
  data: any[];
  columns: ExportColumn[];
  format?: "csv" | "excel";
}

export function exportToCSV({ filename, data, columns }: ExportOptions) {
  // Prepare data with selected columns only
  const exportData = data.map((row) => {
    const formattedRow: any = {};
    columns.forEach((col) => {
      const value = row[col.key];
      formattedRow[col.label] = col.format ? col.format(value) : value;
    });
    return formattedRow;
  });

  // Convert to CSV
  const csv = Papa.unparse(exportData);

  // Download
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", `${filename}.csv`);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportToExcel({ filename, data, columns }: ExportOptions) {
  // For Excel, we'll use CSV with UTF-8 BOM for better Excel compatibility
  const exportData = data.map((row) => {
    const formattedRow: any = {};
    columns.forEach((col) => {
      const value = row[col.key];
      formattedRow[col.label] = col.format ? col.format(value) : value;
    });
    return formattedRow;
  });

  const csv = Papa.unparse(exportData);
  const BOM = "\uFEFF";
  const blob = new Blob([BOM + csv], { type: "text/csv;charset=utf-8;" });
  
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", `${filename}.xlsx`);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
