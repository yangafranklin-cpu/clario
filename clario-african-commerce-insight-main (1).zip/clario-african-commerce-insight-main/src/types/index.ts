export type Product = {
  id: string;
  user_id: string;
  shopify_id?: string;
  name: string;
  sku?: string;
  image_url?: string;
  cost_price: number;
  sale_price: number;
  currency: string;
  total_sold: number;
  created_at: string;
  gross_margin?: number; // Calculated field
  net_profit?: number; // Calculated field
};

export type ProductVariant = {
  id: string;
  product_id: string;
  user_id: string;
  shopify_variant_id?: string;
  external_variant_id?: string;
  external_source?: string;
  sku?: string;
  name: string;
  size?: string;
  color?: string;
  shoe_size?: string;
  custom_attributes?: Record<string, any>;
  cost_price: number;
  sale_price: number;
  stock_quantity: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export type Expense = {
  id: string;
  user_id: string;
  title: string;
  amount: number;
  currency: string;
  category: "facebook_ads" | "tiktok_ads" | "influencer" | "flyer" | "shipping" | "other";
  linked_product_id?: string;
  date: string;
  source: "api_facebook" | "api_tiktok" | "manual";
  created_by: string;
  created_at: string;
  notes?: string;
};

export type Order = {
  id: string;
  order_id_shopify?: string;
  user_id: string;
  product_id?: string;
  product_variant_id?: string;
  customer_name: string;
  quantity: number;
  total_amount: number;
  currency: string;
  logistics_cost?: number;
  gross_margin?: number;
  net_profit?: number;
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled";
  assigned_to?: string;
  created_at: string;
  updated_at: string;
  products?: { name: string };
  product_variants?: { name: string };
};

export type Alert = {
  id: string;
  user_id: string;
  title: string;
  message: string;
  severity: "info" | "warning" | "critical";
  category: "sales" | "expenses" | "inventory" | "performance" | "general";
  is_read: boolean;
  created_at: string;
};

export type Insight = {
  id: string;
  user_id: string;
  date: string;
  metrics: {
    totalSales: number;
    totalOrders: number;
    fbAdSpend: number;
    roas: number;
    roasChange: number;
    topProducts: Array<{ name: string; revenue: number; count: number }>;
    bottomProducts: Array<{ name: string; revenue: number; count: number }>;
  };
  summary: string;
  insights: string[];
  critical_alert?: string;
  recommended_actions?: string[];
  language: string;
  created_at: string;
};