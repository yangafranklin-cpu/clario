import React, { createContext, useContext, useState, useEffect } from "react";

type Currency = {
  code: string;
  symbol: string;
  rate: number;
};

const currencies: Currency[] = [
  { code: "FCFA", symbol: "FCFA", rate: 1 },
  { code: "USD", symbol: "$", rate: 0.0017 },
  { code: "EUR", symbol: "€", rate: 0.0015 },
  { code: "NGN", symbol: "₦", rate: 0.7 },
  { code: "GHS", symbol: "₵", rate: 0.01 },
];

type CurrencyContextType = {
  currentCurrency: Currency;
  currencies: Currency[];
  setCurrency: (code: string) => void;
  formatAmount: (amount: number) => string;
  convertAmount: (amount: number, fromCode?: string) => number;
};

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [currentCurrency, setCurrentCurrency] = useState<Currency>(() => {
    const saved = localStorage.getItem("clario-currency");
    return saved ? JSON.parse(saved) : currencies[0];
  });

  useEffect(() => {
    localStorage.setItem("clario-currency", JSON.stringify(currentCurrency));
  }, [currentCurrency]);

  const setCurrency = (code: string) => {
    const currency = currencies.find((c) => c.code === code);
    if (currency) {
      setCurrentCurrency(currency);
    }
  };

  const formatAmount = (amount: number) => {
    const converted = amount * currentCurrency.rate;
    return `${converted.toLocaleString("fr-FR", { maximumFractionDigits: 0 })} ${currentCurrency.symbol}`;
  };

  const convertAmount = (amount: number, fromCode: string = "FCFA") => {
    const fromCurrency = currencies.find((c) => c.code === fromCode);
    if (!fromCurrency) return amount;
    
    const inFCFA = amount / fromCurrency.rate;
    return inFCFA * currentCurrency.rate;
  };

  return (
    <CurrencyContext.Provider
      value={{ currentCurrency, currencies, setCurrency, formatAmount, convertAmount }}
    >
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error("useCurrency must be used within CurrencyProvider");
  }
  return context;
}
