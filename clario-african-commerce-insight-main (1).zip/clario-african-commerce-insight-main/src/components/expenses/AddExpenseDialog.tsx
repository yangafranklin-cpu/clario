import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Expense } from "@/types";
import { expenseSchema } from "@/lib/validation";
import { useToast } from "@/hooks/use-toast";

type AddExpenseDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (expense: Omit<Expense, "id" | "user_id" | "created_by" | "created_at">) => void;
  products: Array<{ id: string; name: string }>;
};

const categories = [
  { value: "facebook_ads", label: "Facebook Ads" },
  { value: "tiktok_ads", label: "TikTok Ads" },
  { value: "influencer", label: "Influenceur" },
  { value: "flyer", label: "Flyer" },
  { value: "shipping", label: "Livraison" },
  { value: "other", label: "Autre" },
];

export function AddExpenseDialog({ open, onOpenChange, onAdd, products }: AddExpenseDialogProps) {
  const { currencies } = useCurrency();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    title: "",
    amount: "",
    currency: "FCFA",
    category: "facebook_ads" as Expense["category"],
    linked_product_id: "",
    date: new Date().toISOString().split("T")[0],
    source: "manual" as Expense["source"],
    notes: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.amount) {
      return;
    }

    // Validate input
    const validation = expenseSchema.safeParse({
      title: formData.title,
      amount: parseFloat(formData.amount),
      currency: formData.currency,
      category: formData.category,
      linkedProductId: formData.linked_product_id || undefined,
      date: formData.date,
      notes: formData.notes || undefined,
    });

    if (!validation.success) {
      toast({
        variant: "destructive",
        title: "Erreur de validation",
        description: validation.error.errors[0].message,
      });
      return;
    }

    onAdd({
      title: validation.data.title,
      amount: validation.data.amount,
      currency: validation.data.currency,
      category: validation.data.category,
      linked_product_id: validation.data.linkedProductId,
      date: validation.data.date,
      source: formData.source,
      notes: validation.data.notes,
    });

    setFormData({
      title: "",
      amount: "",
      currency: "FCFA",
      category: "facebook_ads",
      linked_product_id: "",
      date: new Date().toISOString().split("T")[0],
      source: "manual",
      notes: "",
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Ajouter une dépense</DialogTitle>
          <DialogDescription>
            Enregistrez une nouvelle dépense publicitaire ou opérationnelle
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="expense-title">Titre</Label>
              <Input
                id="expense-title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Ex: Campagne Facebook Janvier"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="amount">Montant</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                placeholder="5000"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="expense-currency">Devise</Label>
              <Select
                value={formData.currency}
                onValueChange={(value) => setFormData({ ...formData, currency: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.code} ({currency.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="category">Catégorie</Label>
              <Select
                value={formData.category}
                onValueChange={(value: Expense["category"]) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {products.length > 0 && (
              <div className="grid gap-2">
                <Label htmlFor="product">Produit associé (optionnel)</Label>
                <Select
                  value={formData.linked_product_id}
                  onValueChange={(value) => setFormData({ ...formData, linked_product_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner un produit" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="grid gap-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="notes">Notes (optionnel)</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Ajoutez des notes ou commentaires..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuler
            </Button>
            <Button type="submit">Ajouter</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
