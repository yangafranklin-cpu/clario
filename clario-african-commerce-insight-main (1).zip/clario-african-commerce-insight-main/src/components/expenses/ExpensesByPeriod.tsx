import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Expense } from "@/types";
import { startOfMonth, format } from "date-fns";
import { fr } from "date-fns/locale";

interface ExpensesByPeriodProps {
  expenses: Expense[];
}

export function ExpensesByPeriod({ expenses }: ExpensesByPeriodProps) {
  const { convertAmount } = useCurrency();

  const monthlyData = useMemo(() => {
    const dataMap = new Map<string, number>();

    expenses.forEach((expense) => {
      const monthKey = format(startOfMonth(new Date(expense.date)), "yyyy-MM");
      const amount = convertAmount(expense.amount, expense.currency);
      dataMap.set(monthKey, (dataMap.get(monthKey) || 0) + amount);
    });

    return Array.from(dataMap.entries())
      .map(([month, total]) => ({
        month: format(new Date(month), "MMM yyyy", { locale: fr }),
        total,
      }))
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-6); // Last 6 months
  }, [expenses, convertAmount]);

  const chartConfig = {
    total: {
      label: "Dépenses",
      color: "hsl(var(--chart-1))",
    },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Dépenses par mois</CardTitle>
      </CardHeader>
      <CardContent>
        {monthlyData.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">Aucune donnée disponible</p>
        ) : (
          <ChartContainer config={chartConfig} className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="month" className="text-xs" />
                <YAxis className="text-xs" />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="total" fill="var(--color-total)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        )}
      </CardContent>
    </Card>
  );
}
