import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Expense } from "@/types";

interface ExpensesByCategoryProps {
  expenses: Expense[];
}

const categoryLabels: Record<Expense["category"], string> = {
  facebook_ads: "Facebook Ads",
  tiktok_ads: "TikTok Ads",
  influencer: "Influenceur",
  flyer: "Flyer",
  shipping: "Livraison",
  other: "Autre",
};

const categoryColors: Record<Expense["category"], string> = {
  facebook_ads: "bg-blue-500",
  tiktok_ads: "bg-purple-500",
  influencer: "bg-pink-500",
  flyer: "bg-green-500",
  shipping: "bg-orange-500",
  other: "bg-gray-500",
};

export function ExpensesByCategory({ expenses }: ExpensesByCategoryProps) {
  const { formatAmount, convertAmount } = useCurrency();

  const categoryStats = useMemo(() => {
    const stats: Record<
      Expense["category"],
      { total: number; count: number; percentage: number }
    > = {
      facebook_ads: { total: 0, count: 0, percentage: 0 },
      tiktok_ads: { total: 0, count: 0, percentage: 0 },
      influencer: { total: 0, count: 0, percentage: 0 },
      flyer: { total: 0, count: 0, percentage: 0 },
      shipping: { total: 0, count: 0, percentage: 0 },
      other: { total: 0, count: 0, percentage: 0 },
    };

    const totalExpenses = expenses.reduce((sum, expense) => {
      return sum + convertAmount(expense.amount, expense.currency);
    }, 0);

    expenses.forEach((expense) => {
      const amount = convertAmount(expense.amount, expense.currency);
      stats[expense.category].total += amount;
      stats[expense.category].count += 1;
    });

    // Calculate percentages
    Object.keys(stats).forEach((category) => {
      const cat = category as Expense["category"];
      stats[cat].percentage =
        totalExpenses > 0 ? (stats[cat].total / totalExpenses) * 100 : 0;
    });

    return { stats, totalExpenses };
  }, [expenses, convertAmount]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Dépenses par catégorie</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {Object.entries(categoryStats.stats)
          .filter(([_, data]) => data.count > 0)
          .sort(([_, a], [__, b]) => b.total - a.total)
          .map(([category, data]) => {
            const cat = category as Expense["category"];
            return (
              <div key={category} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${categoryColors[cat]}`} />
                    <span className="font-medium">{categoryLabels[cat]}</span>
                    <Badge variant="secondary">{data.count}</Badge>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{formatAmount(data.total)}</div>
                    <div className="text-xs text-muted-foreground">
                      {data.percentage.toFixed(1)}%
                    </div>
                  </div>
                </div>
                <Progress value={data.percentage} className="h-2" />
              </div>
            );
          })}

        {expenses.length === 0 && (
          <p className="text-muted-foreground text-center py-4">Aucune dépense enregistrée</p>
        )}
      </CardContent>
    </Card>
  );
}
