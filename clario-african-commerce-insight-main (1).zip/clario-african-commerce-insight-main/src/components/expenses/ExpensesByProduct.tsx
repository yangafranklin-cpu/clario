import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Expense, Product } from "@/types";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Eye } from "lucide-react";

interface ExpensesByProductProps {
  expenses: Expense[];
  products: Product[];
}

export function ExpensesByProduct({ expenses, products }: ExpensesByProductProps) {
  const { formatAmount, convertAmount } = useCurrency();
  const navigate = useNavigate();

  const productStats = useMemo(() => {
    const stats: Record<string, { name: string; total: number; count: number }> = {};

    expenses.forEach((expense) => {
      if (expense.linked_product_id) {
        if (!stats[expense.linked_product_id]) {
          const product = products.find((p) => p.id === expense.linked_product_id);
          stats[expense.linked_product_id] = {
            name: product?.name || "Produit inconnu",
            total: 0,
            count: 0,
          };
        }
        stats[expense.linked_product_id].total += convertAmount(
          expense.amount,
          expense.currency
        );
        stats[expense.linked_product_id].count += 1;
      }
    });

    return Object.entries(stats)
      .map(([id, data]) => ({ id, ...data }))
      .sort((a, b) => b.total - a.total);
  }, [expenses, products, convertAmount]);

  const unlinkedExpenses = expenses.filter((e) => !e.linked_product_id);
  const unlinkedTotal = unlinkedExpenses.reduce(
    (sum, e) => sum + convertAmount(e.amount, e.currency),
    0
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle>Dépenses par produit</CardTitle>
      </CardHeader>
      <CardContent>
        {productStats.length === 0 && unlinkedExpenses.length === 0 ? (
          <p className="text-muted-foreground text-center py-4">Aucune dépense enregistrée</p>
        ) : (
          <div className="space-y-3">
            {productStats.map((stat) => (
              <div
                key={stat.id}
                className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="flex-1">
                  <div className="font-medium">{stat.name}</div>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="secondary">{stat.count} dépense(s)</Badge>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="font-semibold">{formatAmount(stat.total)}</div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => navigate(`/products/${stat.id}`)}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}

            {unlinkedExpenses.length > 0 && (
              <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
                <div className="flex-1">
                  <div className="font-medium text-muted-foreground">Non liées à un produit</div>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline">{unlinkedExpenses.length} dépense(s)</Badge>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">{formatAmount(unlinkedTotal)}</div>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
