import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useExpenses } from "@/hooks/useExpenses";
import { useCurrency } from "@/contexts/CurrencyContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

interface LinkExpenseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  productId: string;
}

export function LinkExpenseDialog({ open, onOpenChange, productId }: LinkExpenseDialogProps) {
  const { expenses, addExpense } = useExpenses();
  const { currentCurrency } = useCurrency();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedExpenseId, setSelectedExpenseId] = useState<string>("");
  const [newExpense, setNewExpense] = useState({
    title: "",
    amount: "",
    category: "facebook_ads" as const,
    date: new Date().toISOString().split("T")[0],
  });

  const unlinkedExpenses = expenses.filter((expense) => !expense.linked_product_id);

  const handleLinkExisting = async () => {
    if (!selectedExpenseId) return;

    try {
      const { error } = await supabase
        .from("expenses")
        .update({ linked_product_id: productId })
        .eq("id", selectedExpenseId);

      if (error) throw error;

      queryClient.invalidateQueries({ queryKey: ["expenses"] });
      toast({
        title: "Dépense liée",
        description: "La dépense a été liée au produit avec succès.",
      });
      onOpenChange(false);
      setSelectedExpenseId("");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: error instanceof Error ? error.message : "Une erreur est survenue",
      });
    }
  };

  const handleCreateLinked = async () => {
    if (!newExpense.title || !newExpense.amount) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Veuillez remplir tous les champs requis.",
      });
      return;
    }

    addExpense({
      title: newExpense.title,
      amount: parseFloat(newExpense.amount),
      currency: currentCurrency.code,
      category: newExpense.category,
      date: newExpense.date,
      source: "manual",
      linked_product_id: productId,
    });

    onOpenChange(false);
    setNewExpense({
      title: "",
      amount: "",
      category: "facebook_ads",
      date: new Date().toISOString().split("T")[0],
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Lier une dépense au produit</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="existing" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="existing">Dépense existante</TabsTrigger>
            <TabsTrigger value="new">Nouvelle dépense</TabsTrigger>
          </TabsList>

          <TabsContent value="existing" className="space-y-4">
            <div className="space-y-2">
              <Label>Sélectionner une dépense</Label>
              {unlinkedExpenses.length === 0 ? (
                <p className="text-sm text-muted-foreground">Aucune dépense disponible à lier.</p>
              ) : (
                <Select value={selectedExpenseId} onValueChange={setSelectedExpenseId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choisir une dépense" />
                  </SelectTrigger>
                  <SelectContent>
                    {unlinkedExpenses.map((expense) => (
                      <SelectItem key={expense.id} value={expense.id}>
                        {expense.title} - {expense.amount} {expense.currency} ({expense.category})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>

            <DialogFooter>
              <Button onClick={handleLinkExisting} disabled={!selectedExpenseId}>
                Lier la dépense
              </Button>
            </DialogFooter>
          </TabsContent>

          <TabsContent value="new" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Titre *</Label>
              <Input
                id="title"
                value={newExpense.title}
                onChange={(e) => setNewExpense({ ...newExpense, title: e.target.value })}
                placeholder="Ex: Campagne Facebook"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Montant *</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                value={newExpense.amount}
                onChange={(e) => setNewExpense({ ...newExpense, amount: e.target.value })}
                placeholder="0.00"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Catégorie</Label>
              <Select
                value={newExpense.category}
                onValueChange={(value: any) => setNewExpense({ ...newExpense, category: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="facebook_ads">Facebook Ads</SelectItem>
                  <SelectItem value="tiktok_ads">TikTok Ads</SelectItem>
                  <SelectItem value="influencer">Influenceur</SelectItem>
                  <SelectItem value="flyer">Flyers</SelectItem>
                  <SelectItem value="shipping">Livraison</SelectItem>
                  <SelectItem value="other">Autre</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={newExpense.date}
                onChange={(e) => setNewExpense({ ...newExpense, date: e.target.value })}
              />
            </div>

            <DialogFooter>
              <Button onClick={handleCreateLinked}>Créer et lier</Button>
            </DialogFooter>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
