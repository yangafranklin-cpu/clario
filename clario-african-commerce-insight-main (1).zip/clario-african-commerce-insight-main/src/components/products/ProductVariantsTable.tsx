import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trash2, ExternalLink } from "lucide-react";
import { ProductVariant } from "@/types";
import { useCurrency } from "@/contexts/CurrencyContext";

type ProductVariantsTableProps = {
  variants: ProductVariant[];
  onDelete: (variantId: string) => void;
};

export function ProductVariantsTable({ variants, onDelete }: ProductVariantsTableProps) {
  const { formatAmount, convertAmount } = useCurrency();

  if (variants.length === 0) {
    return (
      <p className="text-muted-foreground text-center py-4 text-sm">
        Aucune variante pour ce produit
      </p>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Nom</TableHead>
          <TableHead>Attributs</TableHead>
          <TableHead>Prix</TableHead>
          <TableHead>Stock</TableHead>
          <TableHead>Liaison</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {variants.map((variant) => (
          <TableRow key={variant.id}>
            <TableCell className="font-medium">
              <div>
                <div>{variant.name}</div>
                {variant.sku && (
                  <div className="text-xs text-muted-foreground">SKU: {variant.sku}</div>
                )}
              </div>
            </TableCell>
            <TableCell>
              <div className="flex flex-wrap gap-1">
                {variant.size && <Badge variant="outline">Taille: {variant.size}</Badge>}
                {variant.color && <Badge variant="outline">Couleur: {variant.color}</Badge>}
                {variant.shoe_size && <Badge variant="outline">Pointure: {variant.shoe_size}</Badge>}
              </div>
            </TableCell>
            <TableCell>
              <div className="text-sm">
                <div>{formatAmount(convertAmount(variant.sale_price, "FCFA"))}</div>
                <div className="text-xs text-muted-foreground">
                  Coût: {formatAmount(convertAmount(variant.cost_price, "FCFA"))}
                </div>
              </div>
            </TableCell>
            <TableCell>
              <Badge variant={variant.stock_quantity > 0 ? "default" : "destructive"}>
                {variant.stock_quantity}
              </Badge>
            </TableCell>
            <TableCell>
              {variant.shopify_variant_id && (
                <div className="flex items-center gap-1 text-xs">
                  <Badge variant="secondary">Shopify</Badge>
                  <ExternalLink className="h-3 w-3" />
                </div>
              )}
              {variant.external_source && !variant.shopify_variant_id && (
                <div className="flex items-center gap-1 text-xs">
                  <Badge variant="secondary">{variant.external_source}</Badge>
                  <ExternalLink className="h-3 w-3" />
                </div>
              )}
              {!variant.shopify_variant_id && !variant.external_source && (
                <span className="text-xs text-muted-foreground">-</span>
              )}
            </TableCell>
            <TableCell className="text-right">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onDelete(variant.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
