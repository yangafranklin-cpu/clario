import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCurrency } from "@/contexts/CurrencyContext";

type AddProductDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (productData: {
    name: string;
    sku?: string;
    cost_price: number;
    sale_price: number;
    currency: string;
    total_sold: number;
  }) => void;
};

export function AddProductDialog({ open, onOpenChange, onAdd }: AddProductDialogProps) {
  const { currencies } = useCurrency();
  const [formData, setFormData] = useState({
    name: "",
    sku: "",
    sale_price: "",
    cost_price: "",
    currency: "FCFA",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.sale_price || !formData.cost_price) {
      return;
    }

    onAdd({
      name: formData.name,
      sku: formData.sku || undefined,
      sale_price: parseFloat(formData.sale_price),
      cost_price: parseFloat(formData.cost_price),
      currency: formData.currency,
      total_sold: 0,
    });

    setFormData({ name: "", sku: "", sale_price: "", cost_price: "", currency: "FCFA" });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Ajouter un produit</DialogTitle>
          <DialogDescription>
            Ajoutez un nouveau produit à votre catalogue
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nom du produit</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Ex: T-shirt Nike"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="sku">SKU (optionnel)</Label>
              <Input
                id="sku"
                value={formData.sku}
                onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                placeholder="Ex: TSH-001"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="sale_price">Prix de vente</Label>
              <Input
                id="sale_price"
                type="number"
                step="0.01"
                value={formData.sale_price}
                onChange={(e) => setFormData({ ...formData, sale_price: e.target.value })}
                placeholder="15000"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="cost_price">Coût d'achat</Label>
              <Input
                id="cost_price"
                type="number"
                step="0.01"
                value={formData.cost_price}
                onChange={(e) => setFormData({ ...formData, cost_price: e.target.value })}
                placeholder="8000"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="currency">Devise</Label>
              <Select
                value={formData.currency}
                onValueChange={(value) => setFormData({ ...formData, currency: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.code} ({currency.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuler
            </Button>
            <Button type="submit">Ajouter</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
