import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCurrency } from "@/contexts/CurrencyContext";

type AddVariantDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  productId: string;
  onAdd: (variantData: {
    product_id: string;
    name: string;
    sku?: string;
    size?: string;
    color?: string;
    shoe_size?: string;
    shopify_variant_id?: string;
    external_variant_id?: string;
    external_source?: string;
    cost_price: number;
    sale_price: number;
    stock_quantity: number;
    is_active: boolean;
  }) => void;
};

export function AddVariantDialog({ open, onOpenChange, productId, onAdd }: AddVariantDialogProps) {
  const { currencies } = useCurrency();
  const [formData, setFormData] = useState({
    name: "",
    sku: "",
    size: "",
    color: "",
    shoe_size: "",
    shopify_variant_id: "",
    external_variant_id: "",
    external_source: "",
    sale_price: "",
    cost_price: "",
    stock_quantity: "0",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.sale_price || !formData.cost_price) {
      return;
    }

    onAdd({
      product_id: productId,
      name: formData.name,
      sku: formData.sku || undefined,
      size: formData.size || undefined,
      color: formData.color || undefined,
      shoe_size: formData.shoe_size || undefined,
      shopify_variant_id: formData.shopify_variant_id || undefined,
      external_variant_id: formData.external_variant_id || undefined,
      external_source: formData.external_source || undefined,
      sale_price: parseFloat(formData.sale_price),
      cost_price: parseFloat(formData.cost_price),
      stock_quantity: parseInt(formData.stock_quantity),
      is_active: true,
    });

    setFormData({ 
      name: "", 
      sku: "", 
      size: "", 
      color: "", 
      shoe_size: "",
      shopify_variant_id: "",
      external_variant_id: "",
      external_source: "",
      sale_price: "", 
      cost_price: "", 
      stock_quantity: "0" 
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Ajouter une variante</DialogTitle>
          <DialogDescription>
            Ajoutez une nouvelle variante du produit (taille, couleur, etc.)
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nom de la variante *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Ex: T-shirt Nike Bleu - L"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="size">Taille</Label>
                <Input
                  id="size"
                  value={formData.size}
                  onChange={(e) => setFormData({ ...formData, size: e.target.value })}
                  placeholder="Ex: L, XL, M"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="color">Couleur</Label>
                <Input
                  id="color"
                  value={formData.color}
                  onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                  placeholder="Ex: Bleu, Rouge"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="shoe_size">Pointure</Label>
                <Input
                  id="shoe_size"
                  value={formData.shoe_size}
                  onChange={(e) => setFormData({ ...formData, shoe_size: e.target.value })}
                  placeholder="Ex: 42, 43"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="sku">SKU</Label>
                <Input
                  id="sku"
                  value={formData.sku}
                  onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                  placeholder="Ex: TSH-BL-L"
                />
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="shopify_variant_id">ID Variante Shopify</Label>
              <Input
                id="shopify_variant_id"
                value={formData.shopify_variant_id}
                onChange={(e) => setFormData({ ...formData, shopify_variant_id: e.target.value })}
                placeholder="ID de la variante sur Shopify"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="external_source">Source externe</Label>
                <Select
                  value={formData.external_source}
                  onValueChange={(value) => setFormData({ ...formData, external_source: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choisir..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="shopify">Shopify</SelectItem>
                    <SelectItem value="woocommerce">WooCommerce</SelectItem>
                    <SelectItem value="prestashop">PrestaShop</SelectItem>
                    <SelectItem value="other">Autre</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="external_variant_id">ID externe</Label>
                <Input
                  id="external_variant_id"
                  value={formData.external_variant_id}
                  onChange={(e) => setFormData({ ...formData, external_variant_id: e.target.value })}
                  placeholder="ID sur plateforme externe"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="sale_price">Prix vente *</Label>
                <Input
                  id="sale_price"
                  type="number"
                  step="0.01"
                  value={formData.sale_price}
                  onChange={(e) => setFormData({ ...formData, sale_price: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="cost_price">Coût *</Label>
                <Input
                  id="cost_price"
                  type="number"
                  step="0.01"
                  value={formData.cost_price}
                  onChange={(e) => setFormData({ ...formData, cost_price: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="stock_quantity">Stock</Label>
                <Input
                  id="stock_quantity"
                  type="number"
                  value={formData.stock_quantity}
                  onChange={(e) => setFormData({ ...formData, stock_quantity: e.target.value })}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuler
            </Button>
            <Button type="submit">Ajouter</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
