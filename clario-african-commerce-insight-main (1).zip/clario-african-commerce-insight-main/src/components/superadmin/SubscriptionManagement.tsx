import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2, Plus, Search, Filter, Download, CreditCard } from "lucide-react";
import { motion } from "framer-motion";

type Subscription = {
  id: string;
  user_id: string;
  plan_type: string;
  status: string;
  start_date: string;
  end_date: string | null;
  max_products: number | null;
  max_orders: number | null;
  profile?: {
    full_name: string;
    email: string;
  };
};

interface SubscriptionManagementProps {
  onUpdate: () => void;
}

export function SubscriptionManagement({ onUpdate }: SubscriptionManagementProps) {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [filteredSubs, setFilteredSubs] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSub, setEditingSub] = useState<Subscription | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  useEffect(() => {
    fetchSubscriptions();
  }, []);

  const fetchSubscriptions = async () => {
    try {
      setLoading(true);
      
      const { data: subs, error: subsError } = await supabase
        .from("subscriptions")
        .select("*")
        .order("created_at", { ascending: false });

      if (subsError) throw subsError;

      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("id, full_name, email");

      if (profilesError) throw profilesError;

      const subsWithProfiles = subs?.map(sub => ({
        ...sub,
        profile: profiles?.find(p => p.id === sub.user_id),
      })) || [];

      setSubscriptions(subsWithProfiles);
      setFilteredSubs(subsWithProfiles);
    } catch (error) {
      console.error("Error fetching subscriptions:", error);
      toast.error("Erreur lors du chargement des forfaits");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let filtered = subscriptions;

    if (searchTerm) {
      filtered = filtered.filter(sub =>
        sub.profile?.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sub.profile?.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(sub => sub.status === statusFilter);
    }

    setFilteredSubs(filtered);
  }, [searchTerm, statusFilter, subscriptions]);

  const updateSubscription = async (subId: string, updates: Partial<Subscription>) => {
    try {
      const { error } = await supabase
        .from("subscriptions")
        .update(updates)
        .eq("id", subId);

      if (error) throw error;

      toast.success("Forfait mis à jour avec succès");
      fetchSubscriptions();
      onUpdate();
      setDialogOpen(false);
      setEditingSub(null);
    } catch (error) {
      console.error("Error updating subscription:", error);
      toast.error("Erreur lors de la mise à jour du forfait");
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      active: "default",
      inactive: "secondary",
      suspended: "destructive",
      cancelled: "secondary",
    };
    return variants[status] || "secondary";
  };

  const getPlanBadge = (plan: string) => {
    const colors: Record<string, string> = {
      free: "bg-gray-500",
      starter: "bg-blue-500",
      professional: "bg-purple-500",
      enterprise: "bg-amber-500",
    };
    return colors[plan] || "bg-gray-500";
  };

  if (loading) {
    return (
      <Card className="border-accent/20">
        <CardContent className="flex items-center justify-center p-12">
          <div className="text-center space-y-4">
            <Loader2 className="h-12 w-12 animate-spin text-accent-foreground mx-auto" />
            <p className="text-sm text-muted-foreground">Chargement des forfaits...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-accent/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-accent-foreground" />
              <CardTitle>Gestion des Forfaits</CardTitle>
            </div>
            <CardDescription>
              Gérez les {subscriptions.length} abonnements et plans des utilisateurs
            </CardDescription>
          </div>
          <Button variant="outline" size="sm" className="gap-2">
            <Download className="h-4 w-4" />
            Exporter
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mt-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Rechercher par nom ou email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filtrer par statut" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les statuts</SelectItem>
              <SelectItem value="active">Actif</SelectItem>
              <SelectItem value="inactive">Inactif</SelectItem>
              <SelectItem value="suspended">Suspendu</SelectItem>
              <SelectItem value="cancelled">Annulé</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="p-0">{filteredSubs.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-12 text-center">
            <CreditCard className="h-12 w-12 text-muted-foreground/50 mb-4" />
            <h3 className="font-semibold text-lg mb-2">Aucun forfait trouvé</h3>
            <p className="text-sm text-muted-foreground">
              Essayez de modifier vos filtres de recherche
            </p>
          </div>
        ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="font-semibold">Utilisateur</TableHead>
                <TableHead className="font-semibold">Email</TableHead>
                <TableHead className="font-semibold">Plan</TableHead>
                <TableHead className="font-semibold">Statut</TableHead>
                <TableHead className="font-semibold">Limites</TableHead>
                <TableHead className="font-semibold">Date début</TableHead>
                <TableHead className="font-semibold">Date fin</TableHead>
                <TableHead className="font-semibold text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSubs.map((sub, index) => (
                <motion.tr
                  key={sub.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className="border-b transition-colors hover:bg-muted/50"
                >
                  <TableCell className="font-medium">
                    {sub.profile?.full_name || "-"}
                  </TableCell>
                  <TableCell className="text-muted-foreground">{sub.profile?.email || "-"}</TableCell>
                  <TableCell>
                    <Badge className={getPlanBadge(sub.plan_type)}>
                      {sub.plan_type}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadge(sub.status)}>
                      {sub.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <div>Produits: {sub.max_products || "∞"}</div>
                      <div>Commandes: {sub.max_orders || "∞"}</div>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">
                    {new Date(sub.start_date).toLocaleDateString("fr-FR")}
                  </TableCell>
                  <TableCell className="text-sm">
                    {sub.end_date
                      ? new Date(sub.end_date).toLocaleDateString("fr-FR")
                      : "-"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Dialog open={dialogOpen && editingSub?.id === sub.id} onOpenChange={setDialogOpen}>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setEditingSub(sub)}
                          className="gap-2"
                        >
                          Modifier
                        </Button>
                      </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Modifier le forfait</DialogTitle>
                        <DialogDescription>
                          Modifiez les paramètres du forfait de l'utilisateur
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>Plan</Label>
                          <Select
                            defaultValue={sub.plan_type}
                            onValueChange={(value) =>
                              setEditingSub(prev => prev ? {...prev, plan_type: value} : null)
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="free">Gratuit</SelectItem>
                              <SelectItem value="starter">Starter</SelectItem>
                              <SelectItem value="professional">Professional</SelectItem>
                              <SelectItem value="enterprise">Enterprise</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Statut</Label>
                          <Select
                            defaultValue={sub.status}
                            onValueChange={(value) =>
                              setEditingSub(prev => prev ? {...prev, status: value} : null)
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="active">Actif</SelectItem>
                              <SelectItem value="inactive">Inactif</SelectItem>
                              <SelectItem value="suspended">Suspendu</SelectItem>
                              <SelectItem value="cancelled">Annulé</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Max Produits</Label>
                          <Input
                            type="number"
                            defaultValue={sub.max_products || ""}
                            placeholder="Illimité si vide"
                            onChange={(e) =>
                              setEditingSub(prev => prev ? {...prev, max_products: e.target.value ? parseInt(e.target.value) : null} : null)
                            }
                          />
                        </div>
                        <div>
                          <Label>Max Commandes</Label>
                          <Input
                            type="number"
                            defaultValue={sub.max_orders || ""}
                            placeholder="Illimité si vide"
                            onChange={(e) =>
                              setEditingSub(prev => prev ? {...prev, max_orders: e.target.value ? parseInt(e.target.value) : null} : null)
                            }
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button
                          onClick={() => {
                            if (editingSub) {
                              updateSubscription(sub.id, editingSub);
                            }
                          }}
                        >
                          Enregistrer
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                  </TableCell>
                </motion.tr>
              ))}
            </TableBody>
          </Table>
        </div>
        )}
      </CardContent>
    </Card>
  );
}
