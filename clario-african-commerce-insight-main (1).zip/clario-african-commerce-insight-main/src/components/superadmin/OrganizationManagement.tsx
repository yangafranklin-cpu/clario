import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, Loader2, Building2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

interface Organization {
  id: string;
  name: string;
  email: string;
  phone?: string;
  shop_domain?: string;
  country?: string;
  currency: string;
  is_active: boolean;
  created_at: string;
  user_count?: number;
}

interface OrganizationManagementProps {
  onUpdate?: () => void;
}

export const OrganizationManagement = ({ onUpdate }: OrganizationManagementProps) => {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingOrg, setEditingOrg] = useState<Organization | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    shop_domain: "",
    country: "",
    currency: "FCFA",
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchOrganizations();
  }, []);

  const fetchOrganizations = async () => {
    setLoading(true);
    try {
      const { data: orgsData, error: orgsError } = await supabase
        .from("organizations")
        .select("*")
        .order("created_at", { ascending: false });

      if (orgsError) throw orgsError;

      // Get user counts for each organization
      const orgsWithCounts = await Promise.all(
        (orgsData || []).map(async (org) => {
          const { count } = await supabase
            .from("profiles")
            .select("*", { count: "exact", head: true })
            .eq("organization_id", org.id);
          
          return { ...org, user_count: count || 0 };
        })
      );

      setOrganizations(orgsWithCounts);
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    try {
      if (editingOrg) {
        const { error } = await supabase
          .from("organizations")
          .update(formData)
          .eq("id", editingOrg.id);

        if (error) throw error;
        toast({ title: "Organisation mise à jour" });
      } else {
        const { error } = await supabase
          .from("organizations")
          .insert([formData]);

        if (error) throw error;
        toast({ title: "Organisation créée" });
      }

      setDialogOpen(false);
      setEditingOrg(null);
      setFormData({
        name: "",
        email: "",
        phone: "",
        shop_domain: "",
        country: "",
        currency: "FCFA",
      });
      fetchOrganizations();
      onUpdate?.();
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleEdit = (org: Organization) => {
    setEditingOrg(org);
    setFormData({
      name: org.name,
      email: org.email,
      phone: org.phone || "",
      shop_domain: org.shop_domain || "",
      country: org.country || "",
      currency: org.currency,
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer cette organisation ?")) return;

    try {
      const { error } = await supabase
        .from("organizations")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast({ title: "Organisation supprimée" });
      fetchOrganizations();
      onUpdate?.();
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const toggleActive = async (org: Organization) => {
    try {
      const { error } = await supabase
        .from("organizations")
        .update({ is_active: !org.is_active })
        .eq("id", org.id);

      if (error) throw error;
      toast({ 
        title: org.is_active ? "Organisation désactivée" : "Organisation activée" 
      });
      fetchOrganizations();
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                Gestion des Organisations
              </CardTitle>
              <CardDescription>
                Gérez les entreprises et leurs informations
              </CardDescription>
            </div>
            <Button onClick={() => {
              setEditingOrg(null);
              setFormData({
                name: "",
                email: "",
                phone: "",
                shop_domain: "",
                country: "",
                currency: "FCFA",
              });
              setDialogOpen(true);
            }}>
              <Plus className="mr-2 h-4 w-4" />
              Nouvelle Organisation
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nom</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Téléphone</TableHead>
                <TableHead>Utilisateurs</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {organizations.map((org) => (
                <TableRow key={org.id}>
                  <TableCell className="font-medium">{org.name}</TableCell>
                  <TableCell>{org.email}</TableCell>
                  <TableCell>{org.phone || "-"}</TableCell>
                  <TableCell>{org.user_count || 0}</TableCell>
                  <TableCell>
                    <Badge 
                      variant={org.is_active ? "default" : "secondary"}
                      className="cursor-pointer"
                      onClick={() => toggleActive(org)}
                    >
                      {org.is_active ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(org)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(org.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingOrg ? "Modifier l'Organisation" : "Nouvelle Organisation"}
            </DialogTitle>
            <DialogDescription>
              Remplissez les informations de l'organisation
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Nom *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Nom de l'entreprise"
              />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="contact@entreprise.com"
              />
            </div>
            <div>
              <Label htmlFor="phone">Téléphone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+221 XX XXX XX XX"
              />
            </div>
            <div>
              <Label htmlFor="shop_domain">Domaine Shopify</Label>
              <Input
                id="shop_domain"
                value={formData.shop_domain}
                onChange={(e) => setFormData({ ...formData, shop_domain: e.target.value })}
                placeholder="monshop.myshopify.com"
              />
            </div>
            <div>
              <Label htmlFor="country">Pays</Label>
              <Input
                id="country"
                value={formData.country}
                onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                placeholder="Sénégal"
              />
            </div>
            <div>
              <Label htmlFor="currency">Devise</Label>
              <Input
                id="currency"
                value={formData.currency}
                onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                placeholder="FCFA"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Annuler
            </Button>
            <Button onClick={handleSubmit} disabled={!formData.name || !formData.email}>
              {editingOrg ? "Mettre à jour" : "Créer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
