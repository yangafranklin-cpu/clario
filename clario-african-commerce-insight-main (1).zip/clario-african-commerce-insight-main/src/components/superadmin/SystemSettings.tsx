import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { Palette, Bell, Database, Shield, Users, Save } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

const rolePermissions = [
  {
    role: "super_admin",
    label: "Super Admin",
    permissions: ["Tous les accès", "Gestion des utilisateurs", "Gestion des forfaits", "Paramètres système"],
  },
  {
    role: "admin",
    label: "Admin (Propriétaire)",
    permissions: ["Gestion complète de sa boutique", "Ajout de collaborateurs", "Toutes les données"],
  },
  {
    role: "assistante",
    label: "Assistant(e)",
    permissions: ["Gestion des commandes", "Gestion des dépenses", "Consultation des produits"],
  },
  {
    role: "livreur",
    label: "Livreur",
    permissions: ["Consultation des commandes", "Mise à jour statut livraison"],
  },
  {
    role: "consultant",
    label: "Consultant",
    permissions: ["Consultation uniquement", "Pas de modification"],
  },
];

export function SystemSettings() {
  const handleSaveSettings = () => {
    toast.success("Paramètres système enregistrés");
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="border-primary/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              <CardTitle>Rôles et Permissions</CardTitle>
            </div>
            <CardDescription>
              Gestion des rôles et de leurs permissions dans l'application
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="font-semibold">Rôle</TableHead>
                  <TableHead className="font-semibold">Permissions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rolePermissions.map((item, index) => (
                  <motion.tr
                    key={item.role}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="border-b transition-colors hover:bg-muted/50"
                  >
                    <TableCell className="font-medium">
                      <Badge variant={item.role === "super_admin" ? "destructive" : "default"}>
                        {item.label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {item.permissions.map((permission, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {permission}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                  </motion.tr>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card className="border-accent/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-accent-foreground" />
              <CardTitle>Apparence</CardTitle>
            </div>
            <CardDescription>
              Personnalisez l'apparence de l'application
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between p-4 rounded-lg border">
              <div>
                <Label htmlFor="dark-mode" className="text-base font-medium">Mode sombre par défaut</Label>
                <p className="text-sm text-muted-foreground mt-1">Activer le thème sombre pour tous les utilisateurs</p>
              </div>
              <Switch id="dark-mode" />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg border">
              <div>
                <Label htmlFor="custom-logo" className="text-base font-medium">Logo personnalisé</Label>
                <p className="text-sm text-muted-foreground mt-1">Télécharger un logo pour l'application</p>
              </div>
              <Input id="custom-logo" type="file" className="w-auto" />
            </div>
            <div className="space-y-2 p-4 rounded-lg border">
              <Label htmlFor="primary-color" className="text-base font-medium">Couleur primaire</Label>
              <Input id="primary-color" type="color" defaultValue="#0EA5E9" className="h-12" />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className="border-secondary/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-secondary-foreground" />
              <CardTitle>Notifications</CardTitle>
            </div>
            <CardDescription>
              Configurez les notifications système
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg border">
              <div>
                <Label htmlFor="email-notif" className="text-base font-medium">Notifications email</Label>
                <p className="text-sm text-muted-foreground mt-1">Recevoir des notifications par email</p>
              </div>
              <Switch id="email-notif" defaultChecked />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg border">
              <div>
                <Label htmlFor="push-notif" className="text-base font-medium">Notifications push</Label>
                <p className="text-sm text-muted-foreground mt-1">Notifications dans le navigateur</p>
              </div>
              <Switch id="push-notif" defaultChecked />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg border">
              <div>
                <Label htmlFor="sms-notif" className="text-base font-medium">Notifications SMS</Label>
                <p className="text-sm text-muted-foreground mt-1">Alertes par message texte</p>
              </div>
              <Switch id="sms-notif" />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Card className="border-primary/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Database className="h-5 w-5 text-primary" />
              <CardTitle>Base de données</CardTitle>
            </div>
            <CardDescription>
              Gestion et maintenance de la base de données
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg border">
              <div>
                <Label className="text-base font-medium">Sauvegarde automatique</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  Effectuer des sauvegardes quotidiennes
                </p>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator />
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1">
                <Database className="h-4 w-4 mr-2" />
                Créer une sauvegarde
              </Button>
              <Button variant="outline" className="flex-1">
                <Database className="h-4 w-4 mr-2" />
                Restaurer
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <Card className="border-destructive/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-destructive" />
              <CardTitle>Sécurité</CardTitle>
            </div>
            <CardDescription>
              Paramètres de sécurité et authentification
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg border border-destructive/20">
              <div>
                <Label className="text-base font-medium">Authentification à deux facteurs</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  Obligatoire pour tous les admins
                </p>
              </div>
              <Switch />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg border">
              <div>
                <Label className="text-base font-medium">Expiration des sessions</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  Déconnexion automatique après 24h
                </p>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator />
            <div className="space-y-2 p-4 rounded-lg border">
              <Label htmlFor="session-duration" className="text-base font-medium">Durée de session (heures)</Label>
              <Input
                id="session-duration"
                type="number"
                defaultValue={24}
                min={1}
                max={168}
                className="mt-2"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="flex justify-end"
      >
        <Button onClick={handleSaveSettings} size="lg" className="gap-2 px-8">
          <Save className="h-4 w-4" />
          Enregistrer les paramètres
        </Button>
      </motion.div>
    </div>
  );
}
