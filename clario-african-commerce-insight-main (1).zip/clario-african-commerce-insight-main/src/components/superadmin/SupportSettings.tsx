import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Save, Loader2, MessageCircle, Mail } from "lucide-react";

export const SupportSettings = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState({
    id: "",
    support_email: "",
    support_whatsapp: "",
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("support_settings")
        .select("*")
        .single();

      if (error) throw error;
      
      if (data) {
        setSettings(data);
      }
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from("support_settings")
        .update({
          support_email: settings.support_email,
          support_whatsapp: settings.support_whatsapp,
        })
        .eq("id", settings.id);

      if (error) throw error;

      toast({
        title: "Paramètres sauvegardés",
        description: "Les coordonnées de support ont été mises à jour",
      });
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Paramètres de Support</CardTitle>
        <CardDescription>
          Configurez les moyens de contact pour le support client
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="support_email" className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            Email de Support
          </Label>
          <Input
            id="support_email"
            type="email"
            value={settings.support_email}
            onChange={(e) =>
              setSettings({ ...settings, support_email: e.target.value })
            }
            placeholder="support@example.com"
          />
          <p className="text-sm text-muted-foreground">
            Les clients pourront vous contacter via cet email
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="support_whatsapp" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            Numéro WhatsApp
          </Label>
          <Input
            id="support_whatsapp"
            type="tel"
            value={settings.support_whatsapp}
            onChange={(e) =>
              setSettings({ ...settings, support_whatsapp: e.target.value })
            }
            placeholder="+221 XX XXX XX XX"
          />
          <p className="text-sm text-muted-foreground">
            Format international recommandé (ex: +221700000000)
          </p>
        </div>

        <Button onClick={handleSave} disabled={saving} className="w-full">
          {saving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sauvegarde...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Sauvegarder les paramètres
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
};
