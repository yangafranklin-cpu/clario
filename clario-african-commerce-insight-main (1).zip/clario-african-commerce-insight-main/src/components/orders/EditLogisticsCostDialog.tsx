import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { DollarSign } from "lucide-react";

interface EditLogisticsCostDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  orderId: string;
  currentCost?: number;
}

export function EditLogisticsCostDialog({
  open,
  onOpenChange,
  orderId,
  currentCost = 0,
}: EditLogisticsCostDialogProps) {
  const [cost, setCost] = useState<string>(currentCost.toString());
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateMutation = useMutation({
    mutationFn: async (newCost: number) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { error: updateError } = await supabase
        .from("orders")
        .update({ logistics_cost: newCost })
        .eq("id", orderId);

      if (updateError) throw updateError;

      // Log action
      const { error: actionError } = await supabase
        .from("order_actions")
        .insert({
          order_id: orderId,
          user_id: user.id,
          action_type: "logistics_updated",
          description: `Coût logistique modifié: ${currentCost} → ${newCost}`,
          metadata: { old_cost: currentCost, new_cost: newCost },
        });

      if (actionError) throw actionError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["orders"] });
      toast({
        title: "Succès",
        description: "Coût logistique mis à jour",
      });
      onOpenChange(false);
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour le coût",
        variant: "destructive",
      });
      console.error("Error updating logistics cost:", error);
    },
  });

  const handleUpdate = () => {
    const numCost = parseFloat(cost);
    if (isNaN(numCost) || numCost < 0) {
      toast({
        title: "Erreur",
        description: "Veuillez entrer un montant valide",
        variant: "destructive",
      });
      return;
    }
    updateMutation.mutate(numCost);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Modifier le coût logistique</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Coût logistique</Label>
            <Input
              type="number"
              step="0.01"
              min="0"
              value={cost}
              onChange={(e) => setCost(e.target.value)}
              placeholder="0.00"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuler
          </Button>
          <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
            <DollarSign className="mr-2 h-4 w-4" />
            Mettre à jour
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}