import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { UserCheck } from "lucide-react";

interface AssignOrderDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  orderId: string;
  currentAssignedTo?: string;
}

interface Assistant {
  id: string;
  full_name: string;
  email: string;
}

export function AssignOrderDialog({
  open,
  onOpenChange,
  orderId,
  currentAssignedTo,
}: AssignOrderDialogProps) {
  const [selectedAssistant, setSelectedAssistant] = useState<string>(currentAssignedTo || "");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: assistants = [], isLoading } = useQuery({
    queryKey: ["assistants"],
    queryFn: async () => {
      const { data: userRoles, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "assistante");

      if (rolesError) throw rolesError;

      if (userRoles.length === 0) return [];

      const userIds = userRoles.map((r) => r.user_id);
      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("id, full_name, email")
        .in("id", userIds);

      if (profilesError) throw profilesError;
      return profiles as Assistant[];
    },
  });

  const assignMutation = useMutation({
    mutationFn: async (assistantId: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Update order
      const { error: updateError } = await supabase
        .from("orders")
        .update({ assigned_to: assistantId })
        .eq("id", orderId);

      if (updateError) throw updateError;

      // Get order and assistant details
      const { data: order } = await supabase
        .from("orders")
        .select("*, products(name)")
        .eq("id", orderId)
        .single();

      const assistant = assistants.find((a) => a.id === assistantId);

      // Create notification
      const { error: notifError } = await supabase
        .from("notifications")
        .insert({
          user_id: assistantId,
          title: "Nouvelle commande assignée",
          message: `La commande ${order?.id.slice(0, 8)} pour ${order?.customer_name} vous a été assignée.`,
          type: "assignment",
          order_id: orderId,
        });

      if (notifError) throw notifError;

      // Log action
      const { error: actionError } = await supabase
        .from("order_actions")
        .insert({
          order_id: orderId,
          user_id: user.id,
          action_type: "assigned",
          description: `Commande assignée à ${assistant?.full_name}`,
          metadata: { assigned_to: assistantId },
        });

      if (actionError) throw actionError;

      // Send email notification
      try {
        await supabase.functions.invoke("send-assignment-email", {
          body: {
            assistantEmail: assistant?.email,
            assistantName: assistant?.full_name,
            orderDetails: {
              orderId: order?.id.slice(0, 8),
              customerName: order?.customer_name,
              productName: order?.products?.name || "N/A",
              status: order?.status,
            },
          },
        });
      } catch (emailError) {
        console.warn("Email notification failed:", emailError);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["orders"] });
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
      toast({
        title: "Succès",
        description: "Commande assignée avec succès",
      });
      onOpenChange(false);
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible d'assigner la commande",
        variant: "destructive",
      });
      console.error("Error assigning order:", error);
    },
  });

  const handleAssign = () => {
    if (!selectedAssistant) return;
    assignMutation.mutate(selectedAssistant);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Assigner la commande</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Assistante</Label>
            <Select value={selectedAssistant} onValueChange={setSelectedAssistant}>
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner une assistante" />
              </SelectTrigger>
              <SelectContent>
                {isLoading ? (
                  <SelectItem value="loading" disabled>
                    Chargement...
                  </SelectItem>
                ) : assistants.length === 0 ? (
                  <SelectItem value="none" disabled>
                    Aucune assistante disponible
                  </SelectItem>
                ) : (
                  assistants.map((assistant) => (
                    <SelectItem key={assistant.id} value={assistant.id}>
                      {assistant.full_name} ({assistant.email})
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuler
          </Button>
          <Button
            onClick={handleAssign}
            disabled={!selectedAssistant || assignMutation.isPending}
          >
            <UserCheck className="mr-2 h-4 w-4" />
            Assigner
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}