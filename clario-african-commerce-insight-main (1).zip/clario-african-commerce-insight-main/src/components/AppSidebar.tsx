import { LayoutDashboard, Package, DollarSign, Truck, Settings, Shield } from "lucide-react";
import { NavLink } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const menuItems = [
  { title: "Tableau de bord", url: "/", icon: LayoutDashboard },
  { title: "Produits", url: "/products", icon: Package },
  { title: "Dépenses", url: "/expenses", icon: DollarSign },
  { title: "Commandes", url: "/orders", icon: Truck },
  { title: "Paramètres", url: "/settings", icon: Settings },
];

const superAdminItem = {
  title: "Super Admin",
  url: "/super-admin",
  icon: Shield,
};

export function AppSidebar() {
  const { open } = useSidebar();
  const { userRole } = useAuth();

  const getFilteredMenuItems = () => {
    if (userRole === "super_admin" || userRole === "admin") {
      return menuItems;
    }
    
    if (userRole === "assistante") {
      return menuItems.filter(item => 
        ["Tableau de bord", "Commandes", "Produits", "Dépenses"].includes(item.title)
      );
    }
    
    if (userRole === "livreur") {
      return menuItems.filter(item => item.title === "Commandes");
    }
    
    if (userRole === "consultant") {
      return menuItems.filter(item => item.title === "Tableau de bord");
    }
    
    return menuItems;
  };

  const filteredMenuItems = getFilteredMenuItems();

  return (
    <Sidebar collapsible="icon" className="border-r border-sidebar-border">
      <SidebarContent className="bg-sidebar">
        <SidebarGroup className="py-4 sm:py-6">
          <SidebarGroupLabel className="text-sidebar-foreground text-lg sm:text-xl font-bold mb-4 sm:mb-6 px-3 sm:px-4">
            {open ? "CLARIO" : "C"}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="gap-1 sm:gap-2 px-2 sm:px-3">
              {filteredMenuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild className="hover:scale-105 transition-all duration-200">
                    <NavLink
                      to={item.url}
                      end={item.url === "/"}
                      className={({ isActive }) =>
                        isActive 
                          ? "bg-sidebar-primary text-sidebar-primary-foreground rounded-xl shadow-sm" 
                          : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent rounded-xl"
                      }
                    >
                      <item.icon className="h-4 w-4 sm:h-5 sm:w-5" />
                      <span className="font-medium text-sm sm:text-base">{item.title}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
              {userRole === "super_admin" && (
                <SidebarMenuItem>
                  <SidebarMenuButton asChild className="hover:scale-105 transition-all duration-200">
                    <NavLink
                      to={superAdminItem.url}
                      className={({ isActive }) =>
                        isActive 
                          ? "bg-sidebar-primary text-sidebar-primary-foreground rounded-xl shadow-sm" 
                          : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent rounded-xl"
                      }
                    >
                      <superAdminItem.icon className="h-4 w-4 sm:h-5 sm:w-5" />
                      <span className="font-medium text-sm sm:text-base">{superAdminItem.title}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
