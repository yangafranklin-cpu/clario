import { useAuth } from "@/contexts/AuthContext";
import { ReactNode } from "react";

interface PermissionGateProps {
  children: ReactNode;
  allowedRoles: Array<"admin" | "assistante" | "livreur" | "consultant" | "super_admin">;
  fallback?: ReactNode;
}

export function PermissionGate({ children, allowedRoles, fallback = null }: PermissionGateProps) {
  const { userRole } = useAuth();

  if (!userRole || !allowedRoles.includes(userRole as any)) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}
