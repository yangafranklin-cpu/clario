import React, { ReactNode } from "react";
import { motion } from "framer-motion";
import { Table, TableBody, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface AnimatedTableProps {
  headers: string[];
  children: ReactNode;
}

export function AnimatedTable({ headers, children }: AnimatedTableProps) {
  return (
    <div className="rounded-md border overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            {headers.map((header, index) => (
              <TableHead key={index}>{header}</TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>{children}</TableBody>
      </Table>
    </div>
  );
}

interface AnimatedTableRowProps {
  children: ReactNode;
  index: number;
}

export function AnimatedTableRow({ children, index }: AnimatedTableRowProps) {
  return (
    <TableRow className="border-b transition-colors hover:bg-muted/50">
      {children}
    </TableRow>
  );
}
