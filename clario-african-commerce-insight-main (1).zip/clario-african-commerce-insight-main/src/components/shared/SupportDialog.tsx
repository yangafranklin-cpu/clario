import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Mail, MessageCircle, Loader2 } from "lucide-react";

interface SupportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const SupportDialog = ({ open, onOpenChange }: SupportDialogProps) => {
  const [message, setMessage] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [supportSettings, setSupportSettings] = useState<{
    support_email: string;
    support_whatsapp: string;
  } | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchSupportSettings();
  }, []);

  const fetchSupportSettings = async () => {
    const { data } = await supabase
      .from("support_settings")
      .select("*")
      .single();
    
    if (data) {
      setSupportSettings(data);
    }
  };

  const handleEmailSupport = () => {
    if (!supportSettings) return;
    
    const subject = encodeURIComponent(`Support - ${name}`);
    const body = encodeURIComponent(`
Nom: ${name}
Email: ${email}

Message:
${message}
    `);
    
    window.open(`mailto:${supportSettings.support_email}?subject=${subject}&body=${body}`, "_blank");
    onOpenChange(false);
    setMessage("");
    setName("");
    setEmail("");
    
    toast({
      title: "Email ouvert",
      description: "Votre client email a été ouvert avec le message pré-rempli",
    });
  };

  const handleWhatsAppSupport = () => {
    if (!supportSettings || !message.trim()) {
      toast({
        title: "Message requis",
        description: "Veuillez entrer un message avant d'envoyer",
        variant: "destructive",
      });
      return;
    }

    const formattedMessage = encodeURIComponent(`
Bonjour, j'ai besoin d'aide.

Nom: ${name}
Email: ${email}

Message:
${message}
    `);
    
    const whatsappNumber = supportSettings.support_whatsapp.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${whatsappNumber}?text=${formattedMessage}`, "_blank");
    onOpenChange(false);
    setMessage("");
    setName("");
    setEmail("");
    
    toast({
      title: "WhatsApp ouvert",
      description: "Vous pouvez maintenant envoyer votre message",
    });
  };

  if (!supportSettings) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Contacter le Support</DialogTitle>
          <DialogDescription>
            Choisissez votre méthode de contact préférée
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="name">Nom</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Votre nom"
            />
          </div>
          
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="votre@email.com"
            />
          </div>
          
          <div>
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Décrivez votre problème ou question..."
              rows={5}
            />
          </div>
          
          <div className="flex gap-3">
            <Button
              onClick={handleEmailSupport}
              disabled={loading || !name || !email || !message}
              className="flex-1"
              variant="outline"
            >
              <Mail className="mr-2 h-4 w-4" />
              Email
            </Button>
            
            <Button
              onClick={handleWhatsAppSupport}
              disabled={loading || !name || !email || !message}
              className="flex-1"
            >
              <MessageCircle className="mr-2 h-4 w-4" />
              WhatsApp
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
