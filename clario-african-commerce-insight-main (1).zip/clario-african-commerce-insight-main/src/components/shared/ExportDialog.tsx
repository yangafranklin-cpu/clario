import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ExportColumn, exportToCSV, exportToExcel } from "@/lib/export";
import { Download } from "lucide-react";

interface ExportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  data: any[];
  allColumns: ExportColumn[];
  defaultFilename: string;
  title?: string;
}

export function ExportDialog({
  open,
  onOpenChange,
  data,
  allColumns,
  defaultFilename,
  title = "Exporter les données",
}: ExportDialogProps) {
  const [selectedColumns, setSelectedColumns] = useState<string[]>(
    allColumns.map((col) => col.key)
  );
  const [format, setFormat] = useState<"csv" | "excel">("csv");

  const toggleColumn = (columnKey: string) => {
    setSelectedColumns((prev) =>
      prev.includes(columnKey)
        ? prev.filter((key) => key !== columnKey)
        : [...prev, columnKey]
    );
  };

  const toggleAll = () => {
    if (selectedColumns.length === allColumns.length) {
      setSelectedColumns([]);
    } else {
      setSelectedColumns(allColumns.map((col) => col.key));
    }
  };

  const handleExport = () => {
    const columnsToExport = allColumns.filter((col) =>
      selectedColumns.includes(col.key)
    );

    if (columnsToExport.length === 0) {
      return;
    }

    const exportFn = format === "csv" ? exportToCSV : exportToExcel;
    exportFn({
      filename: defaultFilename,
      data,
      columns: columnsToExport,
    });

    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Format d'export</Label>
            <Select value={format} onValueChange={(value: "csv" | "excel") => setFormat(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">CSV</SelectItem>
                <SelectItem value="excel">Excel (.xlsx)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Colonnes à exporter</Label>
              <Button variant="ghost" size="sm" onClick={toggleAll}>
                {selectedColumns.length === allColumns.length
                  ? "Tout déselectionner"
                  : "Tout sélectionner"}
              </Button>
            </div>
            <div className="border rounded-md p-4 max-h-[300px] overflow-y-auto space-y-2">
              {allColumns.map((column) => (
                <div key={column.key} className="flex items-center space-x-2">
                  <Checkbox
                    id={column.key}
                    checked={selectedColumns.includes(column.key)}
                    onCheckedChange={() => toggleColumn(column.key)}
                  />
                  <Label htmlFor={column.key} className="cursor-pointer">
                    {column.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <p className="text-sm text-muted-foreground">
            {data.length} ligne{data.length > 1 ? "s" : ""} • {selectedColumns.length} colonne
            {selectedColumns.length > 1 ? "s" : ""}
          </p>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuler
          </Button>
          <Button onClick={handleExport} disabled={selectedColumns.length === 0}>
            <Download className="mr-2 h-4 w-4" />
            Exporter
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
