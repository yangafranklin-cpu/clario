import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts";

interface OrdersStatusChartProps {
  data: { status: string; count: number }[];
}

const STATUS_COLORS = {
  pending: "hsl(var(--chart-1))",
  processing: "hsl(var(--chart-2))",
  shipped: "hsl(var(--chart-3))",
  delivered: "hsl(var(--chart-4))",
  cancelled: "hsl(var(--chart-5))",
};

const STATUS_LABELS: Record<string, string> = {
  pending: "En attente",
  processing: "En traitement",
  shipped: "Expédiée",
  delivered: "Livrée",
  cancelled: "Annulée",
};

export function OrdersStatusChart({ data }: OrdersStatusChartProps) {
  const chartData = data.map((item) => ({
    name: STATUS_LABELS[item.status] || item.status,
    value: item.count,
    fill: STATUS_COLORS[item.status as keyof typeof STATUS_COLORS] || "hsl(var(--muted))",
  }));

  const chartConfig = Object.entries(STATUS_LABELS).reduce((acc, [key, label]) => ({
    ...acc,
    [key]: { label, color: STATUS_COLORS[key as keyof typeof STATUS_COLORS] },
  }), {});

  return (
    <Card>
      <CardHeader>
        <CardTitle>Commandes par statut</CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <ChartTooltip content={<ChartTooltipContent />} />
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
