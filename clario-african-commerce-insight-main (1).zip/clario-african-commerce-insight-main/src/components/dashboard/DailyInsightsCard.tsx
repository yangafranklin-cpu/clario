import React from "react";
import { useInsights } from "@/hooks/useInsights";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Lightbulb, 
  AlertTriangle, 
  TrendingUp, 
  RefreshCw,
  CheckCircle2,
  ArrowRight 
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useCurrency } from "@/contexts/CurrencyContext";
import { motion } from "framer-motion";

export function DailyInsightsCard() {
  const { insights, isLoading, generateInsights, isGenerating } = useInsights(1);
  const { formatAmount } = useCurrency();
  const latestInsight = insights[0];

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Insights IA du jour</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Chargement...</p>
        </CardContent>
      </Card>
    );
  }

  if (!latestInsight) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-primary" />
            Insights IA du jour
          </CardTitle>
          <CardDescription>
            Analyse quotidienne automatique de vos performances
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Aucun insight disponible pour aujourd'hui
          </p>
          <Button 
            onClick={() => generateInsights()} 
            disabled={isGenerating}
            className="w-full"
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${isGenerating ? "animate-spin" : ""}`} />
            Générer les insights
          </Button>
        </CardContent>
      </Card>
    );
  }

  const { metrics, summary, insights: insightsList, critical_alert, recommended_actions } = latestInsight;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-primary" />
                Insights IA du jour
              </CardTitle>
              <CardDescription>
                {format(new Date(latestInsight.date), "EEEE d MMMM yyyy", { locale: fr })}
              </CardDescription>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => generateInsights()} 
              disabled={isGenerating}
            >
              <RefreshCw className={`h-4 w-4 ${isGenerating ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </CardHeader>
      <CardContent className="space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Ventes</p>
            <p className="text-lg font-bold">{formatAmount(metrics.totalSales)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Commandes</p>
            <p className="text-lg font-bold">{metrics.totalOrders}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Dépenses pub</p>
            <p className="text-lg font-bold">{formatAmount(metrics.fbAdSpend)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">ROAS</p>
            <div className="flex items-center gap-2">
              <p className="text-lg font-bold">{metrics.roas.toFixed(2)}x</p>
              <Badge 
                variant={metrics.roasChange > 0 ? "default" : "destructive"}
                className="text-xs"
              >
                {metrics.roasChange > 0 ? "+" : ""}{metrics.roasChange.toFixed(1)}%
              </Badge>
            </div>
          </div>
        </div>

        <Separator />

        {/* Summary */}
        <div className="space-y-2">
          <h4 className="text-sm font-semibold flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Résumé
          </h4>
          <p className="text-sm">{summary}</p>
        </div>

        {/* Critical Alert */}
        {critical_alert && (
          <>
            <Separator />
            <div className="space-y-2">
              <h4 className="text-sm font-semibold flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-4 w-4" />
                Alerte critique
              </h4>
              <p className="text-sm text-destructive">{critical_alert}</p>
            </div>
          </>
        )}

        {/* Insights */}
        <Separator />
        <div className="space-y-3">
          <h4 className="text-sm font-semibold">Insights clés</h4>
          <ScrollArea className="h-[120px]">
            <ul className="space-y-2">
              {insightsList.map((insight, index) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 mt-0.5 text-green-500 flex-shrink-0" />
                  <span>{insight}</span>
                </li>
              ))}
            </ul>
          </ScrollArea>
        </div>

        {/* Recommended Actions */}
        {recommended_actions && recommended_actions.length > 0 && (
          <>
            <Separator />
            <div className="space-y-3">
              <h4 className="text-sm font-semibold">Actions recommandées</h4>
              <ul className="space-y-2">
                {recommended_actions.map((action, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <ArrowRight className="h-4 w-4 mt-0.5 text-primary flex-shrink-0" />
                    <span>{action}</span>
                  </li>
                ))}
              </ul>
            </div>
          </>
        )}

        {/* Top Products */}
        {metrics.topProducts.length > 0 && (
          <>
            <Separator />
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Top produits</h4>
              <div className="space-y-1">
                {metrics.topProducts.map((product, index) => (
                  <div key={index} className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">
                      {index + 1}. {product.name}
                    </span>
                    <span className="font-medium">
                      {formatAmount(product.revenue)} ({product.count})
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
    </motion.div>
  );
}