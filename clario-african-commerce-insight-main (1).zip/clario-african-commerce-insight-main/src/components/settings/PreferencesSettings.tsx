import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bell, Globe } from "lucide-react";

export function PreferencesSettings() {
  return (
    <Card className="modern-card">
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Bell className="h-5 w-5 text-primary" />
          </div>
          <div>
            <CardTitle>Préférences</CardTitle>
            <CardDescription>
              Personnalisez votre expérience utilisateur
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Notifications */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Notifications
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
              <div className="space-y-0.5">
                <Label htmlFor="email-notifications" className="cursor-pointer">
                  Notifications par email
                </Label>
                <p className="text-xs text-muted-foreground">
                  Recevez des emails pour les nouvelles commandes
                </p>
              </div>
              <Switch id="email-notifications" defaultChecked />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
              <div className="space-y-0.5">
                <Label htmlFor="push-notifications" className="cursor-pointer">
                  Notifications push
                </Label>
                <p className="text-xs text-muted-foreground">
                  Recevez des notifications dans le navigateur
                </p>
              </div>
              <Switch id="push-notifications" defaultChecked />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
              <div className="space-y-0.5">
                <Label htmlFor="daily-reports" className="cursor-pointer">
                  Rapports quotidiens
                </Label>
                <p className="text-xs text-muted-foreground">
                  Recevez un résumé quotidien de votre activité
                </p>
              </div>
              <Switch id="daily-reports" defaultChecked />
            </div>
          </div>
        </div>

        {/* Language & Region */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <Globe className="h-4 w-4" />
            Langue et région
          </h3>
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="language">Langue de l'interface</Label>
              <Select defaultValue="fr">
                <SelectTrigger id="language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="timezone">Fuseau horaire</Label>
              <Select defaultValue="europe/paris">
                <SelectTrigger id="timezone">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="europe/paris">Europe/Paris (UTC+1)</SelectItem>
                  <SelectItem value="africa/abidjan">Africa/Abidjan (UTC+0)</SelectItem>
                  <SelectItem value="africa/casablanca">Africa/Casablanca (UTC+1)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
