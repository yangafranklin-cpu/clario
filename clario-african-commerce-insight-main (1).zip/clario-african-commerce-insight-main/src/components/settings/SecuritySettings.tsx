import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Lock, Loader2, Eye, EyeOff } from "lucide-react";

export function SecuritySettings() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [passwords, setPasswords] = useState({
    current: "",
    new: "",
    confirm: "",
  });

  const handlePasswordChange = async () => {
    try {
      setLoading(true);

      // Validate passwords
      if (passwords.new !== passwords.confirm) {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: "Les mots de passe ne correspondent pas",
        });
        return;
      }

      if (passwords.new.length < 8) {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: "Le mot de passe doit contenir au moins 8 caractères",
        });
        return;
      }

      // Update password
      const { error } = await supabase.auth.updateUser({
        password: passwords.new,
      });

      if (error) throw error;

      // Clear form
      setPasswords({ current: "", new: "", confirm: "" });

      toast({
        title: "Mot de passe modifié",
        description: "Votre mot de passe a été mis à jour avec succès",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="modern-card">
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Lock className="h-5 w-5 text-primary" />
          </div>
          <div>
            <CardTitle>Sécurité</CardTitle>
            <CardDescription>
              Gérez votre mot de passe et vos paramètres de sécurité
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="new-password">Nouveau mot de passe</Label>
            <div className="relative">
              <Input
                id="new-password"
                type={showPassword ? "text" : "password"}
                value={passwords.new}
                onChange={(e) => setPasswords({ ...passwords, new: e.target.value })}
                placeholder="Minimum 8 caractères"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <Eye className="h-4 w-4 text-muted-foreground" />
                )}
              </Button>
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="confirm-password">Confirmer le nouveau mot de passe</Label>
            <Input
              id="confirm-password"
              type={showPassword ? "text" : "password"}
              value={passwords.confirm}
              onChange={(e) => setPasswords({ ...passwords, confirm: e.target.value })}
              placeholder="Retapez le mot de passe"
            />
          </div>

          {passwords.new && (
            <div className="rounded-lg bg-muted/50 p-3">
              <p className="text-xs font-medium mb-2">Force du mot de passe:</p>
              <div className="flex gap-1">
                <div className={`h-1 flex-1 rounded-full ${passwords.new.length >= 8 ? 'bg-yellow-500' : 'bg-muted'}`} />
                <div className={`h-1 flex-1 rounded-full ${passwords.new.length >= 12 ? 'bg-orange-500' : 'bg-muted'}`} />
                <div className={`h-1 flex-1 rounded-full ${passwords.new.length >= 16 && /[A-Z]/.test(passwords.new) && /[0-9]/.test(passwords.new) ? 'bg-green-500' : 'bg-muted'}`} />
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Utilisez au moins 12 caractères avec des majuscules et des chiffres
              </p>
            </div>
          )}
        </div>

        <div className="flex justify-end pt-2">
          <Button 
            onClick={handlePasswordChange} 
            disabled={loading || !passwords.new || !passwords.confirm}
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Modification...
              </>
            ) : (
              "Changer le mot de passe"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
