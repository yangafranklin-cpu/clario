import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Order } from "@/types";

interface OrderDetailsCardProps {
  order: Order;
  productName?: string;
}

export function OrderDetailsCard({ order, productName }: OrderDetailsCardProps) {
  const { formatAmount, convertAmount } = useCurrency();

  const grossMargin = order.gross_margin || 0;
  const netProfit = order.net_profit || 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Détails de la commande</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Client</p>
            <p className="font-medium">{order.customer_name}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Statut</p>
            <Badge variant={order.status === "delivered" ? "default" : "secondary"}>
              {order.status}
            </Badge>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Produit</p>
            <p className="font-medium">{productName || "N/A"}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Quantité</p>
            <p className="font-medium">{order.quantity}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Montant total</p>
            <p className="font-medium">{formatAmount(convertAmount(order.total_amount, order.currency))}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Frais logistique</p>
            <p className="font-medium">
              {order.logistics_cost
                ? formatAmount(convertAmount(order.logistics_cost, order.currency))
                : "0"}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Marge brute</p>
            <p className={`font-medium ${grossMargin >= 0 ? "text-green-600" : "text-red-600"}`}>
              {formatAmount(convertAmount(grossMargin, order.currency))}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Profit net</p>
            <p className={`font-medium ${netProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
              {formatAmount(convertAmount(netProfit, order.currency))}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Créée le</p>
            <p className="font-medium">
              {new Date(order.created_at).toLocaleDateString("fr-FR")}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
