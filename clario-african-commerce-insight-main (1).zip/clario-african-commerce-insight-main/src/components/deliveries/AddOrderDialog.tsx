import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Order } from "@/types";
import { orderSchema } from "@/lib/validation";
import { useToast } from "@/hooks/use-toast";

type AddOrderDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (order: Omit<Order, "id" | "user_id" | "created_at" | "updated_at">) => void;
  products: Array<{ id: string; name: string; price: number; currency: string }>;
};

export function AddOrderDialog({ open, onOpenChange, onAdd, products }: AddOrderDialogProps) {
  const { currencies } = useCurrency();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    product_id: "",
    customer_name: "",
    quantity: "1",
    total_amount: "",
    currency: "FCFA",
    status: "pending" as Order["status"],
    logistics_cost: "",
    assigned_to: "",
  });

  const handleProductChange = (productId: string) => {
    const product = products.find((p) => p.id === productId);
    if (product) {
      setFormData({
        ...formData,
        product_id: productId,
        total_amount: product.price.toString(),
        currency: product.currency,
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.product_id || !formData.customer_name || !formData.total_amount) {
      return;
    }

    // Validate input
    const validation = orderSchema.safeParse({
      productId: formData.product_id,
      customerName: formData.customer_name,
      quantity: parseInt(formData.quantity),
      totalAmount: parseFloat(formData.total_amount),
      logisticsCost: formData.logistics_cost ? parseFloat(formData.logistics_cost) : undefined,
      currency: formData.currency,
      status: formData.status,
    });

    if (!validation.success) {
      toast({
        variant: "destructive",
        title: "Erreur de validation",
        description: validation.error.errors[0].message,
      });
      return;
    }

    onAdd({
      product_id: formData.product_id,
      customer_name: validation.data.customerName,
      quantity: validation.data.quantity,
      total_amount: validation.data.totalAmount,
      currency: validation.data.currency,
      status: validation.data.status,
      logistics_cost: validation.data.logisticsCost,
      assigned_to: formData.assigned_to || undefined,
    });

    setFormData({
      product_id: "",
      customer_name: "",
      quantity: "1",
      total_amount: "",
      currency: "FCFA",
      status: "pending",
      logistics_cost: "",
      assigned_to: "",
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Ajouter une commande</DialogTitle>
          <DialogDescription>
            Enregistrez une nouvelle commande client
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="product">Produit</Label>
              <Select
                value={formData.product_id}
                onValueChange={handleProductChange}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un produit" />
                </SelectTrigger>
                <SelectContent>
                  {products.map((product) => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="customer">Nom du client</Label>
              <Input
                id="customer"
                value={formData.customer_name}
                onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                placeholder="Ex: Jean Dupont"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="quantity">Quantité</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="order-amount">Montant</Label>
                <Input
                  id="order-amount"
                  type="number"
                  step="0.01"
                  value={formData.total_amount}
                  onChange={(e) => setFormData({ ...formData, total_amount: e.target.value })}
                  required
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="shipping">Frais de livraison (optionnel)</Label>
              <Input
                id="shipping"
                type="number"
                step="0.01"
                value={formData.logistics_cost}
                onChange={(e) => setFormData({ ...formData, logistics_cost: e.target.value })}
                placeholder="0"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="status">Statut</Label>
              <Select
                value={formData.status}
                onValueChange={(value: Order["status"]) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">En attente</SelectItem>
                  <SelectItem value="processing">En traitement</SelectItem>
                  <SelectItem value="shipped">Expédiée</SelectItem>
                  <SelectItem value="delivered">Livrée</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="assigned">Assignée à (optionnel)</Label>
              <Input
                id="assigned"
                value={formData.assigned_to}
                onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                placeholder="Ex: Marie"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuler
            </Button>
            <Button type="submit">Ajouter</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
