import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, X } from "lucide-react";
import { useWebPush } from "@/hooks/useWebPush";

export function NotificationPermissionPrompt() {
  const [showPrompt, setShowPrompt] = useState(false);
  const { permission, requestPermission } = useWebPush();

  useEffect(() => {
    // Show prompt if permission is default and hasn't been dismissed
    const dismissed = localStorage.getItem("notification-prompt-dismissed");
    if (permission === "default" && !dismissed) {
      setTimeout(() => setShowPrompt(true), 5000); // Show after 5 seconds
    }
  }, [permission]);

  const handleAllow = async () => {
    const granted = await requestPermission();
    if (granted) {
      setShowPrompt(false);
      localStorage.setItem("notification-prompt-dismissed", "true");
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem("notification-prompt-dismissed", "true");
  };

  if (!showPrompt || permission !== "default") {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-md">
      <Card>
        <CardHeader className="relative">
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 h-6 w-6"
            onClick={handleDismiss}
          >
            <X className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">Activer les notifications</CardTitle>
          </div>
          <CardDescription>
            Recevez des alertes en temps réel pour les nouvelles commandes, changements de
            statut et rappels d'expédition
          </CardDescription>
        </CardHeader>
        <CardContent className="flex gap-2">
          <Button onClick={handleAllow} className="flex-1">
            Activer
          </Button>
          <Button variant="outline" onClick={handleDismiss} className="flex-1">
            Plus tard
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}