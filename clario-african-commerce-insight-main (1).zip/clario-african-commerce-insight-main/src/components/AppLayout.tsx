import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useAuth } from "@/contexts/AuthContext";
import { NotificationsFeed } from "./notifications/NotificationsFeed";
import { NotificationPermissionPrompt } from "./notifications/NotificationPermissionPrompt";
import { ThemeToggle } from "./shared/ThemeToggle";
import { SupportDialog } from "./shared/SupportDialog";
import { LogOut, MessageCircle } from "lucide-react";
import { useState } from "react";

interface AppLayoutProps {
  children: React.ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  const { currentCurrency, currencies, setCurrency } = useCurrency();
  const { signOut, user } = useAuth();
  const [supportDialogOpen, setSupportDialogOpen] = useState(false);

  return (
    <>
      <NotificationPermissionPrompt />
      <SidebarProvider>
        <div className="flex min-h-screen w-full">
          <AppSidebar />
          <main className="flex-1 w-full min-w-0">
            <header className="sticky top-0 z-10 flex h-14 sm:h-16 items-center gap-2 sm:gap-4 border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 px-3 sm:px-6 transition-all duration-300">
              <SidebarTrigger className="transition-transform duration-200 hover:scale-110 -ml-1 sm:ml-0" />
              <div className="flex-1 min-w-0">
                <h2 className="text-base sm:text-lg font-semibold tracking-tight hidden sm:block truncate">
                  Bonjour, {user?.user_metadata?.full_name || "Utilisateur"} 👋
                </h2>
              </div>
              <div className="flex items-center gap-1 sm:gap-2">
                <span className="text-xs sm:text-sm text-muted-foreground hidden lg:inline truncate max-w-[150px]">
                  {user?.email}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSupportDialogOpen(true)}
                  className="hidden sm:flex gap-2"
                >
                  <MessageCircle className="h-4 w-4" />
                  Support
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setSupportDialogOpen(true)}
                  className="sm:hidden rounded-full h-8 w-8"
                >
                  <MessageCircle className="h-4 w-4" />
                </Button>
                <ThemeToggle />
                <NotificationsFeed />
                <Select value={currentCurrency.code} onValueChange={setCurrency}>
                  <SelectTrigger className="w-[80px] sm:w-[120px] rounded-full text-xs sm:text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((currency) => (
                      <SelectItem key={currency.code} value={currency.code}>
                        {currency.code}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={signOut}
                  className="rounded-full h-8 w-8 sm:h-10 sm:w-10 transition-all duration-200 hover:scale-110"
                >
                  <LogOut className="h-4 w-4 sm:h-5 sm:w-5" />
                </Button>
              </div>
            </header>
            <div className="p-3 sm:p-4 md:p-6 animate-fade-in">{children}</div>
          </main>
        </div>
      </SidebarProvider>
      <SupportDialog open={supportDialogOpen} onOpenChange={setSupportDialogOpen} />
    </>
  );
}
