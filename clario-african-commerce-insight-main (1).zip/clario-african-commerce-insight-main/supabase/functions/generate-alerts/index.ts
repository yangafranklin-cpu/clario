import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const lovableApiKey = Deno.env.get("LOVABLE_API_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Note: This function is designed to be called by cron jobs
    // For production, verify a secret token here
    const cronSecret = req.headers.get('x-cron-secret');
    const expectedSecret = Deno.env.get('CRON_SECRET');
    
    if (expectedSecret && cronSecret !== expectedSecret) {
      console.log('Unauthorized cron job attempt');
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const supabase = createClient(supabaseUrl, supabaseKey);
    console.log("Starting threshold-based alerts generation...");

    // Get all admin users
    const { data: adminRoles } = await supabase
      .from("user_roles")
      .select("user_id")
      .eq("role", "admin");

    if (!adminRoles || adminRoles.length === 0) {
      console.log("No admins found");
      return new Response(
        JSON.stringify({ success: true, message: "No admins to process" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const today = new Date().toISOString().split("T")[0];

    for (const adminRole of adminRoles) {
      const userId = adminRole.user_id;
      console.log(`Processing alerts for user ${userId}`);

      // Get user's thresholds
      const { data: thresholds } = await supabase
        .from("thresholds")
        .select("*")
        .eq("user_id", userId)
        .eq("is_enabled", true);

      if (!thresholds || thresholds.length === 0) {
        console.log(`No thresholds found for user ${userId}`);
        continue;
      }

      // Get today's metrics
      const { data: orders } = await supabase
        .from("orders")
        .select("*, products(name)")
        .eq("user_id", userId)
        .gte("created_at", `${today}T00:00:00`)
        .lt("created_at", `${today}T23:59:59`);

      const { data: expenses } = await supabase
        .from("expenses")
        .select("amount")
        .eq("user_id", userId)
        .eq("category", "publicité")
        .eq("date", today);

      const totalSales = orders?.reduce((sum: number, o: any) => sum + Number(o.total_amount), 0) || 0;
      const fbAdSpend = expenses?.reduce((sum: number, e: any) => sum + Number(e.amount), 0) || 0;
      const roas = fbAdSpend > 0 ? totalSales / fbAdSpend : 0;

      // Calculate net profit
      const totalExpenses = expenses?.reduce((sum: number, e: any) => sum + Number(e.amount), 0) || 0;
      const totalLogistics = orders?.reduce((sum: number, o: any) => sum + Number(o.logistics_cost || 0), 0) || 0;
      const netProfit = totalSales - totalExpenses - totalLogistics;

      // Check thresholds
      const alertsToCreate = [];
      
      for (const threshold of thresholds) {
        let currentValue = 0;
        let metricName = "";
        
        switch (threshold.metric_type) {
          case "roas":
            currentValue = roas;
            metricName = "ROAS";
            break;
          case "net_profit":
            currentValue = netProfit;
            metricName = "Profit net";
            break;
        }

        let shouldAlert = false;
        switch (threshold.condition) {
          case "less_than":
            shouldAlert = currentValue < threshold.threshold_value;
            break;
          case "greater_than":
            shouldAlert = currentValue > threshold.threshold_value;
            break;
          case "equals":
            shouldAlert = currentValue === threshold.threshold_value;
            break;
        }

        if (shouldAlert) {
          // Generate AI suggestion using Lovable AI
          const suggestion = await generateAISuggestion(
            threshold.metric_type,
            currentValue,
            threshold.threshold_value,
            { totalSales, fbAdSpend, roas, netProfit }
          );

          alertsToCreate.push({
            user_id: userId,
            title: `Alerte: ${metricName} en dessous du seuil`,
            message: `${metricName} actuel: ${currentValue.toFixed(2)} (seuil: ${threshold.threshold_value}). ${suggestion}`,
            severity: currentValue < threshold.threshold_value * 0.5 ? "critical" : "warning",
            category: "performance",
          });
        }
      }

      // Insert alerts
      if (alertsToCreate.length > 0) {
        await supabase.from("alerts").insert(alertsToCreate);
        console.log(`Created ${alertsToCreate.length} alerts for user ${userId}`);
      }
    }

    return new Response(
      JSON.stringify({ success: true, processed: adminRoles.length }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("Error generating alerts:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
};

async function generateAISuggestion(
  metricType: string,
  currentValue: number,
  thresholdValue: number,
  metrics: any
): Promise<string> {
  const prompt = `En tant qu'expert e-commerce, génère une suggestion courte et actionnable (max 100 caractères) pour améliorer la métrique suivante:

Métrique: ${metricType}
Valeur actuelle: ${currentValue.toFixed(2)}
Seuil: ${thresholdValue}
Contexte: Ventes ${metrics.totalSales}, Dépenses pub ${metrics.fbAdSpend}, ROAS ${metrics.roas.toFixed(2)}, Profit net ${metrics.netProfit}

Réponds uniquement avec la suggestion, sans introduction.`;

  try {
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: "Tu es un expert e-commerce concis." },
          { role: "user", content: prompt },
        ],
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      console.error("AI API error:", response.status);
      return "Optimisez vos campagnes publicitaires pour améliorer les performances.";
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content || "Optimisez vos campagnes publicitaires.";
  } catch (error) {
    console.error("Error calling AI:", error);
    return "Optimisez vos campagnes publicitaires pour améliorer les performances.";
  }
}

serve(handler);
