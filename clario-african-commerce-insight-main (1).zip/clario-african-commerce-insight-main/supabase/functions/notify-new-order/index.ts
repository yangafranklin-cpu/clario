import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const NewOrderRequestSchema = z.object({
  orderId: z.string().uuid()
});

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify authentication
    const authHeader = req.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } }
    });

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Validate input
    const body = await req.json();
    const parseResult = NewOrderRequestSchema.safeParse(body);
    
    if (!parseResult.success) {
      return new Response(
        JSON.stringify({ error: 'Invalid input', details: parseResult.error.issues }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { orderId } = parseResult.data;

    // Use service role key for admin operations
    const adminSupabase = createClient(supabaseUrl, supabaseKey);

    console.log(`Processing new order notification for ${orderId}`);

    // Get order details
    const { data: order, error: orderError } = await adminSupabase
      .from("orders")
      .select("*, products(name)")
      .eq("id", orderId)
      .single();

    if (orderError || !order) {
      throw new Error(`Order not found: ${orderError?.message}`);
    }

    // Get all admins
    const { data: adminRoles } = await adminSupabase
      .from("user_roles")
      .select("user_id")
      .eq("role", "admin");

    if (adminRoles && adminRoles.length > 0) {
      const adminIds = adminRoles.map((r) => r.user_id);

      // Get admin profiles
      const { data: adminProfiles } = await adminSupabase
        .from("profiles")
        .select("id, email, full_name")
        .in("id", adminIds);

      // Create notifications for all admins
      const notifications = adminIds.map((adminId) => ({
        user_id: adminId,
        title: "Nouvelle commande",
        message: `Commande ${order.id.slice(0, 8)} créée par ${order.customer_name}`,
        type: "new_order",
        order_id: orderId,
      }));

      await adminSupabase.from("notifications").insert(notifications);

      // Send emails to all admins
      for (const admin of adminProfiles || []) {
        await resend.emails.send({
          from: "Commandes <onboarding@resend.dev>",
          to: [admin.email],
          subject: `Nouvelle commande - ${order.id.slice(0, 8)}`,
          html: `
            <h1>Bonjour ${admin.full_name},</h1>
            <p>Une nouvelle commande a été créée :</p>
            <ul>
              <li><strong>Numéro:</strong> ${order.id.slice(0, 8)}</li>
              <li><strong>Client:</strong> ${order.customer_name}</li>
              <li><strong>Produit:</strong> ${order.products?.name || "N/A"}</li>
              <li><strong>Quantité:</strong> ${order.quantity}</li>
              <li><strong>Montant:</strong> ${order.total_amount} ${order.currency}</li>
            </ul>
            <p>Connectez-vous pour gérer cette commande.</p>
          `,
        });
      }

      console.log(`Notifications sent to ${adminIds.length} admins`);
    }

    return new Response(
      JSON.stringify({ success: true }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in notify-new-order function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);