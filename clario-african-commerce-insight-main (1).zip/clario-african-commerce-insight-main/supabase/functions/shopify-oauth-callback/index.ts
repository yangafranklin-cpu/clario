import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.75.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const clientId = Deno.env.get('SHOPIFY_CLIENT_ID')!;
    const clientSecret = Deno.env.get('SHOPIFY_CLIENT_SECRET')!;

    const { code, shop, userId } = await req.json();

    console.log('Processing OAuth callback');

    // Exchange authorization code for access token
    const tokenResponse = await fetch(`https://${shop}/admin/oauth/access_token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        client_id: clientId,
        client_secret: clientSecret,
        code: code,
      }),
    });

    const responseText = await tokenResponse.text();
    
    if (!tokenResponse.ok) {
      console.error('Token exchange failed', { status: tokenResponse.status });
      throw new Error('Shopify authorization failed');
    }

    let tokenData;
    try {
      tokenData = JSON.parse(responseText);
    } catch (e) {
      console.error('Failed to parse token response');
      throw new Error('Invalid response from Shopify');
    }

    const { access_token } = tokenData;
    
    if (!access_token) {
      console.error('No access token in response');
      throw new Error('No access token received from Shopify');
    }
    
    console.log('Access token obtained successfully');

    // Store the access token securely and update profile
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Store token in secure_tokens table (only accessible via service role)
    const { error: tokenError } = await supabase
      .from('secure_tokens')
      .upsert({
        user_id: userId,
        service: 'shopify',
        token: access_token,
      }, {
        onConflict: 'user_id,service'
      });

    if (tokenError) {
      console.error('Failed to store secure token:', tokenError);
      throw tokenError;
    }

    // Update profile with connection status
    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        shopify_connected: true,
        shop_domain: shop,
      })
      .eq('id', userId);

    if (updateError) {
      console.error('Failed to update profile:', updateError);
      throw updateError;
    }

    console.log('Shopify connection established');

    // Trigger initial sync
    const syncResponse = await fetch(`${supabaseUrl}/functions/v1/shopify-sync-products`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${supabaseKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userId, shop }),
    });

    console.log('Initial sync triggered');

    return new Response(
      JSON.stringify({ success: true, message: 'Shopify connected successfully' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in shopify-oauth-callback:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
