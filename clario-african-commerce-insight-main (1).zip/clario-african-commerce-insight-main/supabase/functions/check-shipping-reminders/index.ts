import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log("Checking for orders requiring shipping reminders...");

    // Get orders that are "processing" for more than 2 days
    const twoDaysAgo = new Date();
    twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);

    const { data: orders, error: ordersError } = await supabase
      .from("orders")
      .select("*, products(name), profiles!orders_assigned_to_fkey(email, full_name)")
      .eq("status", "processing")
      .lt("created_at", twoDaysAgo.toISOString());

    if (ordersError) {
      throw ordersError;
    }

    console.log(`Found ${orders?.length || 0} orders requiring reminders`);

    let remindersCreated = 0;

    for (const order of orders || []) {
      if (!order.assigned_to || !order.profiles?.email) continue;

      // Create notification
      await supabase.from("notifications").insert({
        user_id: order.assigned_to,
        title: "Rappel d'expédition",
        message: `La commande ${order.id.slice(0, 8)} est en attente d'expédition depuis plus de 2 jours`,
        type: "shipping_reminder",
        order_id: order.id,
      });

      // Send email
      await resend.emails.send({
        from: "Commandes <onboarding@resend.dev>",
        to: [order.profiles.email],
        subject: `Rappel: Expédition en attente - Commande ${order.id.slice(0, 8)}`,
        html: `
          <h1>Bonjour ${order.profiles.full_name},</h1>
          <p>Cette commande est en attente d'expédition depuis plus de 2 jours :</p>
          <ul>
            <li><strong>Numéro:</strong> ${order.id.slice(0, 8)}</li>
            <li><strong>Client:</strong> ${order.customer_name}</li>
            <li><strong>Produit:</strong> ${order.products?.name || "N/A"}</li>
            <li><strong>Date de commande:</strong> ${new Date(order.created_at).toLocaleDateString("fr-FR")}</li>
          </ul>
          <p>Merci de mettre à jour le statut dès que possible.</p>
        `,
      });

      remindersCreated++;
    }

    console.log(`Created ${remindersCreated} shipping reminders`);

    return new Response(
      JSON.stringify({ success: true, remindersCreated }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in check-shipping-reminders function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);