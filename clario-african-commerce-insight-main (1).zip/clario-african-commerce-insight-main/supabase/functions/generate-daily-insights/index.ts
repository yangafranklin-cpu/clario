import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const lovableApiKey = Deno.env.get("LOVABLE_API_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface DailyMetrics {
  totalSales: number;
  totalOrders: number;
  fbAdSpend: number;
  roas: number;
  roasChange: number;
  topProducts: Array<{ name: string; revenue: number; count: number }>;
  bottomProducts: Array<{ name: string; revenue: number; count: number }>;
  currency: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Note: This function is designed to be called by cron jobs
    // For production, verify a secret token here
    const cronSecret = req.headers.get('x-cron-secret');
    const expectedSecret = Deno.env.get('CRON_SECRET');
    
    if (expectedSecret && cronSecret !== expectedSecret) {
      console.log('Unauthorized cron job attempt');
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const supabase = createClient(supabaseUrl, supabaseKey);
    console.log("Starting daily insights generation...");

    // Get all admin users to generate insights for
    const { data: adminRoles } = await supabase
      .from("user_roles")
      .select("user_id")
      .eq("role", "admin");

    if (!adminRoles || adminRoles.length === 0) {
      console.log("No admins found");
      return new Response(
        JSON.stringify({ success: true, message: "No admins to process" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const today = new Date().toISOString().split("T")[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0];

    for (const adminRole of adminRoles) {
      const userId = adminRole.user_id;
      console.log(`Processing insights for user ${userId}`);

      // Get user profile for locale
      const { data: profile } = await supabase
        .from("profiles")
        .select("currency")
        .eq("id", userId)
        .single();

      const userCurrency = profile?.currency || "FCFA";

      // Calculate today's metrics
      const metrics = await calculateDailyMetrics(supabase, userId, today, userCurrency);
      const yesterdayMetrics = await calculateDailyMetrics(supabase, userId, yesterday, userCurrency);

      // Calculate ROAS change
      const roasChange = yesterdayMetrics.roas > 0 
        ? ((metrics.roas - yesterdayMetrics.roas) / yesterdayMetrics.roas) * 100 
        : 0;

      metrics.roasChange = roasChange;

      // Generate AI insights
      const aiInsights = await generateAIInsights(metrics, "fr");

      // Store insights in database
      await supabase.from("insights").upsert({
        user_id: userId,
        date: today,
        metrics: {
          totalSales: metrics.totalSales,
          totalOrders: metrics.totalOrders,
          fbAdSpend: metrics.fbAdSpend,
          roas: metrics.roas,
          roasChange: metrics.roasChange,
          topProducts: metrics.topProducts,
          bottomProducts: metrics.bottomProducts,
        },
        summary: aiInsights.summary,
        insights: aiInsights.insights,
        critical_alert: aiInsights.critical_alert,
        recommended_actions: aiInsights.recommended_actions,
        language: "fr",
      });

      console.log(`Insights generated for user ${userId}`);
    }

    return new Response(
      JSON.stringify({ success: true, processed: adminRoles.length }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("Error generating insights:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
};

async function calculateDailyMetrics(
  supabase: any,
  userId: string,
  date: string,
  currency: string
): Promise<DailyMetrics> {
  // Get today's orders
  const { data: orders } = await supabase
    .from("orders")
    .select("*, products(name)")
    .eq("user_id", userId)
    .gte("created_at", `${date}T00:00:00`)
    .lt("created_at", `${date}T23:59:59`);

  const totalSales = orders?.reduce((sum: number, o: any) => sum + Number(o.total_amount), 0) || 0;
  const totalOrders = orders?.length || 0;

  // Get FB ad spend for today
  const { data: expenses } = await supabase
    .from("expenses")
    .select("amount")
    .eq("user_id", userId)
    .eq("category", "publicité")
    .eq("date", date);

  const fbAdSpend = expenses?.reduce((sum: number, e: any) => sum + Number(e.amount), 0) || 0;

  // Calculate ROAS
  const roas = fbAdSpend > 0 ? totalSales / fbAdSpend : 0;

  // Get top products
  const productStats = new Map<string, { revenue: number; count: number }>();
  orders?.forEach((order: any) => {
    const productName = order.products?.name || "Unknown";
    const current = productStats.get(productName) || { revenue: 0, count: 0 };
    productStats.set(productName, {
      revenue: current.revenue + Number(order.total_amount),
      count: current.count + 1,
    });
  });

  const sortedProducts = Array.from(productStats.entries())
    .map(([name, stats]) => ({ name, ...stats }))
    .sort((a, b) => b.revenue - a.revenue);

  const topProducts = sortedProducts.slice(0, 3);
  const bottomProducts = sortedProducts.slice(-3).reverse();

  return {
    totalSales,
    totalOrders,
    fbAdSpend,
    roas,
    roasChange: 0,
    topProducts,
    bottomProducts,
    currency,
  };
}

async function generateAIInsights(metrics: DailyMetrics, language: string) {
  const prompt = `Tu es un analyste e-commerce expert. Analyse les métriques suivantes et fournis des insights actionnables en ${language === "fr" ? "français" : "anglais"}.

MÉTRIQUES DU JOUR:
- Ventes totales: ${metrics.totalSales.toFixed(0)} ${metrics.currency}
- Nombre de commandes: ${metrics.totalOrders}
- Dépenses publicitaires Facebook: ${metrics.fbAdSpend.toFixed(0)} ${metrics.currency}
- ROAS (Return on Ad Spend): ${metrics.roas.toFixed(2)}x
- Changement ROAS vs hier: ${metrics.roasChange > 0 ? "+" : ""}${metrics.roasChange.toFixed(1)}%

TOP 3 PRODUITS:
${metrics.topProducts.map((p, i) => `${i + 1}. ${p.name}: ${p.revenue.toFixed(0)} ${metrics.currency} (${p.count} ventes)`).join("\n")}

BOTTOM 3 PRODUITS:
${metrics.bottomProducts.map((p, i) => `${i + 1}. ${p.name}: ${p.revenue.toFixed(0)} ${metrics.currency} (${p.count} ventes)`).join("\n")}

FOURNIS:
1. Un résumé en 1 phrase de la performance du jour
2. 3 à 5 insights actionnables spécifiques
3. 2 actions recommandées prioritaires
4. 1 alerte critique (s'il y en a une, sinon null)

Format ta réponse EXACTEMENT comme suit (JSON strict):
{
  "summary": "phrase résumé ici",
  "insights": [
    "Premier insight actionnable",
    "Deuxième insight actionnable",
    "Troisième insight actionnable"
  ],
  "recommended_actions": [
    "Première action recommandée",
    "Deuxième action recommandée"
  ],
  "critical_alert": "Alerte critique ou null"
}`;

  console.log("Calling Lovable AI for insights generation...");

  const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${lovableApiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages: [
        {
          role: "system",
          content: "Tu es un analyste e-commerce expert qui génère des insights actionnables en JSON strict.",
        },
        { role: "user", content: prompt },
      ],
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    console.error("AI API error:", response.status, await response.text());
    throw new Error(`AI API error: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content || "";

  // Extract JSON from response
  let parsed;
  try {
    // Try to find JSON in the response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      parsed = JSON.parse(jsonMatch[0]);
    } else {
      throw new Error("No JSON found in response");
    }
  } catch (e) {
    console.error("Failed to parse AI response:", content);
    // Fallback response
    parsed = {
      summary: "Données insuffisantes pour générer un résumé",
      insights: ["Analyse en cours", "Données collectées", "Rapport en préparation"],
      recommended_actions: ["Continuer à surveiller les métriques", "Réviser la stratégie publicitaire"],
      critical_alert: null,
    };
  }

  return parsed;
}

serve(handler);