import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.75.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const ShopifySyncSchema = z.object({
  userId: z.string().uuid(),
  shop: z.string().regex(/^[a-z0-9-]+\.myshopify\.com$/, 'Invalid Shopify shop domain')
});

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Validate input
    const body = await req.json();
    const parseResult = ShopifySyncSchema.safeParse(body);
    
    if (!parseResult.success) {
      return new Response(
        JSON.stringify({ error: 'Invalid input', details: parseResult.error.issues }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { userId, shop } = parseResult.data;

    console.log('Syncing products');

    // Get user's Shopify token from secure_tokens table
    const { data: tokenRecord, error: tokenError } = await supabase
      .from('secure_tokens')
      .select('token')
      .eq('user_id', userId)
      .eq('service', 'shopify')
      .single();

    if (tokenError || !tokenRecord?.token) {
      throw new Error('Shopify token not found');
    }

    // Fetch products from Shopify
    const productsResponse = await fetch(
      `https://${shop}/admin/api/2024-01/products.json`,
      {
        headers: {
          'X-Shopify-Access-Token': tokenRecord.token,
          'Content-Type': 'application/json',
        },
      }
    );

    if (!productsResponse.ok) {
      console.error('Failed to fetch products', { status: productsResponse.status });
      throw new Error('Failed to fetch products from Shopify');
    }

    const { products } = await productsResponse.json();
    console.log(`Fetched ${products.length} products`);

    // Upsert products to database
    for (const product of products) {
      const productData = {
        user_id: userId,
        shopify_id: product.id.toString(),
        name: product.title,
        sku: product.variants?.[0]?.sku || null,
        cost_price: parseFloat(product.variants?.[0]?.price || '0'),
        sale_price: parseFloat(product.variants?.[0]?.price || '0'),
        image_url: product.image?.src || null,
        currency: 'FCFA',
      };

      const { error: upsertError } = await supabase
        .from('products')
        .upsert(productData, {
          onConflict: 'shopify_id',
          ignoreDuplicates: false,
        });

      if (upsertError) {
        console.error('Error upserting product');
      }

      // Sync variants if they exist
      if (product.variants && product.variants.length > 1) {
        const { data: dbProduct } = await supabase
          .from('products')
          .select('id')
          .eq('shopify_id', product.id.toString())
          .single();

        if (dbProduct) {
          for (const variant of product.variants) {
            const variantData = {
              user_id: userId,
              product_id: dbProduct.id,
              shopify_variant_id: variant.id.toString(),
              name: variant.title,
              sku: variant.sku,
              cost_price: parseFloat(variant.price || '0'),
              sale_price: parseFloat(variant.price || '0'),
              stock_quantity: variant.inventory_quantity || 0,
            };

            await supabase
              .from('product_variants')
              .upsert(variantData, {
                onConflict: 'shopify_variant_id',
                ignoreDuplicates: false,
              });
          }
        }
      }
    }

    console.log('Products sync completed');

    return new Response(
      JSON.stringify({ success: true, synced: products.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in shopify-sync-products');
    return new Response(
      JSON.stringify({ error: 'Product sync failed' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
