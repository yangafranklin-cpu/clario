import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.75.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const ShopifySyncSchema = z.object({
  userId: z.string().uuid(),
  shop: z.string().regex(/^[a-z0-9-]+\.myshopify\.com$/, 'Invalid Shopify shop domain')
});

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Validate input
    const body = await req.json();
    const parseResult = ShopifySyncSchema.safeParse(body);
    
    if (!parseResult.success) {
      return new Response(
        JSON.stringify({ error: 'Invalid input', details: parseResult.error.issues }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { userId, shop } = parseResult.data;

    console.log('Syncing orders');

    // Get user's Shopify token from secure_tokens table
    const { data: tokenRecord, error: tokenError } = await supabase
      .from('secure_tokens')
      .select('token')
      .eq('user_id', userId)
      .eq('service', 'shopify')
      .single();

    if (tokenError || !tokenRecord?.token) {
      throw new Error('Shopify token not found');
    }

    // Fetch orders from Shopify (last 250 orders)
    const ordersResponse = await fetch(
      `https://${shop}/admin/api/2024-01/orders.json?status=any&limit=250`,
      {
        headers: {
          'X-Shopify-Access-Token': tokenRecord.token,
          'Content-Type': 'application/json',
        },
      }
    );

    if (!ordersResponse.ok) {
      console.error('Failed to fetch orders', { status: ordersResponse.status });
      throw new Error('Failed to fetch orders from Shopify');
    }

    const { orders } = await ordersResponse.json();
    console.log(`Fetched ${orders.length} orders`);

    // Upsert orders to database
    for (const order of orders) {
      for (const lineItem of order.line_items) {
        // Find matching product by shopify product id
        const { data: product } = await supabase
          .from('products')
          .select('id')
          .eq('shopify_id', lineItem.product_id?.toString())
          .single();

        // Find matching variant if exists
        const { data: variant } = await supabase
          .from('product_variants')
          .select('id')
          .eq('shopify_variant_id', lineItem.variant_id?.toString())
          .maybeSingle();

        const orderData = {
          user_id: userId,
          order_id_shopify: order.id.toString(),
          customer_name: order.customer ? `${order.customer.first_name} ${order.customer.last_name}` : 'Client Shopify',
          product_id: product?.id || null,
          product_variant_id: variant?.id || null,
          quantity: lineItem.quantity,
          total_amount: parseFloat(lineItem.price),
          status: order.financial_status === 'paid' ? 'completed' : 
                  order.fulfillment_status === 'fulfilled' ? 'delivered' : 'pending',
          currency: order.currency || 'FCFA',
        };

        const { error: upsertError } = await supabase
          .from('orders')
          .upsert(orderData, {
            onConflict: 'order_id_shopify',
            ignoreDuplicates: false,
          });

        if (upsertError) {
          console.error('Error upserting order');
        }
      }
    }

    console.log('Orders sync completed');

    return new Response(
      JSON.stringify({ success: true, synced: orders.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in shopify-sync-orders');
    return new Response(
      JSON.stringify({ error: 'Order sync failed' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
