import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const OrderStatusChangeSchema = z.object({
  orderId: z.string().uuid(),
  oldStatus: z.enum(['pending', 'processing', 'shipped', 'delivered', 'cancelled']),
  newStatus: z.enum(['pending', 'processing', 'shipped', 'delivered', 'cancelled'])
});

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify authentication
    const authHeader = req.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } }
    });

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Validate input
    const body = await req.json();
    const parseResult = OrderStatusChangeSchema.safeParse(body);
    
    if (!parseResult.success) {
      return new Response(
        JSON.stringify({ error: 'Invalid input', details: parseResult.error.issues }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { orderId, oldStatus, newStatus } = parseResult.data;

    // Use service role key for admin operations
    const adminSupabase = createClient(supabaseUrl, supabaseKey);

    console.log(`Processing status change for order ${orderId}: ${oldStatus} -> ${newStatus}`);

    // Get order details
    const { data: order, error: orderError } = await adminSupabase
      .from("orders")
      .select("*, products(name), profiles!orders_user_id_fkey(email, full_name)")
      .eq("id", orderId)
      .single();

    if (orderError || !order) {
      throw new Error(`Order not found: ${orderError?.message}`);
    }

    // Get assigned assistant if any
    let assignedEmail = null;
    if (order.assigned_to) {
      const { data: assistant } = await adminSupabase
        .from("profiles")
        .select("email, full_name")
        .eq("id", order.assigned_to)
        .single();
      
      assignedEmail = assistant?.email;
    }

    // Create notification for customer
    await adminSupabase.from("notifications").insert({
      user_id: order.user_id,
      title: `Commande ${getStatusLabel(newStatus)}`,
      message: `Votre commande ${order.id.slice(0, 8)} est maintenant ${getStatusLabel(newStatus).toLowerCase()}`,
      type: "status_change",
      order_id: orderId,
    });

    // Create notification for assigned assistant
    if (order.assigned_to) {
      await adminSupabase.from("notifications").insert({
        user_id: order.assigned_to,
        title: `Changement de statut`,
        message: `La commande ${order.id.slice(0, 8)} est maintenant ${getStatusLabel(newStatus).toLowerCase()}`,
        type: "status_change",
        order_id: orderId,
      });
    }

    // Send emails
    const emails = [];
    
    if (order.profiles?.email) {
      emails.push({
        from: "Commandes <onboarding@resend.dev>",
        to: [order.profiles.email],
        subject: `Commande ${getStatusLabel(newStatus)}`,
        html: `
          <h1>Bonjour ${order.profiles.full_name || "Client"},</h1>
          <p>Votre commande a été mise à jour :</p>
          <ul>
            <li><strong>Numéro:</strong> ${order.id.slice(0, 8)}</li>
            <li><strong>Statut:</strong> ${getStatusLabel(newStatus)}</li>
            <li><strong>Produit:</strong> ${order.products?.name || "N/A"}</li>
          </ul>
          <p>Merci de votre confiance !</p>
        `,
      });
    }

    if (assignedEmail) {
      emails.push({
        from: "Commandes <onboarding@resend.dev>",
        to: [assignedEmail],
        subject: `Changement de statut - Commande ${order.id.slice(0, 8)}`,
        html: `
          <h1>Changement de statut</h1>
          <p>La commande ${order.id.slice(0, 8)} a changé de statut :</p>
          <ul>
            <li><strong>Ancien statut:</strong> ${getStatusLabel(oldStatus)}</li>
            <li><strong>Nouveau statut:</strong> ${getStatusLabel(newStatus)}</li>
            <li><strong>Client:</strong> ${order.customer_name}</li>
          </ul>
        `,
      });
    }

    // Send all emails
    for (const email of emails) {
      await resend.emails.send(email);
    }

    console.log(`Notifications sent successfully for order ${orderId}`);

    return new Response(
      JSON.stringify({ success: true, emailsSent: emails.length }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in notify-order-status function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    pending: "En attente",
    processing: "En cours de traitement",
    shipped: "Expédiée",
    delivered: "Livrée",
    cancelled: "Annulée",
  };
  return labels[status] || status;
}

serve(handler);