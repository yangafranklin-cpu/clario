import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.75.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Starting scheduled Shopify sync');

    // Get all users with Shopify connected
    const { data: profiles, error: profilesError } = await supabase
      .from('profiles')
      .select('id, shop_domain')
      .eq('shopify_connected', true);

    if (profilesError) {
      throw profilesError;
    }

    console.log(`Found ${profiles.length} connected users`);

    // For each user, trigger sync
    const results = [];
    for (const profile of profiles) {
      try {
        const shop = profile.shop_domain;
        
        if (!shop) {
          console.error('Shop domain not found');
          results.push({
            userId: profile.id,
            error: 'Shop domain not found',
          });
          continue;
        }

        // Sync products
        const productsSync = await fetch(`${supabaseUrl}/functions/v1/shopify-sync-products`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ userId: profile.id, shop }),
        });

        // Sync orders
        const ordersSync = await fetch(`${supabaseUrl}/functions/v1/shopify-sync-orders`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${supabaseKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ userId: profile.id, shop }),
        });

        results.push({
          userId: profile.id,
          productsSync: productsSync.ok,
          ordersSync: ordersSync.ok,
        });
      } catch (error) {
        console.error('Sync error occurred');
        results.push({
          userId: profile.id,
          error: 'Sync failed',
        });
      }
    }

    console.log('Scheduled sync completed');

    return new Response(
      JSON.stringify({ success: true, results }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in shopify-sync-all');
    return new Response(
      JSON.stringify({ error: 'Sync operation failed' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
