import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const AssignmentEmailSchema = z.object({
  assistantEmail: z.string().email().max(255),
  assistantName: z.string().trim().min(1).max(100),
  orderDetails: z.object({
    orderId: z.string().uuid(),
    customerName: z.string().trim().min(1).max(200),
    productName: z.string().trim().min(1).max(200),
    status: z.enum(['pending', 'processing', 'shipped', 'delivered', 'cancelled'])
  })
});

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify authentication
    const authHeader = req.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } }
    });

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Verify user has admin role
    const { data: userRole } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    if (userRole?.role !== 'admin') {
      return new Response(JSON.stringify({ error: 'Forbidden' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Validate input
    const body = await req.json();
    const parseResult = AssignmentEmailSchema.safeParse(body);
    
    if (!parseResult.success) {
      return new Response(
        JSON.stringify({ error: 'Invalid input', details: parseResult.error.issues }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { assistantEmail, assistantName, orderDetails } = parseResult.data;

    console.log("Sending assignment email to:", assistantEmail);

    const emailResponse = await resend.emails.send({
      from: "Commandes <onboarding@resend.dev>",
      to: [assistantEmail],
      subject: `Nouvelle commande assignée - ${orderDetails.orderId}`,
      html: `
        <h1>Bonjour ${assistantName},</h1>
        <p>Une nouvelle commande vous a été assignée :</p>
        <ul>
          <li><strong>ID Commande:</strong> ${orderDetails.orderId}</li>
          <li><strong>Client:</strong> ${orderDetails.customerName}</li>
          <li><strong>Produit:</strong> ${orderDetails.productName}</li>
          <li><strong>Statut:</strong> ${orderDetails.status}</li>
        </ul>
        <p>Veuillez vous connecter à votre tableau de bord pour traiter cette commande.</p>
        <p>Cordialement,<br>L'équipe</p>
      `,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error in send-assignment-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);