-- Drop the failed functions and triggers
DROP TRIGGER IF EXISTS notify_new_order_trigger ON public.orders;
DROP TRIGGER IF EXISTS notify_order_status_trigger ON public.orders;
DROP FUNCTION IF EXISTS public.notify_new_order();
DROP FUNCTION IF EXISTS public.notify_order_status_change();

-- Simpler approach: Just create notifications in the database
-- Edge functions will be called manually from the app when needed

-- Create function to notify on new order
CREATE OR REPLACE FUNCTION public.create_new_order_notifications()
RETURNS TRIGGER AS $$
DECLARE
  admin_record RECORD;
BEGIN
  -- Create notifications for all admins
  FOR admin_record IN 
    SELECT ur.user_id
    FROM public.user_roles ur
    WHERE ur.role = 'admin'
  LOOP
    INSERT INTO public.notifications (user_id, title, message, type, order_id)
    VALUES (
      admin_record.user_id,
      'Nouvelle commande',
      'Commande ' || substring(NEW.id::text, 1, 8) || ' créée par ' || NEW.customer_name,
      'new_order',
      NEW.id
    );
  END LOOP;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for new orders
CREATE TRIGGER create_new_order_notifications_trigger
  AFTER INSERT ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.create_new_order_notifications();

-- Create function to notify on status change
CREATE OR REPLACE FUNCTION public.create_status_change_notifications()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    -- Notify customer
    INSERT INTO public.notifications (user_id, title, message, type, order_id)
    VALUES (
      NEW.user_id,
      'Commande mise à jour',
      'Votre commande ' || substring(NEW.id::text, 1, 8) || ' est maintenant ' || NEW.status,
      'status_change',
      NEW.id
    );
    
    -- Notify assigned assistant if any
    IF NEW.assigned_to IS NOT NULL THEN
      INSERT INTO public.notifications (user_id, title, message, type, order_id)
      VALUES (
        NEW.assigned_to,
        'Changement de statut',
        'La commande ' || substring(NEW.id::text, 1, 8) || ' est maintenant ' || NEW.status,
        'status_change',
        NEW.id
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for status changes
CREATE TRIGGER create_status_change_notifications_trigger
  AFTER UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.create_status_change_notifications();