-- Fix search_path for update function
DROP TRIGGER IF EXISTS update_product_variants_updated_at ON public.product_variants;
DROP FUNCTION IF EXISTS public.update_product_variant_updated_at();

CREATE OR REPLACE FUNCTION public.update_product_variant_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_product_variants_updated_at
  BEFORE UPDATE ON public.product_variants
  FOR EACH ROW
  EXECUTE FUNCTION public.update_product_variant_updated_at();