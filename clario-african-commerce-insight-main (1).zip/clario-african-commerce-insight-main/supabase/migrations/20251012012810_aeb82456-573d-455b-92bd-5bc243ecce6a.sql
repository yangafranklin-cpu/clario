-- Drop the old pg_net extension from public schema
DROP EXTENSION IF EXISTS pg_net CASCADE;

-- Recreate it in the extensions schema
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;