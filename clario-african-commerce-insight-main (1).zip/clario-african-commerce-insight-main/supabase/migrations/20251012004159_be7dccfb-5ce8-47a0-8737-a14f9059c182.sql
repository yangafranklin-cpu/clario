-- Create product_variants table
CREATE TABLE public.product_variants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  shopify_variant_id TEXT,
  external_variant_id TEXT,
  external_source TEXT,
  sku TEXT,
  name TEXT NOT NULL,
  size TEXT,
  color TEXT,
  shoe_size TEXT,
  custom_attributes JSONB DEFAULT '{}',
  cost_price DECIMAL(10, 2) NOT NULL,
  sale_price DECIMAL(10, 2) NOT NULL,
  stock_quantity INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Enable RLS
ALTER TABLE public.product_variants ENABLE ROW LEVEL SECURITY;

-- RLS Policies for product_variants
CREATE POLICY "Admins can view all variants"
  ON public.product_variants FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert variants"
  ON public.product_variants FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update variants"
  ON public.product_variants FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete variants"
  ON public.product_variants FOR DELETE
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Consultants and assistantes can view variants"
  ON public.product_variants FOR SELECT
  USING (
    public.has_role(auth.uid(), 'consultant') OR 
    public.has_role(auth.uid(), 'assistante')
  );

-- Create indexes for better performance
CREATE INDEX idx_product_variants_product_id ON public.product_variants(product_id);
CREATE INDEX idx_product_variants_user_id ON public.product_variants(user_id);
CREATE INDEX idx_product_variants_shopify_id ON public.product_variants(shopify_variant_id) WHERE shopify_variant_id IS NOT NULL;
CREATE INDEX idx_product_variants_external_id ON public.product_variants(external_variant_id) WHERE external_variant_id IS NOT NULL;

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION public.update_product_variant_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_product_variants_updated_at
  BEFORE UPDATE ON public.product_variants
  FOR EACH ROW
  EXECUTE FUNCTION public.update_product_variant_updated_at();