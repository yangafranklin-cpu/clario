-- Add notes column to expenses table
ALTER TABLE public.expenses 
ADD COLUMN IF NOT EXISTS notes TEXT;