-- Add 'livreur' role to app_role enum
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'livreur';

-- Update handle_new_user function to set 'admin' as default role for new users
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Utilisateur'),
    NEW.email
  );
  
  -- All new users become admin (shop owner) by default
  -- Super admins can change roles later
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'admin'::app_role);
  
  RETURN NEW;
END;
$function$;