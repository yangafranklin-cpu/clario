-- Create notifications table for internal notifications
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info',
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own notifications"
  ON public.notifications FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications"
  ON public.notifications FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can insert notifications"
  ON public.notifications FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'));

-- Create order actions history table
CREATE TABLE IF NOT EXISTS public.order_actions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  action_type TEXT NOT NULL,
  description TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.order_actions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all order actions"
  ON public.order_actions FOR SELECT
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Assistantes can view order actions"
  ON public.order_actions FOR SELECT
  USING (has_role(auth.uid(), 'assistante'));

CREATE POLICY "Admins can insert order actions"
  ON public.order_actions FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Assistantes can insert order actions"
  ON public.order_actions FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'assistante'));

-- Add gross_margin and net_profit columns to orders if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'orders' AND column_name = 'gross_margin') THEN
    ALTER TABLE public.orders ADD COLUMN gross_margin NUMERIC;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'orders' AND column_name = 'net_profit') THEN
    ALTER TABLE public.orders ADD COLUMN net_profit NUMERIC;
  END IF;
END $$;

-- Function to calculate order metrics
CREATE OR REPLACE FUNCTION public.calculate_order_metrics()
RETURNS TRIGGER AS $$
DECLARE
  v_cost_price NUMERIC;
  v_sale_price NUMERIC;
  v_ad_cost NUMERIC := 0;
BEGIN
  -- Get product prices
  IF NEW.product_variant_id IS NOT NULL THEN
    SELECT cost_price, sale_price INTO v_cost_price, v_sale_price
    FROM public.product_variants
    WHERE id = NEW.product_variant_id;
  ELSIF NEW.product_id IS NOT NULL THEN
    SELECT cost_price, sale_price INTO v_cost_price, v_sale_price
    FROM public.products
    WHERE id = NEW.product_id;
  END IF;

  -- Get ad costs for this product
  SELECT COALESCE(SUM(amount), 0) INTO v_ad_cost
  FROM public.expenses
  WHERE category = 'publicité'
    AND (linked_product_id = NEW.product_id OR linked_product_id IS NULL)
    AND date <= CURRENT_DATE;

  -- Calculate gross margin per unit
  NEW.gross_margin := (v_sale_price - v_cost_price) * NEW.quantity;

  -- Calculate net profit (revenue - all costs)
  NEW.net_profit := (v_sale_price * NEW.quantity) - 
                    (COALESCE(NEW.logistics_cost, 0) + v_ad_cost + (v_cost_price * NEW.quantity));

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for order metrics calculation
DROP TRIGGER IF EXISTS calculate_order_metrics_trigger ON public.orders;
CREATE TRIGGER calculate_order_metrics_trigger
  BEFORE INSERT OR UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.calculate_order_metrics();

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON public.notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_order_actions_order_id ON public.order_actions(order_id);
CREATE INDEX IF NOT EXISTS idx_orders_assigned_to ON public.orders(assigned_to);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);