-- Fix 1: Create secure_tokens table for API tokens (no user-readable policies)
CREATE TABLE IF NOT EXISTS public.secure_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  service text NOT NULL,
  token text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, service)
);

-- Enable RLS but with NO SELECT policies - only service role can access
ALTER TABLE public.secure_tokens ENABLE ROW LEVEL SECURITY;

-- Only allow service role to manage tokens (no user policies)
-- Service role bypasses RLS, so no policies needed for it to work

-- Migrate existing tokens from profiles to secure_tokens
INSERT INTO public.secure_tokens (user_id, service, token)
SELECT id, 'shopify', shopify_token
FROM public.profiles
WHERE shopify_token IS NOT NULL
ON CONFLICT (user_id, service) DO NOTHING;

INSERT INTO public.secure_tokens (user_id, service, token)
SELECT id, 'facebook', facebook_token
FROM public.profiles
WHERE facebook_token IS NOT NULL
ON CONFLICT (user_id, service) DO NOTHING;

-- Remove token columns from profiles table
ALTER TABLE public.profiles DROP COLUMN IF EXISTS shopify_token;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS facebook_token;

-- Fix 2: Remove permissive insights insert policy
DROP POLICY IF EXISTS "System can insert insights" ON public.insights;

-- Only service role can insert insights (bypasses RLS automatically)
-- No need for a policy with 'true' condition

-- Add updated_at trigger for secure_tokens
CREATE OR REPLACE FUNCTION public.update_secure_tokens_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_secure_tokens_timestamp
BEFORE UPDATE ON public.secure_tokens
FOR EACH ROW
EXECUTE FUNCTION public.update_secure_tokens_updated_at();