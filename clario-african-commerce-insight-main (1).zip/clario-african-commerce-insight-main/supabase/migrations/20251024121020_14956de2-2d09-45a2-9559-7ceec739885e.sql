-- Create organizations table
CREATE TABLE public.organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  shop_domain TEXT,
  country TEXT,
  currency TEXT DEFAULT 'FCFA',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  is_active BOOLEAN DEFAULT true
);

-- Create support settings table
CREATE TABLE public.support_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  support_email TEXT NOT NULL DEFAULT 'support@example.com',
  support_whatsapp TEXT NOT NULL DEFAULT '+221000000000',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default support settings
INSERT INTO public.support_settings (support_email, support_whatsapp)
VALUES ('support@example.com', '+221000000000');

-- Add organization_id to existing tables
ALTER TABLE public.profiles ADD COLUMN organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;
ALTER TABLE public.products ADD COLUMN organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;
ALTER TABLE public.product_variants ADD COLUMN organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;
ALTER TABLE public.orders ADD COLUMN organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;
ALTER TABLE public.expenses ADD COLUMN organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;
ALTER TABLE public.alerts ADD COLUMN organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;
ALTER TABLE public.insights ADD COLUMN organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;
ALTER TABLE public.notifications ADD COLUMN organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;
ALTER TABLE public.thresholds ADD COLUMN organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE;

-- Enable RLS on organizations
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;

-- Enable RLS on support_settings
ALTER TABLE public.support_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for organizations
CREATE POLICY "Super admins can view all organizations"
ON public.organizations FOR SELECT
USING (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "Super admins can insert organizations"
ON public.organizations FOR INSERT
WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "Super admins can update organizations"
ON public.organizations FOR UPDATE
USING (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "Super admins can delete organizations"
ON public.organizations FOR DELETE
USING (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "Users can view their own organization"
ON public.organizations FOR SELECT
USING (
  id IN (
    SELECT organization_id FROM public.profiles WHERE id = auth.uid()
  )
);

-- RLS Policies for support_settings
CREATE POLICY "Super admins can manage support settings"
ON public.support_settings FOR ALL
USING (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY "All authenticated users can view support settings"
ON public.support_settings FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Update existing RLS policies to include organization isolation
-- Drop old policies and recreate with organization_id checks

-- Products policies
DROP POLICY IF EXISTS "Admins can view all products" ON public.products;
DROP POLICY IF EXISTS "Consultants can view products" ON public.products;

CREATE POLICY "Admins can view their organization products"
ON public.products FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) AND
  organization_id IN (SELECT organization_id FROM public.profiles WHERE id = auth.uid())
);

CREATE POLICY "Consultants can view their organization products"
ON public.products FOR SELECT
USING (
  (has_role(auth.uid(), 'consultant'::app_role) OR has_role(auth.uid(), 'assistante'::app_role)) AND
  organization_id IN (SELECT organization_id FROM public.profiles WHERE id = auth.uid())
);

-- Orders policies
DROP POLICY IF EXISTS "Admins can view all orders" ON public.orders;
DROP POLICY IF EXISTS "Assistantes can view all orders" ON public.orders;

CREATE POLICY "Admins can view their organization orders"
ON public.orders FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) AND
  organization_id IN (SELECT organization_id FROM public.profiles WHERE id = auth.uid())
);

CREATE POLICY "Assistantes can view their organization orders"
ON public.orders FOR SELECT
USING (
  has_role(auth.uid(), 'assistante'::app_role) AND
  organization_id IN (SELECT organization_id FROM public.profiles WHERE id = auth.uid())
);

-- Expenses policies
DROP POLICY IF EXISTS "Admins can view all expenses" ON public.expenses;

CREATE POLICY "Admins can view their organization expenses"
ON public.expenses FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) AND
  organization_id IN (SELECT organization_id FROM public.profiles WHERE id = auth.uid())
);

-- Function to update organization timestamps
CREATE OR REPLACE FUNCTION public.update_organizations_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER update_organizations_updated_at
BEFORE UPDATE ON public.organizations
FOR EACH ROW
EXECUTE FUNCTION public.update_organizations_updated_at();

-- Function to update support_settings timestamps
CREATE OR REPLACE FUNCTION public.update_support_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER update_support_settings_updated_at
BEFORE UPDATE ON public.support_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_support_settings_updated_at();