-- Create thresholds table for customizable alerts
CREATE TABLE IF NOT EXISTS public.thresholds (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  metric_type TEXT NOT NULL,
  condition TEXT NOT NULL,
  threshold_value NUMERIC NOT NULL,
  is_enabled BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.thresholds ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Admins can manage thresholds"
  ON public.thresholds
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can view their own thresholds"
  ON public.thresholds
  FOR SELECT
  USING (auth.uid() = user_id);

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION public.update_thresholds_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public';

CREATE TRIGGER update_thresholds_updated_at
BEFORE UPDATE ON public.thresholds
FOR EACH ROW
EXECUTE FUNCTION public.update_thresholds_updated_at();

-- Insert default thresholds for existing admins
INSERT INTO public.thresholds (user_id, metric_type, condition, threshold_value)
SELECT 
  user_id,
  'roas',
  'less_than',
  1.5
FROM public.user_roles
WHERE role = 'admin'::app_role
ON CONFLICT DO NOTHING;

INSERT INTO public.thresholds (user_id, metric_type, condition, threshold_value)
SELECT 
  user_id,
  'net_profit',
  'less_than',
  0
FROM public.user_roles
WHERE role = 'admin'::app_role
ON CONFLICT DO NOTHING;