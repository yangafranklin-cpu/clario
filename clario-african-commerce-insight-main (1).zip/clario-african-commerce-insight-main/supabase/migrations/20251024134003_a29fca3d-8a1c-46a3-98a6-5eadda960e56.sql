-- Update handle_new_user function to automatically create organization
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_organization_id UUID;
  v_shop_name TEXT;
  v_phone TEXT;
  v_country TEXT;
BEGIN
  -- Extract organization info from user metadata
  v_shop_name := COALESCE(NEW.raw_user_meta_data->>'shop_name', 'Mon Entreprise');
  v_phone := NEW.raw_user_meta_data->>'phone';
  v_country := NEW.raw_user_meta_data->>'country';
  
  -- Create a new organization for this user
  INSERT INTO public.organizations (name, email, phone, country, currency)
  VALUES (
    v_shop_name,
    NEW.email,
    v_phone,
    v_country,
    'FCFA'
  )
  RETURNING id INTO v_organization_id;
  
  -- Create profile linked to the new organization
  INSERT INTO public.profiles (id, full_name, email, phone, country, organization_id)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Utilisateur'),
    NEW.email,
    v_phone,
    v_country,
    v_organization_id
  );
  
  -- Assign admin role (shop owner)
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'admin'::app_role);
  
  RETURN NEW;
END;
$function$;