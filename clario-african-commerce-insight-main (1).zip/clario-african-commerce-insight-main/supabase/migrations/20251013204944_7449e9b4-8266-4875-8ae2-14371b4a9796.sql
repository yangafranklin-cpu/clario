-- Add shop_domain column to profiles table
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS shop_domain TEXT;

-- Create cron job to sync Shopify data every 5 minutes
SELECT cron.schedule(
  'shopify-sync-all',
  '*/5 * * * *', -- Every 5 minutes
  $$
  SELECT
    net.http_post(
        url:='https://tvmuwqyivshuxnvbkpbv.supabase.co/functions/v1/shopify-sync-all',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2bXV3cXlpdnNodXhudmJrcGJ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAyMTk2OTAsImV4cCI6MjA3NTc5NTY5MH0.xqfkVs0RXsYHAH-tMHLdR0ZatbSD7uN1_2Ja9Afgb3E"}'::jsonb,
        body:=concat('{"time": "', now(), '"}')::jsonb
    ) as request_id;
  $$
);