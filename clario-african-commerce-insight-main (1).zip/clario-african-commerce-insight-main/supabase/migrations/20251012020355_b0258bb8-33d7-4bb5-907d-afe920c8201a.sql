-- Create insights table to store AI-generated insights
CREATE TABLE IF NOT EXISTS public.insights (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  metrics JSONB NOT NULL,
  summary TEXT NOT NULL,
  insights JSONB NOT NULL,
  critical_alert TEXT,
  recommended_actions JSONB,
  language TEXT NOT NULL DEFAULT 'fr',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, date)
);

ALTER TABLE public.insights ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all insights"
  ON public.insights FOR SELECT
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view their own insights"
  ON public.insights FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "System can insert insights"
  ON public.insights FOR INSERT
  WITH CHECK (true);

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_insights_user_date ON public.insights(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_insights_date ON public.insights(date DESC);

-- Enable pg_cron extension for scheduled jobs
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule daily insights generation at 8 AM every day
-- This will call the edge function to generate insights
SELECT cron.schedule(
  'generate-daily-insights',
  '0 8 * * *',
  $$
  SELECT net.http_post(
    url := 'https://tvmuwqyivshuxnvbkpbv.supabase.co/functions/v1/generate-daily-insights',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2bXV3cXlpdnNodXhudmJrcGJ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAyMTk2OTAsImV4cCI6MjA3NTc5NTY5MH0.xqfkVs0RXsYHAH-tMHLdR0ZatbSD7uN1_2Ja9Afgb3E'
    ),
    body := jsonb_build_object('scheduled', true)
  ) as request_id;
  $$
);