-- Create schemas if not exist
CREATE SCHEMA IF NOT EXISTS cron;
CREATE SCHEMA IF NOT EXISTS extensions;

-- Install pg_cron in cron schema (its default)
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA cron;

-- Install pg_net in extensions schema
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Create the cron job
SELECT cron.schedule(
  'generate-daily-alerts',
  '0 8 * * *',
  $$
  SELECT
    extensions.http_post(
      url:='https://tvmuwqyivshuxnvbkpbv.supabase.co/functions/v1/generate-alerts',
      headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2bXV3cXlpdnNodXhudmJrcGJ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAyMTk2OTAsImV4cCI6MjA3NTc5NTY5MH0.xqfkVs0RXsYHAH-tMHLdR0ZatbSD7uN1_2Ja9Afgb3E"}'::jsonb,
      body:='{}'::jsonb
    ) as request_id;
  $$
);