-- Enable pg_cron extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Enable pg_net extension for HTTP calls if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Create a cron job to generate alerts daily at 8:00 AM
SELECT cron.schedule(
  'generate-daily-alerts',
  '0 8 * * *', -- Every day at 8:00 AM
  $$
  SELECT
    net.http_post(
      url:='https://tvmuwqyivshuxnvbkpbv.supabase.co/functions/v1/generate-alerts',
      headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR2bXV3cXlpdnNodXhudmJrcGJ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAyMTk2OTAsImV4cCI6MjA3NTc5NTY5MH0.xqfkVs0RXsYHAH-tMHLdR0ZatbSD7uN1_2Ja9Afgb3E"}'::jsonb,
      body:='{}'::jsonb
    ) as request_id;
  $$
);