# Configuration de l'intégration Shopify

## Étapes pour autoriser votre application

### 1. Créer une application Shopify

1. Allez sur [Shopify Partners Dashboard](https://partners.shopify.com)
2. Cliquez sur **Apps** dans le menu de gauche
3. Cliquez sur **Create app**
4. Choisissez **Custom app**

### 2. Configurer l'application OAuth

Dans les paramètres de votre application Shopify :

#### URLs de redirection autorisées
Ajoutez ces URLs dans la section **App setup > URLs** :

**Pour le développement local :**
```
http://localhost:5173/settings
```

**Pour la production :**
```
https://[votre-domaine]/settings
```

#### Permissions (Scopes)
Dans la section **API access scopes**, activez :
- `read_products` - Lire les produits
- `write_products` - Modifier les produits
- `read_orders` - Lire les commandes
- `write_orders` - Modifier les commandes

### 3. Récupérer vos identifiants

Dans votre application Shopify, copiez :
- **Client ID** : À utiliser dans le code (déjà configuré : `f9b3fcb50f731babcfeb5210d928297d`)
- **Client Secret** : Stocké de manière sécurisée dans Lovable Cloud

### 4. Tester la connexion

1. Dans votre application, allez sur la page **Paramètres**
2. Entrez le nom de votre boutique (ex: `ma-boutique` pour `ma-boutique.myshopify.com`)
3. Cliquez sur **Connecter Shopify**
4. Vous serez redirigé vers Shopify pour autoriser l'application
5. Une fois autorisé, vous serez redirigé vers votre application

### Résolution des problèmes courants

#### Erreur "redirect_uri_mismatch"
- Vérifiez que l'URL de redirection dans Shopify correspond exactement à celle utilisée
- Format attendu : `https://[votre-domaine]/settings`
- Pas de slash à la fin, pas de paramètres

#### Erreur "invalid_client"
- Vérifiez que le Client ID est correct
- Vérifiez que le Client Secret est bien configuré dans Lovable Cloud

#### L'autorisation échoue silencieusement
- Ouvrez la console du navigateur pour voir les erreurs
- Vérifiez que les scopes demandés correspondent à ceux configurés dans Shopify

### Support

Pour plus d'informations :
- [Documentation OAuth Shopify](https://shopify.dev/docs/apps/auth/oauth)
- [Guide des scopes API](https://shopify.dev/docs/api/usage/access-scopes)
